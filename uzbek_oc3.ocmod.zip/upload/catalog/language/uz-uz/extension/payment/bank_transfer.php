<?php
// Text
$_['text_title']				= 'Bank o\'tkazmasi';
$_['text_instruction']			= 'Bank o\'tkazmalari bo\'yicha ko\'rsatmalar';
$_['text_description']			= 'Iltimos, umumiy miqdorni quyidagi bank hisob raqamiga o\'tkazing: bu yerda to\'lov rekvizitlari';
$_['text_payment']				= 'Bankdagi hisob raqamimizga pul kelib tushmaguncha, buyurtma bajarilmaydi.';

