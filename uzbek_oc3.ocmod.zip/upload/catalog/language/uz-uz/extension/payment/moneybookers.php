<?php
// Text
$_['text_title'] = 'Карта Visa и MasterCard (Moneybookers)';

