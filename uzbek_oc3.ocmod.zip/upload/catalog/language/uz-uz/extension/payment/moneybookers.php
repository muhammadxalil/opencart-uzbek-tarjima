<?php
// Text
$_['text_title'] = 'Visa va MasterCard kartalari (Moneybookers)';

