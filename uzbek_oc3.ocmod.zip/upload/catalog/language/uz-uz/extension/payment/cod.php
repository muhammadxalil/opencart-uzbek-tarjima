<?php
// Text
$_['text_title'] = 'Yetkazib berilishi bilan to\'lash';

