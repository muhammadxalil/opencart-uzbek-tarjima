<?php
// Text
$_['text_title'] = 'Bepul buyurtma';

