<?php
// Text
$_['text_title']				= 'Visa va MasterCard kartalari (PayPal)';
$_['text_wait']					= 'Iltimos kuting!';
$_['text_credit_card']			= 'To\'lov kartasi haqida ma\'lumot';
$_['text_loading']				= 'Yuklanmoqda';

// Entry
$_['entry_cc_type']				= 'Karta turi:';
$_['entry_cc_number']			= 'Karta raqami:';
$_['entry_cc_start_date']		= 'Kartaning amal qilish muddati boshlanishi:';
$_['entry_cc_expire_date']		= 'Kartaning amal qilish muddati tugashi:';
$_['entry_cc_cvv2']				= 'Xavfsizlik kodi (CVV2):';
$_['entry_cc_issue']			= 'Karta kodi (Issue):';

// Help
$_['help_start_date']			= '(agar ma\'lum bo\'lsa)';
$_['help_issue']				= '(faqat Maestro va Solo kartalari uchun)';

