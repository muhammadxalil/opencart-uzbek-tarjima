<?php
// Text
$_['text_title']				= 'PayPal';
$_['text_reason']				= 'Sabab';
$_['text_testmode']				= 'Ogohlantirish: sinov usulidagi to\'lov shlyuzi \'SandBox\'. Hisobingizdagi mablag\' yechilmaydi.';
$_['text_total']				= 'Yetkazib berish, ishlov berish, chegirmalar va soliqlar';

