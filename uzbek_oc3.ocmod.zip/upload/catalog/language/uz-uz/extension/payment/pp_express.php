<?php
// Heading
$_['express_text_title']		= 'Buyurtmani tasdiqlash';

// Text
$_['text_title']				= 'PayPal Express to\'lovlari (shu jumladan Visa va MasterCard)';
$_['button_continue']			= 'Davom etish';
$_['text_cart']					= 'Xaridlar savatchasi';
$_['text_shipping_updated']		= 'Yetkazib berish yangilandi';
$_['text_trial']				= 'Miqdori:%s; Davriyligi:%s %s; To\'lovlar soni:%s, Keyingi ';
$_['text_recurring']			= 'Miqdori: %s Davriyligi: %s %s';
$_['text_recurring_item']		= 'Takroriy to\'lovlar';
$_['text_length']				= 'To\'lovlar soni: %s';

// Entry
$_['express_entry_coupon']		= 'Kupon kodini kiriting:';

// Button
$_['express_button_coupon']		= 'Qo\'shish';
$_['express_button_confirm']	= 'Tasdiqlash';
$_['express_button_login']		= 'PayPal-ga kirish';
$_['express_button_shipping']	= 'Yetkazib berishni yangilash';
$_['button_cancel_recurring']	= 'Cancel payments';

// Error
$_['error_heading_title']		= 'Xato yuz berdi ...';
$_['error_too_many_failures']	= 'To\'lov jarayonida xatolik yuz berdi.';

