<?php
// Text
$_['text_title']				= 'Naqd to\'lash';
$_['text_instruction']			= 'Naqd to\'lash. Yo\'riqnoma';
$_['text_payable']				= 'Tp\'lovni oluvchi: ';
$_['text_address']				= 'To\'lovlarni manzil bo\'yicha qabul qilish: ';
$_['text_payment']				= 'To‘lov olgunimizcha buyurtmangizga ishlov berilmaydi.';

