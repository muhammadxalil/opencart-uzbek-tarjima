<?php
// Heading
$_['heading_title']    = 'Hamkorlik bo\'limi';

// Text
$_['text_register']    = 'Ro\'yxatdan o\'tish';
$_['text_login']       = 'Kirish';
$_['text_logout']      = 'Chiqish';
$_['text_forgotten']   = 'Parolni unutdingizmi?';
$_['text_account']     = 'Mening ma\'lumotim';
$_['text_edit']        = 'Shaxsiy ma\'lumotlarni tahrirlash';
$_['text_password']    = 'Parol';
$_['text_payment']     = 'To\'lov usullari';
$_['text_tracking']    = 'Yo\'llanma kodi';
$_['text_transaction'] = 'Tranzaksiyalar';


