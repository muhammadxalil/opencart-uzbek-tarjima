<?php
// Heading
$_['heading_title'] = 'Do\'konni tanlang';

// Text
$_['text_default']  = 'Asosiy';
$_['text_store']    = 'Iltimos, tashrif buyurmoqchi bo\'lgan do\'konni tanlang.';

