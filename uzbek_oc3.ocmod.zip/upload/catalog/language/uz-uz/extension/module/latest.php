<?php
// Heading
$_['heading_title'] = 'So\'nggi kelgan mahsulotlar';

// Text
$_['text_tax']      = 'QQS siz:';

