<?php
// Heading
$_['heading_title'] = 'Aksiyalar';

// Text
$_['text_tax']      = 'QQSsiz:';

