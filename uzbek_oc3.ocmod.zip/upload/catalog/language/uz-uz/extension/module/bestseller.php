<?php
// Heading
$_['heading_title'] = 'Eng ko\'p sotilgan mahsulot';

// Text
$_['text_tax']      = 'QQSsiz:';

