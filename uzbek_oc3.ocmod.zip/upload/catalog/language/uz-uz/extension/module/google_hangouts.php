<?php
// Heading
$_['heading_title']  = 'Google Hangouts chati';

