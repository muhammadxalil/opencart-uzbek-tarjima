<?php
// Heading
$_['heading_title']    = 'Shaxsiy kabinet';

// Text
$_['text_register']    = 'Ro\'yxatdan o\'tish';
$_['text_login']       = 'Kirish';
$_['text_logout']      = 'Chiqish';
$_['text_forgotten']   = 'Parolni unutdingizmi?';
$_['text_account']     = 'Mening ma\'lumotim';
$_['text_edit']        = 'Kontakt ma\'lumotlarini o\'zgartirish';
$_['text_password']    = 'Parol';
$_['text_address']     = 'Manzillar kitobi';
$_['text_wishlist']    = 'Xatcho\'plar';
$_['text_order']       = 'Buyurtmalar tarixi';
$_['text_download']    = 'Yuklash uchun fayllar';
$_['text_reward']      = 'Bonus ballari';
$_['text_return']      = 'Qaytarishlar';
$_['text_transaction'] = 'Bitimlar tarixi';
$_['text_newsletter']  = 'Elektron pochta xabarnomasi';
$_['text_recurring']   = 'Doimiy to\'lovlar';

