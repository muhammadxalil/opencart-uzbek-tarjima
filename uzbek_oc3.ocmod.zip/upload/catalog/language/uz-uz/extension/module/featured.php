<?php
// Heading
$_['heading_title'] = 'Tavsiya etilganlari';

// Text
$_['text_tax']      = 'QQSsiz:';

