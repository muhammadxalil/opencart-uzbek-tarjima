<?php
// Text
$_['text_title']				= 'PayPal Ekspress to\'lovlari';
$_['text_canceled']				= 'To\'lov muvaffaqiyatli bekor qilindi!';

// Button
$_['button_cancel']				= 'Takroriy to\'lovlarni bekor qilish';

// Error
$_['error_not_cancelled']		= 'Xatolik: %s';
$_['error_not_found']			= 'Profilni bekor qilib bo\'lmaydi';