<?php
// Text
$_['text_title']       = 'Belgilangan yetkazib berish narxi';
$_['text_description'] = 'Belgilangan yetkazib berish narxi bilan yetkazib berish';

