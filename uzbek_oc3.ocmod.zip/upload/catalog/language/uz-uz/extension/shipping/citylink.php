<?php
// Text
$_['text_title']  = 'Shahar bo\'ylab yetkazib berish';
$_['text_weight'] = 'Vazn:';

