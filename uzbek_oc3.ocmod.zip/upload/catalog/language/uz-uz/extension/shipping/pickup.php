<?php
// Text
$_['text_title']       = 'Pikap';
$_['text_description'] = 'Do\'kondan olib ketish';

