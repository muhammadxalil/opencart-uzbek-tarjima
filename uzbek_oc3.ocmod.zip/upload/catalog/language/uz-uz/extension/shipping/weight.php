<?php
// Text
$_['text_title']  = 'Vazniga qarab yetkazib berish';
$_['text_weight'] = 'Vazn:';

