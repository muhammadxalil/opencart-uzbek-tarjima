<?php
// Text
$_['text_title']       = 'Tovar birligi uchun';
$_['text_description'] = 'Mahsulot birligiga qarab yetkazib berish narxi';

