<?php
// Text
$_['text_title']       = 'Bepul yetkazib berish';
$_['text_description'] = 'Bepul yetkazib berish';

