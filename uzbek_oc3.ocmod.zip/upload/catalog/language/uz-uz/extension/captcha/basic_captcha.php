<?php
// Heading
$_['text_captcha'] = 'Robotlardan himoya';

// Entry
$_['entry_captcha'] = 'Quyidagi maydonchaga kodni kiriting';

// Error
$_['error_captcha'] = 'Tasdiqlash kodi rasmga mos kelmadi!';
