<?php
// Heading
$_['heading_title']        = 'Yetkazib berish narxlarini baholash';

// Text
$_['text_success']         = 'Hisoblash muvaffaqiyatli yakunlandi!';
$_['text_shipping']        = 'Yetkazib berish narxini hisoblash uchun mintaqangizni ko\'rsating.';
$_['text_shipping_method'] = 'Iltimos, joriy buyurtma uchun afzal yetkazib berish usulingizni tanlang.';

// Entry
$_['entry_country']        = 'Mamlakat';
$_['entry_zone']           = 'Tuman / Viloyat';
$_['entry_postcode']       = 'Indeks';

// Error
$_['error_postcode']       = 'Indeks 2 tadan 10 tagacha belgili bo\'lishi kerak!';
$_['error_country']        = 'Iltimos, mamlakatni tanlang!';
$_['error_zone']           = 'Iltimos, Tuman / Viloyatni tanlang!';
$_['error_shipping']       = 'Yetkazib berish usulini ko\'rsatishingiz kerak!';
$_['error_no_shipping']    = 'Ushbu manzilga etkazib berish mumkin emas. Iltimos, <a href="%s"> ma\'muriyat bilan bog\'laning </a>!';

