<?php
$_['text_low_order_fee'] = 'Minimal buyurtma berilgandagi qo\'shimcha to\'lov';

