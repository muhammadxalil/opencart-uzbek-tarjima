<?php
// Heading
$_['heading_title'] = 'Bonus ballarni ishlatish (%s ball mavjud)';

// Text
$_['text_reward']   = 'Bonus ballar (%s)';
$_['text_order_id'] = 'Buyurtma raqami: #%s';
$_['text_success']  = 'Ballar muvaffaqiyatli qo\'llanildi!';

// Entry
$_['entry_reward']  = 'Foydalanish uchun tayyor (maksimum %s)';

// Error
$_['error_reward']  = 'Iltimos, ushbu buyurtmani to\'lash uchun bonus ballari sonini ko\'rsating!';
$_['error_points']  = 'Sizda %s bonus ballari yo\'q!';
$_['error_maximum'] = 'Qo\'llash mumkin bo\'lgan eng ko\'p ball: %s!';
