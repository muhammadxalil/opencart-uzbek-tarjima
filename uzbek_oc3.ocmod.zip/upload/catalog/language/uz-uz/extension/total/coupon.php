<?php

$_['heading_title'] = 'Kuponni ishlatish';

// Text
$_['text_coupon']   = 'Kupon (%s)';
$_['text_success']  = 'Chegirma kuponi muvaffaqiyatli foydalanildi!';

// Entry
$_['entry_coupon']  = 'Kupon kodini kiriting';

// Error
$_['error_coupon']  = 'Xatolik. Chegirma kuponi kodi noto\'g\'ri. Ehtimol yaroqlilik muddati o\'tgan yoki ishlatilish limitiga yetgan!';
$_['error_empty']   = 'Diqqat! Kupon kodini kiriting';


