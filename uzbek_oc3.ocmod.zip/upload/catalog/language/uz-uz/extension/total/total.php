<?php
$_['text_total'] = 'Umumiy miqdor';

