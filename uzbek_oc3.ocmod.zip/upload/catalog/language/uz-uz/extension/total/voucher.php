<?php
// Heading
$_['heading_title'] = 'Sovg\'a sertifikatidan foydalanish';

// Text
$_['text_voucher']  = 'Sovg\'a sertifikati (%s)';
$_['text_success']  = 'Sovg‘a sertifikatingiz muvaffaqiyatli qo‘llandi!';

// Entry
$_['entry_voucher'] = 'Sovg\'a sertifikati kodini kiriting';

// Error
$_['error_voucher'] = 'Xatolik. Noto\'g\'ri sovg\'a vaucher kodi yoki ushbu sertifikat allaqachon ishlatilgan!';
$_['error_empty']   = 'Diqqat: Sertifikat kodini kiriting!';

