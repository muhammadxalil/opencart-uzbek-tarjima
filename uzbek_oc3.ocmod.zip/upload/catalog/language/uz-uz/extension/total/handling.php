<?php
$_['text_handling'] = 'Buyurtmani ko\'rib chiqish uchun to\'lov';

