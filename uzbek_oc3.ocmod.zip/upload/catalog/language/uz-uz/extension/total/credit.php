<?php
$_['text_credit']   = 'Do\'kon krediti';
$_['text_order_id'] = 'Buyurtma raqami: %s';

