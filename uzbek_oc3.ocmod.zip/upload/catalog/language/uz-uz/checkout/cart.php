<?php
// Heading
$_['heading_title']    = 'Savat';

// Text
$_['text_success']     = '<a href="%s">%s</a> qo\'shildi <a href="%s">xarid qilish savatiga</a>!';
$_['text_remove']      = 'Savat almashtirildi!';
$_['text_login']       = 'Narxlarni ko\'rish uchun <a href="%s"> kirish </a> yoki <a href="%s"> hisob yaratish </a> kerak!';
$_['text_items']       = 'Mahsulotlar %s  (%s)';
$_['text_points']      = 'Bonus ballari: %s';
$_['text_next']        = 'Keyin nima qilmoqchisiz?';
$_['text_next_choice'] = 'Agar sizda chegirmali kupon kodi yoki sotib olmoqchi bo\'lgan bonus ballaringiz bo\'lsa, iltimos, quyida keltirilgan tegishli narsani tanlang. Shuningdek, mintaqangizga etkazib berish narxini taxminan bilib olishingiz mumkin.';
$_['text_empty']       = 'Savatingiz bo\'sh!';
$_['text_day']         = 'kun';
$_['text_week']        = 'hafta';
$_['text_semi_month']  = 'yarim oy';
$_['text_month']       = 'oy';
$_['text_year']        = 'yil';
$_['text_trial']       = 'Стоимость: %s; Периодичность: %s %s; Кол-во платежей: %s; Далее, ';
$_['text_recurring']   = 'Стоимость: %s; Периодичность: %s %s';
$_['text_length']      = ' Кол-во платежей: %s';
$_['text_until_cancelled']   	= 'до отмены';
$_['text_recurring_item']    	              = 'Периодические платежи';
$_['text_payment_recurring']                    = 'Платежный профиль';
$_['text_trial_description'] 	              = 'Стоимость: %s; Периодичность: %d %s; Кол-во платежей: %d;  Далее,  ';
$_['text_payment_description'] 	              = 'Стоимость: %s; Периодичность: %d %s; Кол-во платежей: %d';
$_['text_payment_until_canceled_description'] = 'Стоимость: %s; Периодичность: %d %s; Кол-во платежей: до отмены';

// Column
$_['column_image']          = 'Rasm';
$_['column_name']           = 'Ism';
$_['column_model']          = 'Model';
$_['column_quantity']       = 'Miqdori';
$_['column_price']          = 'Bir dona narxi.';
$_['column_total']          = 'Jami';

// Error
$_['error_stock']            = 'Товары отмеченные *** отсутствуют в нужном количестве или их нет на складе!';
$_['error_minimum']          = 'Минимальное количество для заказа товара %s составляет %s!';
$_['error_required']         = '%s обязательно!';
$_['error_product']          = 'В вашей корзине нет товаров!';
$_['error_recurring_required'] = 'Пожалуйста, выберите периодичность платежа!';
