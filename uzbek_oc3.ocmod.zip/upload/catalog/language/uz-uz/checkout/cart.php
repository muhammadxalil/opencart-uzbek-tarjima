<?php
// Heading
$_['heading_title']    = 'Xaridlar savatchasi';

// Text
$_['text_success']     = '<a href="%s">%s</a> xaridlar savatchasiga <a href="%s">qo\'shildi</a>!';
$_['text_remove']      = 'Xaridlar savatchasi o\'zgartirildi!';
$_['text_login']       = 'Avtorizatsiyadan <a href="%s">o\'tish zarur</a> yoki <a href="%s">hisob qaydnomasini </a> narxlarni ko\'rish uchun yarating!';
$_['text_items']       = 'Tovarlar %s  (%s)';
$_['text_points']      = 'Mukofot ballari: %s';
$_['text_next']        = 'Keyinchalik nima qilishni xohlaysiz?';
$_['text_next_choice'] = 'Agar sizda foydalanmoqchi bo\'lgan chegirma kupon kodi yoki bonus ballari bo\'lsa, quyida keltirilgan tegishli bandni tanlang. Shuningdek, siz mintaqangizga yetkazib berish narxini taxminan bilib olishingiz mumkin.';
$_['text_empty']       = 'Savatcha bo\'sh!';
$_['text_day']         = 'kun';
$_['text_week']        = 'haftani';
$_['text_semi_month']  = 'yarim oylik';
$_['text_month']       = 'oy';
$_['text_year']        = 'yil';
$_['text_trial']       = 'Narxi: %s; Davriylik: %s %s; To\'lovlar soni: %s; Keyingisi, ';
$_['text_recurring']   = 'Narxi: %s; Davriylik: %s %s';
$_['text_length']      = 'To\'lovlar soni: %s';
$_['text_until_cancelled']   	= 'bekor qilinguncha';
$_['text_recurring_item']    	              = 'Takroriy to\'lovlar';
$_['text_payment_recurring']                    = 'Hisob-kitob profili';
$_['text_trial_description'] 	              = 'Narxi: %s; Davriylik: %d %s; To\'lovlar soni: %d;  Keyingisi,  ';
$_['text_payment_description'] 	              = 'Narxi: %s; Davriylik: %d %s; To\'lovlar soni: %d';
$_['text_payment_until_canceled_description'] = 'Narxi: %s; Davriylik: %d %s; To\'lovlar soni: bekor qilinguncha';

// Column
$_['column_image']          = 'Rasm';
$_['column_name']           = 'Nomi';
$_['column_model']          = 'Model';
$_['column_quantity']       = 'Miqdori';
$_['column_price']          = 'Donasining narxi.';
$_['column_total']          = 'Jami';

// Error
$_['error_stock']            = '*** bilan belgilangan mahsulotlar kerakli miqdorda mavjud emas yoki omborda mavjud emas!';
$_['error_minimum']          = '%s tovarga buyurtma berishning minimal miqdori - %s!';
$_['error_required']         = '%s majburiy!';
$_['error_product']          = 'Savatchangizda mahsulot yo\'q!';
$_['error_recurring_required'] = 'Iltimos, to\'lov davriyligini tanlang!';
