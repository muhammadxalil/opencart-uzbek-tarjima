<?php
// Heading
$_['heading_title']										= 'Buyurtma';

// Text
$_['text_cart']												= 'Savatcha';
$_['text_checkout_option']							= 'Шаг %s: Способ оформления заказа';
$_['text_checkout_account']						= 'Шаг %s: Профиль &amp; Платежная информация';
$_['text_checkout_payment_address']			= 'Шаг %s: Платежная информация';
$_['text_checkout_shipping_address']			= 'Шаг %s: Адрес доставки';
$_['text_checkout_shipping_method']			= 'Шаг %s: Способ доставки';
$_['text_checkout_payment_method']			= 'Шаг %s: Способ оплаты';
$_['text_checkout_confirm']							= 'Шаг 6: Подтверждение заказа';
$_['text_modify']											= 'Изменить &raquo;';
$_['text_new_customer']								= 'Yangi mijoz';
$_['text_returning_customer']						= 'Ro\'yxatdan o\'tgan foydalanuvchi';
$_['text_checkout']										= 'To\'lov variantlari';
$_['text_i_am_returning_customer']				= 'Я совершал здесь покупки ранее и регистрировался';
$_['text_register']										= 'Ro\'yhatdan o\'tish';
$_['text_guest']											= 'Ro\'yxatdan o\'tmasdan to\'lov';
$_['text_register_account']							= 'Hisob qaydnomasini yaratish sizga tezroq va qulay xaridlarni amalga oshirishga, shuningdek doimiy mijoz sifatida chegirmalar olishga yordam beradi.';
$_['text_forgotten']										= 'Parolni unutdingizmi?';
$_['text_your_details']									= 'Shaxsiy ma\'lumotlar';
$_['text_your_address']								= 'Manzil';
$_['text_your_password']							= 'Parol';
$_['text_agree']											= 'Men o\'qidim <a href="%s" class="agree"><b>%s</b></a> va shartlari bilan roziman';
$_['text_address_new']								= 'Men yangi manzildan foydalanmoqchiman';
$_['text_address_existing']							= 'Mavjud manzildan foydalanmoqchiman';
$_['text_shipping_method']							= 'Ushbu buyurtma uchun qulay etkazib berish usulini tanlang';
$_['text_payment_method']							= 'Ushbu buyurtma uchun to\'lov usulini tanlang';
$_['text_comments']									= 'Siz buyurtmangizga sharh qo\'shishingiz mumkin';
$_['text_recurring']										= 'Takroriy to\'lovlar';
$_['text_payment_recurring']						= 'To\'lov profili';
$_['text_trial_description']							= 'Стоимость: %s; Периодичность: %d %s; Кол-во платежей: %d;  Далее,  ';
$_['text_payment_description']					= 'Стоимость: %s; Периодичность: %d %s; Кол-во платежей: %d';
$_['text_payment_until_canceled_description']		= 'Стоимость: %s; Периодичность: %d %s; Кол-во платежей: до отмены';

$_['text_day']					= 'kun';
$_['text_week']				= 'hafta';
$_['text_semi_month']	= 'yarim oy';
$_['text_month']				= 'oy';
$_['text_year']				= 'yil';

// Column
$_['column_name']			= 'Mahsulot nomi';
$_['column_model']		= 'Model';
$_['column_quantity']		= 'Miqdori';
$_['column_price']			= 'Narx';
$_['column_total']			= 'Jami';

// Entry
$_['entry_email_address']			= 'Elektron pochta manzili';
$_['entry_email']							= 'E-Mail';
$_['entry_password']					= 'Parol';
$_['entry_confirm']						= 'Parolni tasdiqlash';
$_['entry_firstname']					= 'Ism';
$_['entry_lastname']					= 'Familiya';
$_['entry_telephone']					= 'Telefon';
$_['entry_fax']							= 'Faks';
$_['entry_address']						= 'Manzilni tanlang';
$_['entry_company']					= 'Kompaniya';
$_['entry_customer_group']			= 'Biznes turi';
$_['entry_address_1']					= 'Manzil';
$_['entry_address_2']					= 'Manzil 2';
$_['entry_postcode']					= 'Indeks';
$_['entry_city']							= 'Shahar';
$_['entry_country']						= 'Mamlakat';
$_['entry_zone']							= 'Tuman / Shahar';
$_['entry_newsletter']					= 'Yangiliklarga obuna bo\'lmoqchiman %s .';
$_['entry_shipping']					= 'Mening etkazib berish manzilim mening to\'lov manzilim bilan bir xil.';

// Error
$_['error_warning']						= 'Возникла проблема при обработке Вашего заказа! Если проблема возникает повторно, попробуйте выбрать другой способ оплаты или <a href="%s">свяжитесь с администратором магазина</a>.';
$_['error_login']							= 'Ошибка: Неправильный E-Mail и/или пароль.';
$_['error_attempts']					= 'Вы превысили максимальное количество попыток авторизации. Повторите попытку авторизации на сайте через 1 час';
$_['error_approved']					= 'Прежде чем Вы сможете войти, администрация должна одобрить Ваш аккаунт.';
$_['error_exists']						= 'Ошибка: данный E-Mail адрес уже зарегистрирован!';
$_['error_firstname']					= 'Имя должно быть от 1 до 32 символов!';
$_['error_lastname']					= 'Фамилия должна быть от 1 до 32 символов!';
$_['error_email']							= 'Е-mail адрес введён неверно!';
$_['error_telephone']					= 'Номер телефона должен быть от 3 до 32 символов!';
$_['error_password']					= 'Пароль должен быть от 4 до 20 символов!';
$_['error_confirm']						= 'Пароли не совпадают!';
$_['error_address_1']					= 'Адрес должен быть от 3 до 128 символов!';
$_['error_city']							= 'Название города должно быть от 2 до 128 символов!';
$_['error_postcode']					= 'Индекс должен быть от 2 до 10 символов!';
$_['error_country']						= 'Пожалуйста, выберите страну!';
$_['error_zone']							= 'Пожалуйста, выберите регион / область';
$_['error_agree']							= 'Вы должны прочитать и согласится с %s!';
$_['error_address']						= 'Необходимо указать адрес!';
$_['error_shipping']						= 'Необходимо указать способ доставки!';
$_['error_no_shipping']				= 'Нет доступных способов доставки. Пожалуйста <a href="%s">свяжитесь с администрацией</a>!';
$_['error_payment']						= 'Необходимо указать способ оплаты!';
$_['error_no_payment']				= 'Нет доступных способов оплаты. Пожалуйста <a href="%s">свяжитесь с администрацией</a>!';
$_['error_custom_field']				= '%s обязательно!';
$_['error_custom_field_validate']	= '%s не корректное!';
