<?php
// Heading
$_['heading_title']										= 'Buyurtmani rasmiylashtirish';

// Text
$_['text_cart']												= 'Xaridlar savati';
$_['text_checkout_option']							= '%s qadam: Buyurtmani rasmiylashtirish usuli';
$_['text_checkout_account']						= '%s qadam: Profil &amp; To\'lov ma\'lumoti';
$_['text_checkout_payment_address']			= '%s qadam: To\'lov ma\'lumoti';
$_['text_checkout_shipping_address']			= '%s qadam: Yetkazib berish manzili';
$_['text_checkout_shipping_method']			= '%s qadam: Yetkazib berish usuli';
$_['text_checkout_payment_method']			= '%s qadam: To\'lov usuli';
$_['text_checkout_confirm']							= 'Qadam 6: Buyurtmani tasdiqlash';
$_['text_modify']											= 'O\'zgartirish &raquo;';
$_['text_new_customer']								= 'Yangi xaridor';
$_['text_returning_customer']						= 'Ro\'yxatdan o\'tgan foydalanuvchi';
$_['text_checkout']										= 'Buyurtmani rasmiylashtirish variantlari';
$_['text_i_am_returning_customer']				= 'Men bu yerda avval xaridlar qilganman va ro\'yxatdan o\'tganman';
$_['text_register']										= 'Ro\'yxatdan o\'tish';
$_['text_guest']											= 'Ro\'yxatdan o\'tmasdan rasmiylashtirish';
$_['text_register_account']							= 'Hisob qaydnomasini yaratish xaridlarni tezroq va qulayroq qilishga, shuningdek doimiy mijoz sifatida chegirmalar olishga yordam beradi.';
$_['text_forgotten']										= 'Parolni unutdingizmi?';
$_['text_your_details']									= 'Shaxsiy ma\'lumotlar';
$_['text_your_address']								= 'Manzil';
$_['text_your_password']							= 'Parol';
$_['text_agree']											= 'Men <a href="%s" class="agree"><b>%s</b></a> ni o\'qib chiqdim va shartlarga roziman';
$_['text_address_new']								= 'Men yangi manzildan foydalanmoqchiman';
$_['text_address_existing']							= 'Men mavjud manzildan foydalanmoqchiman';
$_['text_shipping_method']							= 'Ushbu buyurtma uchun qulay yetkazib berish usulini tanlang.';
$_['text_payment_method']							= 'Ushbu buyurtma uchun to\'lov usulini tanlang.';
$_['text_comments']									= 'Siz buyurtmangizga sharh qo\'shishingiz mumkin.';
$_['text_recurring']										= 'Davriy to\'lovlar';
$_['text_payment_recurring']						= 'Hisob-kitob profili';
$_['text_trial_description']							= 'Narxi: %s; Davriyligi: %d %s; To\'lovlar soni: %d;  Keyingi,  ';
$_['text_payment_description']					= 'Narxi: %s; Davriyligi: %d %s; To\'lovlar soni: %d';
$_['text_payment_until_canceled_description']		= 'Narxi: %s; Davriyligi: %d %s; To\'lovlar soni: bekor qilinguncha';

$_['text_day']					= 'kun';
$_['text_week']				= 'hafta';
$_['text_semi_month']	= 'yarim oy';
$_['text_month']				= 'oy';
$_['text_year']				= 'yil';

// Column
$_['column_name']			= 'Mahsulot nomi';
$_['column_model']		= 'Model';
$_['column_quantity']		= 'Soni';
$_['column_price']			= 'Narxi';
$_['column_total']			= 'Jami';

// Entry
$_['entry_email_address']			= 'E-Mail Manzil';
$_['entry_email']							= 'E-Mail';
$_['entry_password']					= 'Parol';
$_['entry_confirm']						= 'Parolni tasdiqlash';
$_['entry_firstname']					= 'Ism';
$_['entry_lastname']					= 'Familiya';
$_['entry_telephone']					= 'Telefon raqami';
$_['entry_fax']							= 'Faks';
$_['entry_address']						= 'Manzilni tanlang';
$_['entry_company']					= 'Kompaniya';
$_['entry_customer_group']			= 'Biznes turi';
$_['entry_address_1']					= 'Manzil';
$_['entry_address_2']					= 'Manzil 2';
$_['entry_postcode']					= 'Indeks';
$_['entry_city']							= 'Shahar';
$_['entry_country']						= 'Mamlakat';
$_['entry_zone']							= 'Tuman / Viloyat';
$_['entry_newsletter']					= 'Men %s yangiliklariga obuna bo\'lmoqchiman.';
$_['entry_shipping']					= 'Mening yetkazib berish manzilim to\'lov manzilimga mos emas.';

// Error
$_['error_warning']						= 'Buyurtmani qayta ishlashda muammo yuz berdi! Agar muammo davom etsa, boshqa to\'lov usulini tanlang yoki <a href="%s"> do\'kon ma\'muriga murojaat qiling </a>.';
$_['error_login']							= 'Xatolik: Noto\'g\'ri elektron pochta va / yoki parol.';
$_['error_attempts']					= 'Siz avtorizatsiya qilish urinishlarining maksimal miqdoridan oshib ketdingiz. 1 soatdan keyin saytda avtorizatsiyani qayta urinib ko\'ring';
$_['error_approved']					= 'Tizimga kirishdan oldin ma\'muriyat sizning hisobingizni tasdiqlashi kerak.';
$_['error_exists']						= 'Xatolik: ushbu elektron pochta allaqachon ro\'yxatdan o\'tgan!';
$_['error_firstname']					= 'Ism 1-32 belgidan iborat bo\'lishi kerak!';
$_['error_lastname']					= 'Familiya 1-32 belgidan iborat bo\'lishi kerak!';
$_['error_email']							= 'Elektron pochta manzili noto\'g\'ri kiritilgan!';
$_['error_telephone']					= 'Telefon raqami 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_password']					= 'Parol 4 tadan 20 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_confirm']						= 'Parol va tasdiqlash paroli bir-biriga mos kelmadi!';
$_['error_address_1']					= 'Manzil 3-128 belgidan iborat bo\'lishi kerak!';
$_['error_city']						= 'Shahar nomi 2 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_postcode']					= 'Pochta indeksi 2 tadan 10 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_country']						= 'Iltimos, mamlakatni tanlang!';
$_['error_zone']						= 'Iltimos, tuman / viloyatni tanlang!';
$_['error_agree']						= 'Siz %s ni o\'qib chiqib, unga rozi bo\'lishingiz kerak!';
$_['error_address']						= 'Manzilni kiritish shart!';
$_['error_shipping']					= 'Yetkazib berish usulini ko\'rsatishingiz kerak!';
$_['error_no_shipping']				    = 'Yetkazib berish usullari mavjud emas. Iltimos, <a href="%s"> ma\'muriyat bilan bog\'laning </a>!';
$_['error_payment']						= 'To\'lov usulini ko\'rsatishingiz kerak!';
$_['error_no_payment']				    = 'To\'lov usullari mavjud emas. Iltimos, <a href="%s"> ma\'muriyat bilan bog\'laning </a>!';
$_['error_custom_field']				= '%s majburiy!';
$_['error_custom_field_validate']	= '%s noto\'g\'ri!';
