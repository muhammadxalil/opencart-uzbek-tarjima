<?php
// Heading
$_['heading_title'] = 'To\'lov xatosi!';

// Text
$_['text_basket']   = 'Xaridlar savatchasi';
$_['text_checkout'] = 'Buyurtmani rasmiylashtirish';
$_['text_failure']  = 'To\'lov xatosi';
$_['text_message']  = '<p>To\'lov jarayonida xatolik yuz berdi. Xatolik tufayli to\'lovni yakunlab bo\'lmadi</p><p>Ehtimolli sabablar:</p><ul><li>Mablag\' yetarli emas</li><li>Tekshirishda xatolik</li></ul> <p>Iltimos, boshqa to\'lov usulini tanlab qayta urinib ko\'ring.</p><p>Agar xato qaytarilsa, iltimos <a href="%s">ma\'muriyatga murojaat qiling</a> va buyurtma tafsilotlarini taqdim eting.</p>';

