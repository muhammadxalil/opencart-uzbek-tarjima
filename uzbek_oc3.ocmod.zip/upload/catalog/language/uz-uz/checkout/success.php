<?php
// Heading
$_['heading_title']        = 'Sizning buyurtmangiz qabul qilindi!';

// Text
$_['text_basket']          = 'Savat';
$_['text_checkout']        = 'Buyurtma berish';
$_['text_success']         = 'Buyurtma qabul qilindi';
$_['text_customer']        = '<p>Buyurtmangiz qabul qilindi!</p><p>Buyurtma tarixi ushbu <a href="%s">Shaxsiy kabinetda</a>. Tarixni ko\'rish uchun havolani bosing <a href="%s">Buyurtmalar tarixi</a>.</p><p>Agar xaridingiz raqamli tovarlar bilan bog\'liq bo\'lsa, sahifaga o\'ting <a href="%s">Yuklab olish uchun fayllarga</a> ko\'rish yoki yuklab olish uchun.</p><p>Savollaringiz bo\'lsa, iltimos <a href="%s">biz bilan bog\'laning</a>.</p><p>Internet do\'konimizda xarid qilganingiz uchun tashakkur!</p>';
$_['text_guest']           = '<p>Sizning buyurtmangiz qabul qilindi!</p><p>Savollaringiz bo\'lsa, iltimos <a href="%s">biz bilan bog\'laning</a>.</p><p>Internet do\'konimizda xarid qilganingiz uchun tashakkur!</p>';
