<?php
// Heading
$_['heading_title']    = 'Sayt xaritasi';

// Text
$_['text_special']     = 'Aksiyalar';
$_['text_account']     = 'Shaxsiy kabinet';
$_['text_edit']        = 'Shaxsiy ma\'lumot';
$_['text_password']    = 'Parol';
$_['text_address']     = 'Mening manzillarim';
$_['text_history']     = 'Buyurtmalar tarixi';
$_['text_download']    = 'Yuklash uchun fayllar';
$_['text_cart']        = 'Savatcha';
$_['text_checkout']    = 'Buyurtmani tasdiqlash';
$_['text_search']      = 'Izlash';
$_['text_information'] = 'Ma\'lumot';
$_['text_contact']     = 'Bizning kontaktlar';

