<?php
// Heading
$_['heading_title']    = 'Sayt xaritasi';

// Text
$_['text_special']     = 'Aktsiyalar';
$_['text_account']     = 'Shaxsiy kabinet';
$_['text_edit']        = 'Shaxsiy ma\'lumot';
$_['text_password']    = 'Parol';
$_['text_address']     = 'Mening manzillarim';
$_['text_history']     = 'Buyurtmalar tarixi';
$_['text_download']    = 'Yuklash uchun fayllar';
$_['text_cart']        = 'Savat';
$_['text_checkout']    = 'Buyurtma';
$_['text_search']      = 'Qidirmoq';
$_['text_information'] = 'Ma\'lumot';
$_['text_contact']     = 'Bizning aloqalarimiz';

