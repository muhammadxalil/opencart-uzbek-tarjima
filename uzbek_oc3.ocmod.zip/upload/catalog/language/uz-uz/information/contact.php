<?php
// Heading
$_['heading_title']  = 'Qayta aloqa';

// Text
$_['text_location']  = 'Bizning joylashuvimiz';
$_['text_store']     = 'Bizning do\'konlarimiz';
$_['text_contact']   = 'Bizga yozing';
$_['text_address']   = 'Manzil';
$_['text_telephone'] = 'Telefon';
$_['text_fax']       = 'Faks';
$_['text_open']      = 'Ish tartibi';
$_['text_comment']   = 'Qo\'shimcha ma\'lumot';
$_['text_success']   = '<p>Sizning xabaringiz do\'kon egasiga muvaffaqiyatli yuborildi!</p>';
$_['button_submit']         = 'Xabar yubormoq';

// Entry
$_['entry_name']     = 'Sizning ismingiz';
$_['entry_email']    = 'Sizning elektron manzilingiz';
$_['entry_enquiry']  = 'Sizning savolingiz yoki xabaringiz';
$_['entry_captcha']  = 'Rasmda ko\'rsatilgan kodni kiriting';

// Email
$_['email_subject']  = 'Xabar %s';



// Errors
$_['error_name']     = 'Имя должно быть от 3 до 32 символов!';
$_['error_email']    = 'Elektron pochta manzili noto\'g\'ri kiritilgan!';
$_['error_enquiry']  = 'Matn uzunligi 10 dan 3000 gacha belgidan iborat bo\'lishi kerak!';
$_['error_captcha']  = 'Tasdiqlash kodi rasmga mos kelmaydi!';


