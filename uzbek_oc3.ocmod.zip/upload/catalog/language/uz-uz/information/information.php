<?php
// Text
$_['text_error'] = 'Ma\'lumotlar sahifasi topilmadi!';

