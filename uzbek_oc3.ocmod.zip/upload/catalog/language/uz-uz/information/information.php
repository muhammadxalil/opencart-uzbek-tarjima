<?php
// Text
$_['text_error'] = 'Ma\'lumot sahifasi topilmadi!';

