<?php
// Heading
$_['heading_title'] = 'So\'ralgan sahifa topilmadi!';

// Text
$_['text_error']    = 'Kechirasiz, siz so\'ragan sahifa topilmadi. Ehtimol siz mavjud bo\'lmagan manzilni ko\'rsatgansiz, sahifa o\'chirilgan, ko\'chirilgan yoki vaqtincha ishlamayapti!';

