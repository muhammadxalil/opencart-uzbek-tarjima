<?php
// Heading
$_['heading_title']  = 'Kalit so\'zni o\'zgartirish';

// Text
$_['text_account']   = 'Shaxsiy kabinet';
$_['text_password']  = 'Parolingiz';
$_['text_success']   = 'Parolingiz muvaffaqiyatli o\'zgartirildi!';

// Entry
$_['entry_password'] = 'Parol';
$_['entry_confirm']  = 'Parolni tasdiqlang';

// Error
$_['error_password'] = 'Parol 4 dan 20 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_confirm']  = 'Parollar va tasdiqlash paroli mos emas!';
