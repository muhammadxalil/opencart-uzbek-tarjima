<?php
// Heading
$_['heading_title']  = 'Parolni o\'zgartirish';

// Text
$_['text_account']   = 'Shaxsiy kabinet';
$_['text_password']  = 'Sizning parol';
$_['text_success']   = 'Sizning parolingiz muvaffaqiyatli o\'zgartirildi!';

// Entry
$_['entry_password'] = 'Parol';
$_['entry_confirm']  = 'Parolni tasdiqlang';

// Error
$_['error_password'] = 'Parol 4 tadan 20 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_confirm']  = 'Parol va parol tasdig\'i mos emas!';
