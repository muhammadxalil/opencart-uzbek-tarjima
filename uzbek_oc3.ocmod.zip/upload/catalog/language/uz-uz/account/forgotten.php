<?php
// Heading
$_['heading_title']   = 'Parolni unutdingizmi?';

// Text
$_['text_account']    = 'Shaxsiy kabinet';
$_['text_forgotten']  = 'Parolni unutdingizmi?';
$_['text_your_email'] = 'Sizning E-Mailingiz';
$_['text_email']      = 'Hisobingizning elektron pochtasini kiriting. Parolingizni elektron pochta orqali olish uchun Keyingi tugmasini bosing.';
$_['text_success']    = 'Elektron pochtangizga yangi parol yuborildi.';

// Entry
$_['entry_email']     = 'E-Mail';
$_['entry_password']  = 'Yangi parol';
$_['entry_confirm']   = 'Yangi parolni tasdiqlang';

// Error
$_['error_email']     = 'E-Mail адрес не найден, проверьте и попробуйте еще раз!';
$_['error_approved']  = 'Внимание! Ваш аккаунт еще не активирован.';
$_['error_password']  = 'Пароль должен быть от 4 до 20 символов!';
$_['error_confirm']   = 'Пароль и подтверждение пароля рзличны!';

