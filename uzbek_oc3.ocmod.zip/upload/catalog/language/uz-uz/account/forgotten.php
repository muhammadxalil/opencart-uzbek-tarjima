<?php
// Heading
$_['heading_title']   = 'Parolni unutdingizmi?';

// Text
$_['text_account']    = 'Shaxsiy kabinet';
$_['text_forgotten']  = 'Parolni unutdingizmi?';
$_['text_your_email'] = 'Sizning E-Mail';
$_['text_email']      = 'Hisob qaydnomangizning elektron pochta manzilini kiriting. Elektron pochta orqali parolni olish uchun "Oldinga" tugmasini bosing.';
$_['text_success']    = 'Sizning elektron pochtangizga yangi parol yuborildi.';

// Entry
$_['entry_email']     = 'E-Mail';
$_['entry_password']  = 'Yangi parol';
$_['entry_confirm']   = 'Yangi parolni tasdiqlang';

// Error
$_['error_email']     = 'Elektron pochta manzili topilmadi, tekshiring va qayta urinib ko\'ring!';
$_['error_approved']  = 'Diqqat! Sizning hisobingiz hali faollashtirilmagan.';
$_['error_password']  = 'Parol 4 tadan 20 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_confirm']   = 'Parol va parolni tasdiqlash boshqacha!';

