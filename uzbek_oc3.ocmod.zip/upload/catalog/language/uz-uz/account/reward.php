<?php
// Heading
$_['heading_title']      = 'Mukofot ballari';

// Column
$_['column_date_added']  = 'Qo\'shilgan';
$_['column_description'] = 'Ta\'rifi';
$_['column_points']      = 'Mukofot ballari';

// Text
$_['text_account']       = 'Shaxsiy kabinet';
$_['text_reward']        = 'Mukofot ballari';
$_['text_total']         = 'To\'plangan mukofot ballari';
$_['text_empty']         = 'Sizda mukofot ballari yo\'q!';

