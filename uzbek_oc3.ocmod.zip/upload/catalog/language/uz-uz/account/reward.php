<?php
// Heading
$_['heading_title']      = 'Bonus ballari';

// Column
$_['column_date_added']  = 'Qo\'shildi';
$_['column_description'] = 'Tavsif';
$_['column_points']      = 'Bonus ballari';

// Text
$_['text_account']       = 'Shaxsiy kabinet';
$_['text_reward']        = 'Bonus ballari';
$_['text_total']         = 'To\'plangan bonus ballari';
$_['text_empty']         = 'Sizda bonus ballari yo\'q!';

