<?php
// Heading
$_['heading_title']         = 'Buyurtmalar tarixi';

// Text
$_['text_account']          = 'Shaxsiy kabinet';
$_['text_order']            = 'Buyurtma';
$_['text_order_detail']     = 'Buyurtma tafsilotlari';
$_['text_invoice_no']       = '№ Hisoblar';
$_['text_order_id']         = '№ Buyurtma';
$_['text_date_added']       = 'Qo\'shildi';
$_['text_shipping_address'] = 'Yetkazib berish manzili';
$_['text_shipping_method']  = 'Yetkazib berish usuli';
$_['text_payment_address']  = 'Yetkazib berish usuli';
$_['text_payment_method']   = 'To\'lov usuli';
$_['text_comment']          = 'Buyurtmani sharhlang';
$_['text_history']          = 'Buyurtmalar tarixi';
$_['text_success']          = '<a href="%s"> %s </a> buyurtmasidagi narsalar <a href=" %s "> savatingizga </a> muvaffaqiyatli qo\'shildi!';
$_['text_empty']            = 'Siz hali hech qanday xarid qilmadingiz!';
$_['text_error']            = 'So\'ralgan buyurtma topilmadi!';

// Column
$_['column_order_id']       = '№ Buyurtma';
$_['column_product']        = 'Miqdori';
$_['column_customer']       = 'Mijoz';
$_['column_name']           = 'Mahsulot nomi';
$_['column_model']          = 'Model';
$_['column_quantity']       = 'Miqdori';
$_['column_price']          = 'Narx';
$_['column_total']          = 'Jami';
$_['column_action']         = 'Harakat';
$_['column_date_added']     = 'Qo\'shildi';
$_['column_status']         = 'Holat';
$_['column_comment']        = 'Izoh';

// Error
$_['error_reorder']         = '%s hozirda mavjud emas....';
