<?php
// Heading
$_['heading_title']         = 'Buyurtmalar tarixi';

// Text
$_['text_account']          = 'Shaxsiy kabinet';
$_['text_order']            = 'Buyurtma';
$_['text_order_detail']     = 'Buyurtma tafsilotlari';
$_['text_invoice_no']       = 'Hisob raqami';
$_['text_order_id']         = 'Buyurtma raqami';
$_['text_date_added']       = 'Qo\'shilgan';
$_['text_shipping_address'] = 'Yetkazib berish manzili';
$_['text_shipping_method']  = 'Yetkazib berish usuli';
$_['text_payment_address']  = 'To\'lov manzili';
$_['text_payment_method']   = 'To\'lov usuli';
$_['text_comment']          = 'Buyurtmani sharhlari';
$_['text_history']          = 'Buyurtmalar tarixi';
$_['text_success']          = '<a href="%s">%s</a> buyurtma mahsulotlari <a href="%s"> savatingizga muvaffaqiyatli qo\'shildi </a>!';
$_['text_empty']            = 'Siz hali hech narsa xarid qilmagansiz!';
$_['text_error']            = 'So\'ralgan buyurtma topilmadi!';

// Column
$_['column_order_id']       = 'Buyurtma raqami';
$_['column_product']        = 'Miqdori';
$_['column_customer']       = 'Xaridor';
$_['column_name']           = 'Mahsulot nomi';
$_['column_model']          = 'Model';
$_['column_quantity']       = 'Miqdori';
$_['column_price']          = 'Narxi';
$_['column_total']          = 'Jami';
$_['column_action']         = 'Harakat';
$_['column_date_added']     = 'Qo\'shilgan';
$_['column_status']         = 'Holati';
$_['column_comment']        = 'Sharh';

// Error
$_['error_reorder']         = '%s hozirda mavjud emas....';
