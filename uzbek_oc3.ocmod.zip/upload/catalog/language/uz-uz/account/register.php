<?php
// Heading
$_['heading_title']        = 'Ro\'yxatdan o\'tish';

// Text
$_['text_account']         = 'Shaxsiy kabinet';
$_['text_register']        = 'Ro\'yxatdan o\'tish';
$_['text_account_already'] = 'Agar siz allaqachon ro\'yxatdan o\'tgan bo\'lsangiz, <a href="%s"> kirish sahifasiga  o\'ting</a>.';
$_['text_your_details']    = 'Asosiy ma\'lumotlar';
$_['text_your_address']    = 'Sizning manzilingiz';
$_['text_newsletter']      = 'Axborot byulleteni';
$_['text_your_password']   = 'Sizning parolingiz';
$_['text_agree']           = 'Men <a href="%s" class="agree"><b>%s</b></a> ni o\'qib chiqdim va shartlarga roziman.';

// Entry
$_['entry_customer_group'] = 'Biznes yo\'nalishi';
$_['entry_firstname']      = 'Ism';
$_['entry_lastname']       = 'Familiya';
$_['entry_email']          = 'E-Mail';
$_['entry_telephone']      = 'Telefon raqami';
$_['entry_fax']            = 'Faks';
$_['entry_company']        = 'Kompaniya';
$_['entry_address_1']      = 'Manzil 1';
$_['entry_address_2']      = 'Manzil 2';
$_['entry_postcode']       = 'Indeks';
$_['entry_city']           = 'Shahar';
$_['entry_country']        = 'Mamlakat';
$_['entry_zone']           = 'Tuman / Viloyat';
$_['entry_newsletter']     = 'Yangiliklarga obuna bo\'lish';
$_['entry_password']       = 'Parol';
$_['entry_confirm']        = 'Parolni tasdiqlash';

// Error
$_['error_exists']         = 'Ushbu elektron pochta allaqachon ro\'yxatdan o\'tgan!';
$_['error_firstname']      = 'Ism 1-32 belgidan iborat bo\'lishi kerak!';
$_['error_lastname']       = 'Familiya 1-32 belgidan iborat bo\'lishi kerak!';
$_['error_email']          = 'Elektron pochta manzili noto\'g\'ri kiritilgan!';
$_['error_telephone']      = 'Telefon raqami 3 tadan 32 tagacha raqamdan iborat bo\'lishi kerak!';
$_['error_address_1']      = 'Manzil 3-128 belgidan iborat bo\'lishi kerak!';
$_['error_city']           = 'Shahar nomi 2 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_postcode']       = 'Pochta indeksi 2 tadan 10 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_country']        = 'Iltimos, mamlakatni tanlang!';
$_['error_zone']           = 'Iltimos, tuman / viloyatni tanlang!';
$_['error_custom_field']   = '%s to\'ldirilishi majburiy!';
$_['error_password']       = 'Parol 4 tadan 20 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_confirm']        = 'Parol va tasdiqlash paroli bir-biriga mos kelmadi!';
$_['error_agree']          = 'Diqqat. Siz %s ni o\'qib, unga rozi bo\'lishingiz kerak!';
