<?php
// Heading
$_['heading_title']        = 'Belgilanish';

// Text
$_['text_account']         = 'Shaxsiy kabinet';
$_['text_register']        = 'Belgilanish';
$_['text_account_already'] = 'Agar siz allaqachon ro\'yxatdan o\'tgan bo\'lsangiz, <a href="%s"> kirish sahifasiga </a> o\'ting.';
$_['text_your_details']    = 'Asosiy ma\'lumotlar';
$_['text_your_address']    = 'Sizning manzilingiz';
$_['text_newsletter']      = 'Axborot byulleteni';
$_['text_your_password']   = 'Parolingiz';
$_['text_agree']           = 'Men <a href="%s" class="agree"> <b> %s </b> </a> ni o\'qidim va shartlarga roziman';

// Entry
$_['entry_customer_group'] = 'Faoliyat yo\'nalishi';
$_['entry_firstname']      = 'Ism';
$_['entry_lastname']       = 'Familiya';
$_['entry_email']          = 'E-Mail';
$_['entry_telephone']      = 'Telefon';
$_['entry_fax']            = 'Faks';
$_['entry_company']        = 'Kompaniya';
$_['entry_address_1']      = 'Manzil 1';
$_['entry_address_2']      = 'Manzil 2';
$_['entry_postcode']       = 'Indeks';
$_['entry_city']           = 'Shahar';
$_['entry_country']        = 'Mamlakat';
$_['entry_zone']           = 'Tuman / Shahar';
$_['entry_newsletter']     = 'Yangiliklarga obuna bo\'ling';
$_['entry_password']       = 'Parol';
$_['entry_confirm']        = 'Parolni tasdiqlash';

// Error
$_['error_exists']         = 'Данный E-Mail уже зарегистрирован!';
$_['error_firstname']      = 'Имя должно быть от 1 до 32 символов!';
$_['error_lastname']       = 'Фамилия должна быть от 1 до 32 символов!';
$_['error_email']          = 'E-Mail введен неправильно!';
$_['error_telephone']      = 'Телефон должен быть от 3 до 32 цифр!';
$_['error_address_1']      = 'Адрес должен быть от 3 до 128 символов!';
$_['error_city']           = 'Название города должно быть от 2 до 128 символов!';
$_['error_postcode']       = 'Индекс должен быть от 2 до 10 символов!';
$_['error_country']        = 'Выберите страну!';
$_['error_zone']           = 'Выберите регион / область!';
$_['error_custom_field']   = '%s обязательно к заполнению!';
$_['error_password']       = 'В пароле должно быть от 4 до 20 символов!';
$_['error_confirm']        = 'Пароли и пароль подтверждения не совпадают!';
$_['error_agree']          = 'Вы должны прочитать и согласится с %s!';
