<?php
// Heading
$_['heading_title']     = 'Yuklab olish uchun fayllar';


// Text
$_['text_account']      = 'Shaxsiy kabinet';
$_['text_downloads']    = 'Yuklab olish uchun fayllar';
$_['text_empty']        = 'Sizda fayllarni yuklab olish uchun buyurtmalar yo\'q!';

// Column
$_['column_order_id']   = 'Buyurtma raqami';
$_['column_name']       = 'Nomi';
$_['column_size']       = 'O\'lchami';
$_['column_date_added'] = 'Qo\'shilgan sanasi';
