<?php
// Heading
$_['heading_title']     = 'Yuklamalar';


// Text
$_['text_account']      = 'Shaxsiy kabinet';
$_['text_downloads']    = 'Yuklamalar';
$_['text_empty']        = 'Yuklab olish uchun fayllar bilan buyurtmalaringiz yo\'q!';

// Column
$_['column_order_id']   = '№ Buyurtma';
$_['column_name']       = 'Ism';
$_['column_size']       = 'Hajmi';
$_['column_date_added'] = 'Qo\'shilgan sana';
