<?php
// Heading
$_['heading_title']    = 'Yangiliklarga obuna bo\'lish';

// Text
$_['text_account']     = 'Shaxsiy kabinet';
$_['text_newsletter']  = 'Yangiliklar byulleteni';
$_['text_success']     = 'Sizning obunangiz muvaffaqiyatli yangilandi!';

// Entry
$_['entry_newsletter'] = 'Obuna bo\'lish';


