<?php
// Heading
$_['heading_title']    = 'Yangiliklarga obuna bo\'ling';

// Text
$_['text_account']     = 'Shaxsiy kabinet';
$_['text_newsletter']  = 'Axborot byulleteni';
$_['text_success']     = 'Obunangiz muvaffaqiyatli yangilandi!';

// Entry
$_['entry_newsletter'] = 'Obuna bo\'lish';


