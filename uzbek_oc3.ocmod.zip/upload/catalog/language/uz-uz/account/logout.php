<?php
// Heading
$_['heading_title'] = 'Chiqish';

// Text
$_['text_message']  = '<p> Siz Shaxsiy hisobingizdan chiqdingiz. </p> <p> Savatingiz saqlandi. Shaxsiy hisobingizga keyingi kirish paytida u tiklanadi. </p>';
$_['text_account']  = 'Shaxsiy kabinet';
$_['text_logout']   = 'Chiqish';

