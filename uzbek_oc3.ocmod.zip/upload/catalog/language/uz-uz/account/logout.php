<?php
// Heading
$_['heading_title'] = 'Chiqish';

// Text
$_['text_message']  = '<p>Siz shaxsiy kabinetdan chiqdingiz.</p><p>Savatingiz saqlandi. Keyingi safar hisobingizga kirganingizda, u tiklanadi.</p>';
$_['text_account']  = 'Shaxsiy kabinet';
$_['text_logout']   = 'Chiqish';

