<?php
// Heading
$_['heading_title']        = 'Mening manzillarim';


// Text
$_['text_account']         = 'Shaxsiy kabinet';
$_['text_address_book']    = 'Yetkazib berish manzillari ro\'yxati';
$_['text_edit_address']    = 'Manzilni tahrirlash';
$_['text_add']             = 'Sizning manzilingiz muvaffaqiyatli qo\'shildi.';
$_['text_edit']            = 'Sizning manzilingiz muvaffaqiyatli o\'zgartirildi';
$_['text_delete']          = 'Sizning manzilingiz muvaffaqiyatli o\'chirildi.';
$_['text_empty']           = 'Hisob qaydnomasidagi manzillar ro\'yxati bo\'sh.';

// Entry
$_['entry_firstname']      = 'Ism, Otasining ismi';
$_['entry_lastname']       = 'Familiya';
$_['entry_company']        = 'Kompaniya';
$_['entry_address_1']      = 'Manzil 1';
$_['entry_address_2']      = 'Manzil 2';
$_['entry_postcode']       = 'Pochta indeksi';
$_['entry_city']           = 'Shahar';
$_['entry_country']        = 'Mamlakat';
$_['entry_zone']           = 'Tuman / Viloyat';
$_['entry_default']        = 'Asosiy manzil';

// Error
$_['error_delete']         = 'Siz kamida 1 manzilni kiritishingiz kerak!';
$_['error_default']        = 'Siz asosiy manzilni o\'chira olmaysiz!';
$_['error_firstname']      = 'Ism 1 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_lastname']       = 'Familiya 1 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_vat']            = 'Noto\'g\'ri indeks!';
$_['error_address_1']      = 'Manzil 3 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_postcode']       = 'Pochta indeksi 2 tadan 10 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_city']           = 'Shahar nomi 2 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_country']        = 'Iltimos, mamlakatni ko\'rsating!';
$_['error_zone']           = 'Iltimos, Tuman / Viloyatni ko\'rsating!';
$_['error_custom_field']   = '%s shart!';
$_['error_custom_field_validate'] = '%s xato!';
