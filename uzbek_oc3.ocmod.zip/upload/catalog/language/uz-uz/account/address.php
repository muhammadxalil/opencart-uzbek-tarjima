<?php
// Heading
$_['heading_title']        = 'Mening manzillarim';


// Text
$_['text_account']         = 'Shaxsiy kabinet';
$_['text_address_book']    = 'Yetkazib berish manzili ro\'yxati';
$_['text_edit_address']    = 'Manzilni tahrirlash';
$_['text_add']             = 'Sizning manzilingiz muvaffaqiyatli qo\'shildi';
$_['text_edit']            = 'Sizning manzilingiz muvaffaqiyatli o\'zgartirildi';
$_['text_delete']          = 'Sizning manzilingiz o\'chirildi';
$_['text_empty']           = 'Hisobdagi manzillar ro\'yxati bo\'sh.';

// Entry
$_['entry_firstname']      = 'Ism';
$_['entry_lastname']       = 'Familiya';
$_['entry_company']        = 'Kompaniya';
$_['entry_address_1']      = 'Manzil';
$_['entry_address_2']      = 'Manzil 2';
$_['entry_postcode']       = 'Pochta indeksi';
$_['entry_city']           = 'Shahar';
$_['entry_country']        = 'Mamlakat';
$_['entry_zone']           = 'Viloyat';
$_['entry_default']        = 'Asosiy manzil';

// Error
$_['error_delete']         = 'Вы должны добавить не менее 1 адреса!';
$_['error_default']        = 'Вы не можете удалить основной адрес!';
$_['error_firstname']      = 'Имя должно быть от 1 до 32 символов!';
$_['error_lastname']       = 'Фамилия должна быть от 1 до 32 символов!';
$_['error_vat']            = 'Неверный индекс!';
$_['error_address_1']      = 'Адрес должен быть от 3 до 128 символов!';
$_['error_postcode']       = 'Индекс должен быть от 2 до 10 символов!';
$_['error_city']           = 'Название города должно быть от 2 до 128 символов!';
$_['error_country']        = 'Пожалуйста, укажите страну!';
$_['error_zone']           = 'Пожалуйста, укажите регион / область!';
$_['error_custom_field']   = '%s необходим!';
$_['error_custom_field_validate'] = '%s неверный!';
