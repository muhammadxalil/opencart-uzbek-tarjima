<?php
// Heading
$_['heading_title']      = 'Bitimlar tarixi';

// Column
$_['column_date_added']  = 'Qo\'shilgan';
$_['column_description'] = 'Ta\'rif';
$_['column_amount']      = 'Miqdor (%s)';

// Text
$_['text_account']       = 'Shaxsiy kabinet';
$_['text_transaction']   = 'Sizning tranzaksiyalaringiz';
$_['text_total']         = 'Sizning joriy balansingiz';
$_['text_empty']         = 'Sizda hech qanday tranzaksiya yo\'q!';

