<?php
// Heading
$_['heading_title']      = 'Tranzaksiyalar tarixi';

// Column
$_['column_date_added']  = 'Qo\'shildi';
$_['column_description'] = 'Tavsif';
$_['column_amount']      = 'Miqdor (%s)';

// Text
$_['text_account']       = 'Shaxsiy kabinet';
$_['text_transaction']   = 'Sizning operatsiyalaringiz';
$_['text_total']         = 'Sizning joriy balansingiz';
$_['text_empty']         = 'Sizda bitimlar bo\'lmagan!';

