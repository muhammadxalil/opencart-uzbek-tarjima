<?php
// Heading
$_['heading_title']      = 'Hisob qaydnomasi';


// Text
$_['text_account']       = 'Shaxsiy kabinet';
$_['text_edit']          = 'Ma\'lumotni tahrirlash';
$_['text_your_details']  = 'Sizning hisob qaydnomangiz';
$_['text_success']       = 'Sizning hisob qaydnomangiz muvaffaqiyatli yangilandi!';

// Entry
$_['entry_firstname']    = 'Ism, Otasining ismi';
$_['entry_lastname']     = 'Familiya';
$_['entry_email']        = 'E-Mail';
$_['entry_telephone']    = 'Telefon';
$_['entry_fax']          = 'Faks';

// Error
$_['error_exists']       = 'Ushbu elektron pochta allaqachon ro\'yxatdan o\'tgan!';
$_['error_firstname']    = 'Ism 1 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_lastname']     = 'Familiya 1 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_email']        = 'E-Mail адрес введен неверно!';
$_['error_telephone']    = 'Telefon raqami 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_custom_field'] = '%s zarur!';
$_['error_custom_field_validate'] = '%s xato!';
