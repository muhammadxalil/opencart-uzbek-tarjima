<?php
// Heading
$_['heading_title']      = 'Qayd yozuvi';


// Text
$_['text_account']       = 'Shaxsiy kabinet';
$_['text_edit']          = 'Ma\'lumotni tahrirlash';
$_['text_your_details']  = 'Sizning hisob qaydnomangiz';
$_['text_success']       = 'Sizning hisobingiz muvaffaqiyatli yangilandi!';

// Entry
$_['entry_firstname']    = 'Ism';
$_['entry_lastname']     = 'Familiya';
$_['entry_email']        = 'E-Mail';
$_['entry_telephone']    = 'Telefon';
$_['entry_fax']          = 'Faks';

// Error
$_['error_exists']       = 'Данный E-Mail уже зарегистрирован!';
$_['error_firstname']    = 'Имя должно быть от 1 до 32 символов!';
$_['error_lastname']     = 'Фамилия должна быть от 1 до 32 символов!';
$_['error_email']        = 'E-Mail адрес введен неверно!';
$_['error_telephone']    = 'Номер телефона должен быть от 3 до 32 символов!';
$_['error_custom_field'] = '%s необходим!';
$_['error_custom_field_validate'] = '%s неверный!';
