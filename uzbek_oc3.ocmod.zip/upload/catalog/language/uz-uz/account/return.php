<?php
// Heading
$_['heading_title']			= 'Tovarni qaytarish';

// Text
$_['text_account']			= 'Shaxsiy kabinet';
$_['text_return']				= 'Qaytarish haqida ma\'lumot';
$_['text_return_detail']	= 'Qaytarish tafsilotlari';
$_['text_description']		= '<p>Iltimos, tovarni qaytarish arizasini to\'ldiring</p>';
$_['text_order']				= 'Buyurtma haqida ma\'lumot';
$_['text_product']			= 'Tovar haqida ma\'lumot';
$_['text_reason']			= 'Qaytarish sababi haqida ma\'lumot';
$_['text_message']			= '<p>Mahsulotni qaytarish uchun so\'rov yubordingiz.</p><p> Elektron pochtangizga so\'rovning holati to\'g\'risida bildirishnomalar jo\'natiladi. Rahmat!</p>';
$_['text_return_id']			= 'Qaytarish uchun so\'rov raqami';
$_['text_order_id']			= 'Buyurtma raqami';
$_['text_date_ordered']	= 'Buyurtma sanasi';
$_['text_status']				= 'Holati';
$_['text_date_added']		= 'Qo\'shilgan';
$_['text_comment']			= 'Qaytarish bo\'yicha sharhlar';
$_['text_history']			= 'Qaytarishlar tarixi';
$_['text_empty']				= 'Oldin hech qanday mahsulotni qaytib berish bo\'lmagan!';
$_['text_agree']				= 'Men <a href="%s" class="agree"><b>%s</b></a> ni o\'qib chiqdim va shartlariga roziman';

$_['button_submit']			= 'So\'rov yuborish';

// Column
$_['column_return_id']   = 'To\'lovni qaytarish uchun so\'rov raqami';
$_['column_order_id']    = 'Buyurtma raqami';
$_['column_status']      = 'Holati';
$_['column_date_added']  = 'Qo\'shilgan';
$_['column_customer']    = 'Xaridor';
$_['column_product']     = 'Mahsulot nomi';
$_['column_model']       = 'Модель';
$_['column_quantity']    = 'Soni';
$_['column_price']       = 'Narxi';
$_['column_opened']      = 'Ochilgan';
$_['column_comment']     = 'Sharh';
$_['column_reason']      = 'Sabab';
$_['column_action']      = 'Harakat';

// Entry
$_['entry_order_id']     = 'Buyurtma raqami';
$_['entry_date_ordered'] = 'Buyurtma sanasi';
$_['entry_firstname']    = 'Ism';
$_['entry_lastname']     = 'Familiya';
$_['entry_email']        = 'E-Mail';
$_['entry_telephone']    = 'Telefon raqami';
$_['entry_product']      = 'Mahsulot nomi';
$_['entry_model']        = 'Model';
$_['entry_quantity']     = 'Soni';
$_['entry_reason']       = 'Qaytarish sababi';
$_['entry_opened']       = 'Mahsulot ochilgan.';
$_['entry_fault_detail'] = 'Nuqsonlari tasnifi';
$_['entry_captcha']      = 'Rasmdan kodni kiriting';

// Error
$_['text_error']         = 'Qaytarish so\'rovi topilmadi!';
$_['error_order_id']     = 'Buyurtma raqami ko\'rsatilmagan!';
$_['error_firstname']    = 'Ism 1 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_lastname']     = 'Familiya 1 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_email']        = 'Elektron pochta manzili noto'g'ri kiritilgan!';
$_['error_telephone']    = 'Telefon raqami 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_product']      = 'Mahsulot nomi 3 tadan 255 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_model']        = 'Model nomi 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_reason']       = 'Siz tovarni qaytarib berish sababini ko\'rsatishingiz kerak!';
$_['error_captcha']      = 'Rasmdagi kod noto\'g\'ri kiritildi!';
$_['error_agree']        = 'Siz %s ni o\'qib, unga rozi bo\'lishingiz kerak!';
