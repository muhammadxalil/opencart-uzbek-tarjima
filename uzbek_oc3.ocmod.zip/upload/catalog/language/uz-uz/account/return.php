<?php
// Heading
$_['heading_title']			= 'Xarid qilish natijalari';

// Text
$_['text_account']			= 'Shaxsiy kabinet';
$_['text_return']				= 'Pulni qaytarish haqida ma\'lumot';
$_['text_return_detail']	= 'Tafsilotlarni qaytaring';
$_['text_description']		= '<p>Qaytish uchun mol so\'rov shaklini to\'ldiring.</p>';
$_['text_order']				= 'buyurtma haqida ma\'lumot';
$_['text_product']			= 'Mahsulot haqida ma\'lumot';
$_['text_reason']			= 'Qaytish sababi haqida ma\'lumot';
$_['text_message']			= '<p> Qaytish to\'g\'risida so\'rov yuborgansiz. </p> <p> Siz elektron pochta orqali so\'rovingiz holati to\'g\'risida bildirishnoma olasiz. Rahmat! </p>';
$_['text_return_id']			= '№ Qaytish so\'rovi';
$_['text_order_id']			= '№ Buyurtma';
$_['text_date_ordered']	= 'Buyurtma sanasi';
$_['text_status']				= 'Holat';
$_['text_date_added']		= 'Qo\'shildi';
$_['text_comment']			= 'Izohni qaytaring';
$_['text_history']			= 'Qaytish tarixi';
$_['text_empty']				= 'Siz ilgari mahsulotni qaytarib olmagan edingiz!';
$_['text_agree']				= 'Men <a href="%s" class="agree"> <b> %s </b> </a> ni o\'qidim va shartlarga roziman';

$_['button_submit']			= 'So\'rov yuboring';

// Column
$_['column_return_id']   = '№ Qaytish so\'rovi';
$_['column_order_id']    = '№ Buyurtma';
$_['column_status']      = 'Holat';
$_['column_date_added']  = 'Qo\'shildi';
$_['column_customer']    = 'Mijoz';
$_['column_product']     = 'Mahsulot nomi';
$_['column_model']       = 'Model';
$_['column_quantity']    = 'Miqdori';
$_['column_price']       = 'Narx';
$_['column_opened']      = 'Ochiq';
$_['column_comment']     = 'Izoh';
$_['column_reason']      = 'Sababi';
$_['column_action']      = 'Harakat';

// Entry
$_['entry_order_id']     = '№ Buyurtma';
$_['entry_date_ordered'] = 'Buyurtma sanasi';
$_['entry_firstname']    = 'Ism';
$_['entry_lastname']     = 'Familiya';
$_['entry_email']        = 'E-Mail';
$_['entry_telephone']    = 'Telefon';
$_['entry_product']      = 'Mahsulot nomi';
$_['entry_model']        = 'Model';
$_['entry_quantity']     = 'Miqdori';
$_['entry_reason']       = 'Qaytish uchun sabab';
$_['entry_opened']       = 'Mahsulot paketdan chiqarildi';
$_['entry_fault_detail'] = 'Kamchiliklarning tavsifi';
$_['entry_captcha']      = 'Rasmdagi rasmni kiriting';

// Error
$_['text_error']         = 'Запрос на возврат не найден!';
$_['error_order_id']     = 'Не указан № заказа!';
$_['error_firstname']    = 'Имя должно быть от 1 до 32 символов!';
$_['error_lastname']     = 'Фамилия должна быть от 1 до 32 символов!';
$_['error_email']        = 'E-Mail адрес введен неверно!';
$_['error_telephone']    = 'Номер телефона должен быть от 3 до 32 символов!';
$_['error_product']      = 'Наименование товара  должно быть от 3 до 255 символов!';
$_['error_model']        = 'Название модели должно быть от 3 до 64 символов!';
$_['error_reason']       = 'Необходимо указать причину возврата товара!';
$_['error_captcha']      = 'Неверно введен код с картинки!';
$_['error_agree']        = 'Вы должны прочитать и согласится с %s!';
