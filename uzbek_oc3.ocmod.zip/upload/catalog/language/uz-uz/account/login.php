<?php
// Heading
$_['heading_title']                = 'Kirish';

// Text
$_['text_account']                 = 'Shaxsiy kabinet';
$_['text_login']                   = 'Kirish';
$_['text_new_customer']            = 'Yangi mijoz';
$_['text_register']                = 'Ro\'yhatdan o\'tish';
$_['text_register_account']        = 'Hisob qaydnomasini yaratish tezroq sotib olishga yordam beradi. Siz buyurtmaning holatini boshqarishingiz, shuningdek, ilgari qilingan buyurtmalarni ko\'rishingiz mumkin. Siz mukofot ballarini to\'plashingiz va chegirmali kuponlarni olishingiz mumkin. <BR> Va biz doimiy mijozlarga chegirmalar va shaxsiy xizmatlarning moslashuvchan tizimini taklif etamiz.<BR>';
$_['text_returning_customer']      = 'Ro\'yxatdan o\'tgan mijoz';
$_['text_i_am_returning_customer'] = 'Shaxsiy hisobingizga kiring';
$_['text_forgotten']               = 'Parolni unutdingizmi?';

// Entry
$_['entry_email']                  = 'E-Mail';
$_['entry_password']               = 'Parol';

// Error
$_['error_login']                  = 'Неправильно заполнены поле E-Mail и/или пароль!';
$_['error_attempts']               = 'Вы превысили максимальное количество попыток авторизации. Повторите попытку авторизации на сайте через 1 час';
$_['error_approved']               = 'Необходимо подтвердить аккаунт перед авторизацией.';
