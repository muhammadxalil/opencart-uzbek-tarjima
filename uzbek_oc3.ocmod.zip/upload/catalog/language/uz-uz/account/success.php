<?php
// Heading
$_['heading_title'] = 'Sizning hisob qaydnomangiz yaratildi!';

// Text
$_['text_message']  = '<p> Tabriklaymiz! Shaxsiy hisobingiz muvaffaqiyatli yaratildi. </p> <p> Endi siz qo\'shimcha funktsiyalardan foydalanishingiz mumkin: buyurtma tarixini ko\'rish, hisob-fakturani bosib chiqarish, aloqa ma\'lumotlari va etkazib berish manzillarini o\'zgartirish va boshqalar. </p> <p> Agar sizda bo\'lsa. har qanday savol bo\'lsa, <a href="%s"> bizga yozing </a>. </p>';
$_['text_approval'] = '<p>%s da ro\'yxatdan o\'tganingiz uchun tashakkur! </p> <p> Shaxsiy hisobingiz do\'kon ma\'muriyati tomonidan faollashtirilishi bilan sizga elektron pochta orqali xabar qilinadi. </p> <p> Agar savollaringiz bo\'lsa, iltimos <a href="%s"> bizga yozing </a>. </p>';
$_['text_account']  = 'Shaxsiy kabinet';
$_['text_success']  = 'Muvaffaqiyatli';


