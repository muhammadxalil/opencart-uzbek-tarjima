<?php
// Heading
$_['heading_title'] = 'Sizning hisobingiz yaratildi!';

// Text
$_['text_message']  = '<p> Tabriklaymiz! Shaxsiy hisobingiz muvaffaqiyatli yaratildi. </p> <p> Endi siz qo\'shimcha variantlardan foydalanishingiz mumkin: buyurtma tarixini ko\'rish, hisob-fakturani chop etish, aloqa ma\'lumotlarini va etkazib berish manzillarini o\'zgartirish va boshqa ko\'p narsalar. </p> <p> Agar sizda har qanday savol, <a href="%s"> bizga yozing </a>. </p>';
$_['text_approval'] = '<p> %s-da ro\'yxatdan o\'tganingiz uchun tashakkur! </p> <p> Do\'kon ma\'muriyati tomonidan shaxsiy kabinetingiz faollashtirilgandan so\'ng, sizga elektron pochta orqali xabar beriladi. </p> <p> Agar sizda biron bir savol bo\'lsa, iltimos <a href="%s"> bizga elektron pochta orqali </a>. </p> yuboring';
$_['text_account']  = 'Shaxsiy kabinet';
$_['text_success']  = 'Muvaffaqiyatli';


