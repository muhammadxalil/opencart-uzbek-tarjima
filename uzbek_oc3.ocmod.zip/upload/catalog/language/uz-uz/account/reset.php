<?php
// header
$_['heading_title']		= 'Parolni tiklash';

// Text
$_['text_account']		= 'Shaxsiy kabinet';
$_['text_password']	= 'Yangi parolni kiriting.';
$_['text_success']		= 'Sizning parolingiz o\'zgartirildi.';

// Entry
$_['entry_password']	= 'Parol';
$_['entry_confirm']		= 'Parolni tasdiqlash';

// Error
$_['error_password']	= 'Parol 4 tadan 20 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_confirm']		= 'Parol va parolni tasdiqlash boshqacha!';
$_['error_code']			= 'Parolni tiklash kodi noto\'g\'ri!';