<?php
// header
$_['heading_title']		= 'Parolni tiklash';

// Text
$_['text_account']		= 'Shaxsiy kabinet';
$_['text_password']	= 'Yangi parolni kiriting.';
$_['text_success']		= 'Parolingiz o\'zgartirildi';

// Entry
$_['entry_password']	= 'Parol';
$_['entry_confirm']		= 'Parolni tasdiqlash';

// Error
$_['error_password']	= 'Пароль должен быть от 4 до 20 символов!';
$_['error_confirm']		= 'Пароль и подтверждение пароля различны!';
$_['error_code']			= 'Код восстановления пароля ошибочный!';