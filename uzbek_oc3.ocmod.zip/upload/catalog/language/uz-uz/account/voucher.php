<?php
// Heading
$_['heading_title']    = 'Sovg\'a sertifikatini sotib olish';

// Text
$_['text_account']     = 'Hisob';
$_['text_voucher']     = 'Sovg\'a sertifikati';
$_['text_description'] = 'Sovg\'a sertifikati narxini to\'laganingizdan so\'ng, qabul qiluvchiga sovg\'a sertifikati yuboriladi.';
$_['text_agree']       = 'Menga sovg\'a sertifikatlari qaytarib berilmasligi haqida xabar berildi.';
$_['text_message']     = '<p> Sovg\'a sertifikati sotib olganingiz uchun tashakkur! Buyurtmani to\'ldirgandan so\'ng, oluvchiga sertifikatdan qanday foydalanish bo\'yicha ko\'rsatmalar bo\'lgan xat yuboriladi </p>';
$_['text_for']         = '%s uchun %s sovg\'a kuponi';

// Entry
$_['entry_to_name']    = 'Qabul qiluvchining ismi';
$_['entry_to_email']   = 'Qabul qiluvchining elektron pochtasi';
$_['entry_from_name']  = 'Sizning ismingiz';
$_['entry_from_email'] = 'Sizning Email';
$_['entry_theme']      = 'Sovg\'a vaucheri mavzusi';
$_['entry_message']    = 'Xabar';
$_['entry_amount']     = 'Miqdor';

// Help
$_['help_message']     = 'Sertifikat oluvchisi uchun xabar yoki tabrik (ixtiyoriy)';
$_['help_amount']      = '%S dan katta va %s dan kam bo\'lishi kerak';

// Error
$_['error_to_name']    = 'Oluvchining ismi  1 tadan 64 tagacha belgili bo\'lishi kerak!';
$_['error_from_name']  = 'Ismingiz 1 tadan 64 tagacha belgili bo\'lishi kerak!';
$_['error_email']      = 'To\'g\'ri elektron pochtani kiriting!';
$_['error_theme']      = 'Sertifikat mavzusini tanlang!';
$_['error_amount']     = 'Diqqat Miqdori %s dan katta va %s dan kam bo\'lishi kerak!';
$_['error_agree']      = 'Sovg\'a sertifikatlari qaytarib berilmasligiga rozi bo\'lishingiz kerak!';
