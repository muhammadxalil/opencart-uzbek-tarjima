<?php
// Heading
$_['heading_title']    = 'Купить подарочный сертификат';

// Text
$_['text_account']     = 'Hisob qaydnomasi';
$_['text_voucher']     = 'Sovg\'a sertifikati';
$_['text_description'] = 'Подарочный сертификат будет отправлен получателю после того как Вы оплатите стоимость Подарочного сертификата.';
$_['text_agree']       = 'Я уведомлен, что подарочные сертификаты не подлежат возврату.';
$_['text_message']     = '<p>Спасибо за покупку подарочного сертификата! После завершения заказа получателю будет выслано письмо с инструкцией, о том, как воспользоваться сертификатом</p>';
$_['text_for']         = '%s Sovg\'a sertifikati %s';

// Entry
$_['entry_to_name']    = 'Qabul qiluvchining nomi';
$_['entry_to_email']   = 'Qabul qiluvchining elektron pochtasi';
$_['entry_from_name']  = 'Sizning ismingiz';
$_['entry_from_email'] = 'Sizning elektron manzilingiz';
$_['entry_theme']      = 'Sovg\'alar sertifikati mavzusi';
$_['entry_message']    = 'Xabar';
$_['entry_amount']     = 'Miqdor';

// Help
$_['help_message']     = 'Сообщение или поздавление для получателя сертификата (не обязательно)';
$_['help_amount']      = 'Должна быть больше %s и меньше %s';

// Error
$_['error_to_name']    = 'Имя получателя должно быть от 1 до 64 символов!';
$_['error_from_name']  = 'Ваше имя должно быть от 1 до 64 символов!';
$_['error_email']      = 'Введите корректный E-Mail!';
$_['error_theme']      = 'Выберите тему сертификата!';
$_['error_amount']     = 'Внимание. Сумма должна быть больше %s и меньше %s!';
$_['error_agree']      = 'Вы должны согласиться с тем, что подарочные сертификаты не подлежат возврату!';
