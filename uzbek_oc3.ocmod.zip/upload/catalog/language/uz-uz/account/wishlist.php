<?php
// Heading
$_['heading_title'] = 'Mening xatcho\'plarim';

// Text
$_['text_account']  = 'Shaxsiy kabinet';
$_['text_instock']  = 'Peshtoqda';
$_['text_wishlist'] = 'Xatcho\'plar (%s)';
$_['text_login']    = 'Siz <a href="%s">kirishingiz kerak</a> yoki <a href="%s">akkaunt yarating</a> saqlash uchun <a href="%s">%s</a> o\'zingizning <a href="%s">xatcho\'plar ro\'yxatingizga</a>!';
$_['text_success']  = 'Siz qo\'shdingiz<a href="%s">%s</a> Xatcho\'plar <a href="%s">ga</a>!';
$_['text_exists']   = '<a href="%s">%s</a> allaqchon <a href="%s">xatcho\'plarda mavjud</a>!';
$_['text_remove']   = 'Xatcho\'plar ro\'yxati muvaffaqiyatli o\'zgartirildi!';
$_['text_empty']    = 'Xatcho\'plaringiz bo\'sh';

// Column
$_['column_image']  = 'Rasm';
$_['column_name']   = 'Mahsulot nomi';
$_['column_model']  = 'Model';
$_['column_stock']  = 'Mavjudligi';
$_['column_price']  = 'Mahsulot birligi uchun to\'lov';
$_['column_action'] = 'Harakat';
