<?php
// Heading
$_['heading_title'] = 'Mening Istaklarim';

// Text
$_['text_account']  = 'Shaxsiy kabinet';
$_['text_instock']  = 'Omborda mavjud;';
$_['text_wishlist'] = 'Istaklar (%s)';
$_['text_login']    = '<a href="%s"> %s </a> ni saqlash uchun <a href="%s"> kirish </a> yoki <a href="%s"> hisob yaratish </a> kerak. <a href="%s"> xatcho\'plar ro\'yxatiga </a>!';
$_['text_success']  = '<a href="%s"> Xatcho\'plar </a> ga <a href="%s">% s </a> qo\'shdingiz!';
$_['text_exists']   = '<a href="%s">%s</a> уже есть <a href="%s">закладках</a>!';
$_['text_remove']   = 'Xatcho\'plar ro\'yxati muvaffaqiyatli o\'zgartirildi!';
$_['text_empty']    = 'Xatcho\'plaringiz bo\'sh';

// Column
$_['column_image']  = 'Rasm';
$_['column_name']   = 'Mahsulot nomi';
$_['column_model']  = 'Model';
$_['column_stock']  = 'Mavjudligi';
$_['column_price']  = 'Donasining narxi';
$_['column_action'] = 'Harakat';
