<?php
// Heading
$_['heading_title']					= 'Shaxsiy kabinet';

// Text
$_['text_account']					= 'Shaxsiy kabinet';
$_['text_my_account']			= 'Hisobim';
$_['text_my_orders']				= 'Buyurtmalarim';
$_['text_my_newsletter']			= 'Obuna';
$_['text_edit']							= 'Kontakt ma\'lumotlarini o\'zgartiring';
$_['text_password']				= 'Parolingizni o\'zgartiring';
$_['text_address']					= 'Mening manzilimni o\'zgartiring';
$_['text_credit_card']				= 'Kredit kartalarni boshqarish';
$_['text_wishlist']					= 'Istaklar';
$_['text_order']						= 'Buyurtmalar tarixi';
$_['text_download']					= 'Yuklamalar';
$_['text_reward']						= 'Bonus ballari';
$_['text_return']						= 'So\'rovlarni qaytarish';
$_['text_transaction']				= 'Tranzaksiyalar tarixi';
$_['text_newsletter']				= 'Yangiliklarga obuna bo\'ling yoki obunani bekor qiling';
$_['text_recurring']					= 'Takroriy to\'lovlar';
$_['text_transactions']			= 'Tranzaksiyalar';

