<?php
// Heading
$_['heading_title']					= 'Shaxsiy kabinet';

// Text
$_['text_account']					= 'Shaxsiy kabinet';
$_['text_my_account']			= 'Mening hisob qaydnomam';
$_['text_my_orders']				= 'Mening buyurtmalarim';
$_['text_my_newsletter']			= 'Obuna';
$_['text_edit']							= 'Kontakt ma\'lumotlarini o\'zgartirish';
$_['text_password']				= 'Parolni o\'zgartirish';
$_['text_address']					= 'Mening manzillarimni o\'zgartirish';
$_['text_credit_card']				= 'Kredit kartalarni boshqarish';
$_['text_wishlist']					= 'Xatcho\'plarni ko\'rish';
$_['text_order']						= 'Buyurtmalar tarixi';
$_['text_download']					= 'Yuklab olish uchun fayllar';
$_['text_reward']						= 'Bonus ballari';
$_['text_return']						= 'Qaytarish so\'rovlari';
$_['text_transaction']				= 'Bitimlar tarixi';
$_['text_newsletter']				= 'Yangiliklarga obuna bo\'lish yoki obunani bekor qilish';
$_['text_recurring']					= 'Takroriy to\'lovlar';
$_['text_transactions']			= 'Bitim(tranzaksiya)lar';

