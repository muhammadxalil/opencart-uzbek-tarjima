<?php
// Heading
$_['heading_title']     = 'Aktsiyalar';

// Text
$_['text_empty']        = 'Aktsiya bo\'yicha tovarlar yo\'q.';
$_['text_quantity']     = 'Soni:';
$_['text_manufacturer'] = 'Ishlab chiqaruvchi:';
$_['text_model']        = 'Model:';
$_['text_points']       = 'Mukofot ballari:';
$_['text_price']        = 'Narxi:';
$_['text_tax']          = 'QQS qo\'shilmagan:';
$_['text_compare']      = 'Mahsulotlarni taqqoslash (%s)';
$_['text_sort']         = 'Saralash:';
$_['text_default']      = 'Sukut bo\'yicha';
$_['text_name_asc']     = 'Nomi (A - Z)';
$_['text_name_desc']    = 'Nomi (Z - A)';
$_['text_price_asc']    = 'Narxi (past &gt; yuqori)';
$_['text_price_desc']   = 'Narxi (yuqori &gt; past)';
$_['text_rating_asc']   = 'Рейтинг (pastdan boshlab)';
$_['text_rating_desc']  = 'Рейтинг (yuqoridan boshlab)';
$_['text_model_asc']    = 'Model (A - Z)';
$_['text_model_desc']   = 'Model (Я - А)';
$_['text_limit']        = 'Ko\'rsatish:';

