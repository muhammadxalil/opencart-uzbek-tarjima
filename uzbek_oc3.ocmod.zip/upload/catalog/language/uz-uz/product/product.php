<?php
// Text
$_['text_search']                             = 'Izlash';
$_['text_brand']                              = 'Ishlab chiqaruvchi';
$_['text_manufacturer']                       = 'Ishlab chiqaruvchi:';
$_['text_model']                              = 'Model:';
$_['text_reward']                             = 'Mukofot ballari:';
$_['text_points']                             = 'Bonus ballaridagi narx:';
$_['text_stock']                              = 'Mavjudligi:';
$_['text_instock']                            = 'Peshtoqda';
$_['text_tax']                                = 'QQS qo\'shilmagan:';
$_['text_discount']                           = ' yoki ko\'proq: ';
$_['text_option']                             = 'Mavjud variantlar';
$_['text_minimum']                            = 'Minimal buyurtma miqdori: %s';
$_['text_reviews']                            = '%s sharhlar';
$_['text_write']                              = 'Sharh yozish';
$_['text_login']                              = 'Iltimos <a href="%s"> tizimga kiring</a> yoki <a href="%s">sharh yozishdan oldin </a> hisobini yarating';
$_['text_no_reviews']                         = 'Ushbu mahsulot uchun sharhlar yo\'q.';
$_['text_note']                               = '<span style="color: #FF0000;">Izoh:</span> HTML belgilash qo\'llab-quvvatlanmaydi! Oddiy matndan foydalaning.';
$_['text_success']                            = 'Fikr-mulohazangiz uchun tashakkur. U spamni tekshirish uchun ma\'murga jo\'natildi va tez orada e\'lon qilinadi.';
$_['text_related']                            = 'Tavsiya etilgan mahsulotlar';
$_['text_tags']                               = '<i class="fa fa-tags"></i>';
$_['text_error']                              = 'Mahsulot topilmadi!';
$_['text_payment_recurring']                    = 'Hisob-kitob profili';
$_['text_trial_description']                  = 'Miqdor: %s; Davriylik: %d %s; To\'lovlar soni: %d, Keyingi ';
$_['text_payment_description']                = 'Miqdor: %s; Davriylik:  %d %s; To\'lovlar soni:  %d ';
$_['text_payment_until_canceled_description'] = 'Miqdor: %s; Davriylik:  %d %s ; To\'lovlar soni: bekor qilinguncha';
$_['text_day']                                = 'kun';
$_['text_week']                               = 'hafta';
$_['text_semi_month']                         = 'yarim oy';
$_['text_month']                              = 'oy';
$_['text_year']                               = 'yil';

// Entry
$_['entry_qty']                               = 'Soni';
$_['entry_name']                              = 'Sizning ismingiz:';
$_['entry_review']                            = 'Sizning sharhingiz:';
$_['entry_rating']                            = 'Baho:';
$_['entry_good']                              = 'Yaxshi';
$_['entry_bad']                               = 'Yomon';
$_['entry_captcha']                           = 'Rasmda ko\'rsatilgan kodni kiriting:';

// Tabs
$_['tab_description']                       = 'Ta\'rif';
$_['tab_attribute']                           = 'Xarakteristikalar';
$_['tab_review']                              = 'Sharhlar (%s)';
$_['button_continue']                      = 'Fikr va mulohaza yuborish';

// Error
$_['error_name']                              = 'Ism 3 tadan 25 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_text']                              = 'Sharh matni 25-1000 belgidan iborat bo\'lishi kerak!';
$_['error_rating']                            = 'Iltimos, reytingni tanlang!';
$_['error_captcha']                           = 'Rasmda ko\'rsatilgan kod noto\'g\'ri kiritilgan!';
