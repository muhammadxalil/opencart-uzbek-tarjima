<?php
// Text
$_['text_search']                             = 'Qidirmoq';
$_['text_brand']                              = 'Ishlab chiqaruvchi';
$_['text_manufacturer']                       = 'Ishlab chiqaruvchi:';
$_['text_model']                              = 'Model:';
$_['text_reward']                             = 'Bonus ballari:';
$_['text_points']                             = 'Bonus ballaridagi narx:';
$_['text_stock']                              = 'Mavjudligi:';
$_['text_instock']                            = 'Mavjud';
$_['text_tax']                                = 'НДС yo\'q:';
$_['text_discount']                           = ' yoki undan ko\'p: ';
$_['text_option']                             = 'Mavjud variantlar';
$_['text_minimum']                            = 'Minimal buyurtma miqdori: %s';
$_['text_reviews']                            = '%s sharhlar';
$_['text_write']                              = 'Mulohaza yozing';
$_['text_login']                              = 'Пожалуйста <a href="%s">авторизируйтесь</a> или <a href="%s">создайте учетную запись</a> перед тем как написать отзыв';
$_['text_no_reviews']                         = 'Ushbu mahsulot uchun sharhlar yo\'q.';
$_['text_note']                               = '<span style="color: #FF0000;">Примечание:</span> HTML разметка не поддерживается! Используйте обычный текст.';
$_['text_success']                            = 'Fikr-mulohazangiz uchun tashakkur. U administratorga spam-tekshiruv uchun yuborilgan va tez orada nashr etiladi.';
$_['text_related']                            = 'Tavsiya etilgan mahsulotlar';
$_['text_tags']                               = '<i class="fa fa-tags"></i>';
$_['text_error']                              = 'Mahsulot topilmadi!';
$_['text_payment_recurring']                    = 'To\'lov profili';
$_['text_trial_description']                  = 'Сумма: %s; Периодичность: %d %s; Кол-во платежей: %d, Далее ';
$_['text_payment_description']                = 'Сумма: %s; Периодичность:  %d %s; Кол-во платежей:  %d ';
$_['text_payment_until_canceled_description'] = 'Сумма: %s; Периодичность:  %d %s ; Кол-во платежей: до отмены';
$_['text_day']                                = 'kun';
$_['text_week']                               = 'hafta';
$_['text_semi_month']                         = 'yarim oy';
$_['text_month']                              = 'oy';
$_['text_year']                               = 'yil';

// Entry
$_['entry_qty']                               = 'Miqdori';
$_['entry_name']                              = 'Sizning ismingiz:';
$_['entry_review']                            = 'Sizning fikringiz:';
$_['entry_rating']                            = 'Baholash:';
$_['entry_good']                              = 'Yaxshi';
$_['entry_bad']                               = 'Yomon';
$_['entry_captcha']                           = 'Rasmda ko\'rsatilgan kodni kiriting:';

// Tabs
$_['tab_description']                       = 'Tavsif';
$_['tab_attribute']                           = 'Xususiyatlari';
$_['tab_review']                              = 'Sharhlar (%s)';
$_['button_continue']                      = 'Sharh yuboring';

// Error
$_['error_name']                              = 'Имя должно быть от 3 до 25 символов!';
$_['error_text']                              = 'Текст отзыва должен быть от 25 до 1000 символов!';
$_['error_rating']                            = 'Пожалуйста, выберите оценку!';
$_['error_captcha']                           = 'Код, указанный на картинке, введен неверно!';
