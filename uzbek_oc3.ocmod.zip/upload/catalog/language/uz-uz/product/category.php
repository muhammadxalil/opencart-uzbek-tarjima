<?php
// Text
$_['text_refine']       = 'Subkategoriyani tanlang';
$_['text_product']      = 'Mahsulotlar';
$_['text_error']        = 'Kategoriya topilmadi!';
$_['text_empty']        = 'Ushbu toifadagi mahsulotlar yo\'q';
$_['text_quantity']     = 'Miqdori:';
$_['text_manufacturer'] = 'Ishlab chiqaruvchi:';
$_['text_model']        = 'Model:';
$_['text_points']       = 'Bonus ballari:';
$_['text_price']        = 'Narx:';
$_['text_tax']          = 'НДС Yo\'q:';
$_['text_compare']      = 'Mahsulotni taqqoslash (%s)';
$_['text_sort']         = 'Tartiblash:';
$_['text_default']      = 'Odatiy';
$_['text_name_asc']     = 'Ism (А - Я)';
$_['text_name_desc']    = 'Ism (Я - А)';
$_['text_price_asc']    = 'Narx (past &gt; yuqori)';
$_['text_price_desc']   = 'Narx (yuqori &gt; past)';
$_['text_rating_asc']   = 'Reyting (pastdan boshlab)';
$_['text_rating_desc']  = 'Reyting (balanddan boshlab)';
$_['text_model_asc']    = 'Model (А - Я)';
$_['text_model_desc']   = 'Model (Я - А)';
$_['text_limit']        = 'Ko\'rsatish:';

