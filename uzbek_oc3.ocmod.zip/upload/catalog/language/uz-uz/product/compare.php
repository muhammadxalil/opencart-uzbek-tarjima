<?php
// Heading
$_['heading_title']     = 'Mahsulotni taqqoslash';

// Text
$_['text_product']      = 'Tavsif';
$_['text_name']         = 'Mahsulot';
$_['text_image']        = 'Rasm';
$_['text_price']        = 'Narx';
$_['text_model']        = 'Model';
$_['text_manufacturer'] = 'Ishlab chiqaruvchi';
$_['text_availability'] = 'Mavjudligi';
$_['text_instock']      = 'Omborxonada bormi';
$_['text_rating']       = 'Reyting';
$_['text_reviews']      = 'Jami sharhlar: %s';
$_['text_summary']      = 'Qisqa Tasvir';
$_['text_weight']       = 'Og\'irligi';
$_['text_dimension']    = 'O\'lchamlari (Д х Ш х В)';
$_['text_compare']      = 'Mahsulotni taqqoslash (%s)';
$_['text_success']      = 'Товар <a href="%s">%s</a> добавлен в ваш <a href="%s">список сравнения</a>!';
$_['text_remove']       = 'Удалено из списка сравнений';
$_['text_empty']        = 'Вы не выбрали ни одного товара для сравнения.';
