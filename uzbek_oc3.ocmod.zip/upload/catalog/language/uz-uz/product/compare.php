<?php
// Heading
$_['heading_title']     = 'Mahsulotlarni taqqoslash';

// Text
$_['text_product']      = 'Ta\'rif';
$_['text_name']         = 'Mahsulot';
$_['text_image']        = 'Rasm';
$_['text_price']        = 'Narxi';
$_['text_model']        = 'Model';
$_['text_manufacturer'] = 'Ishlab chiqaruvchi';
$_['text_availability'] = 'Mavjudligi';
$_['text_instock']      = 'Omborda bor';
$_['text_rating']       = 'Baho';
$_['text_reviews']      = 'Umumiy sharhlar: %s';
$_['text_summary']      = 'Qisqacha tavsif';
$_['text_weight']       = 'Og\'irligi';
$_['text_dimension']    = 'O\'lchamlari (U х E х B)';
$_['text_compare']      = 'Mahsulotlarni taqqoslash (%s)';
$_['text_success']      = 'Mahsulot <a href="%s">%s</a> sizning <a href="%s"> taqqoslash ro\'yxatingizga qo\'shildi</a>!';
$_['text_remove']       = 'Taqqoslash ro\'yxatidan olib tashlandi.';
$_['text_empty']        = 'Taqqoslash uchun hech qanday mahsulot tanlanmagan.';
