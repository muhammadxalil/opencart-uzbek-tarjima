<?php
// Heading
$_['heading_title']     = 'Qidiruv';
$_['heading_tag']		= 'Teg bo\'yicha - ';

// Text
$_['text_search']       = 'Qidiruv natijalari';
$_['text_keyword']      = 'Kalit so\'zlar';
$_['text_category']     = 'Barcha toifalar';
$_['text_sub_category'] = 'Subkategoriyalarda qidirish';
$_['text_empty']        = 'Qidiruv mezonlaringizga mos keladigan mahsulotlar yo\'q.';
$_['text_quantity']     = 'Miqdori:';
$_['text_manufacturer'] = 'Ishlab chiqaruvchi:';
$_['text_model']        = 'Modeli:';
$_['text_points']       = 'Mukofot ballari:';
$_['text_price']        = 'Narxi:';
$_['text_tax']          = 'QQSsiz:';
$_['text_reviews']      = 'Umumiy sharhlar: %s';
$_['text_compare']      = 'Mahsulotlarni taqqoslash (%s)';
$_['text_sort']         = 'Saralash:';
$_['text_default']      = 'Sukut bo\'yicha';
$_['text_name_asc']     = 'Nomi (A - Z)';
$_['text_name_desc']    = 'Nomi (Z - A)';
$_['text_price_asc']    = 'Narxi (past &gt; yuqori)';
$_['text_price_desc']   = 'Narxi (yuqori &gt; past)';
$_['text_rating_asc']   = 'Reytingi (pastdan boshlab)';
$_['text_rating_desc']  = 'Reytingi (yuqoridan boshlab)';
$_['text_model_asc']    = 'Modeli (A - Z)';
$_['text_model_desc']   = 'Modeli (Z - A)';
$_['text_limit']        = 'Ko\'rsatish:';

// Entry
$_['entry_search']      = 'Qidiruv:';
$_['entry_description'] = 'Mahsulot ta\'riflaridan qidirish';
