<?php
// Heading
$_['heading_title']     = 'Qidirmoq';
$_['heading_tag']		= 'Teg bilan - ';

// Text
$_['text_search']       = 'Qidiruv natijalari';
$_['text_keyword']      = 'Kalit so\'zlar';
$_['text_category']     = 'Barcha toifalar';
$_['text_sub_category'] = 'Subkategoriyalarda qidirish';
$_['text_empty']        = 'Qidiruv mezonlariga mos keladigan mahsulotlar yo\'q.';
$_['text_quantity']     = 'Miqdori:';
$_['text_manufacturer'] = 'Ishlab chiqaruvchi:';
$_['text_model']        = 'Model:';
$_['text_points']       = 'Bonus ballari:';
$_['text_price']        = 'Narx:';
$_['text_tax']          = 'Без НДС:';
$_['text_reviews']      = 'Jami sharhlar: %s';
$_['text_compare']      = 'Mahsulotni taqqoslash (%s)';
$_['text_sort']         = 'Tartiblash:';
$_['text_default']      = 'Odatiy';
$_['text_name_asc']     = 'Ism (А - Я)';
$_['text_name_desc']    = 'Ism (Я - А)';
$_['text_price_asc']    = 'Narx (низкая &gt; высокая)';
$_['text_price_desc']   = 'Narx (высокая &gt; низкая)';
$_['text_rating_asc']   = 'Reyting (начиная с низкого)';
$_['text_rating_desc']  = 'Reyting (начиная с высокого)';
$_['text_model_asc']    = 'Model (А - Я)';
$_['text_model_desc']   = 'Model (Я - А)';
$_['text_limit']        = 'Ko\'rsatish:';

// Entry
$_['entry_search']      = 'Qidirmoq:';
$_['entry_description'] = 'Mahsulot tavsiflarini qidirib toping';
