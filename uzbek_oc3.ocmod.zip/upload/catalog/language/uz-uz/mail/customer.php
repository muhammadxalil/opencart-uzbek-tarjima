<?php
// Text
$_['text_subject']        = '%s - Ro\'yxatdan o\'tganingiz uchun rahmat.';
$_['text_welcome']        = '%s ga xush kelibsiz va ro\'yxatdan o\'tganingiz uchun tashakkur!';
$_['text_login']          = 'Sizning hisobingiz yaratildi va siz elektron pochta va parolingizdan ushbu havola orqali foydalanib tizimga kirishingiz mumkin:';
$_['text_approval']       = 'Sizning hisobingiz yaratildi va tasdiqlashni kutmoqda. Tasdiqdan keyin do\'konga elektron pochta va parol yordamida havoladan foydalanishingiz mumkin:';
$_['text_services']       = 'Tizimga kirganingizdan so\'ng siz do\'konning so\'nggi xizmatlarini, masalan, so\'nggi buyurtmalarni ko\'rib chiqish, hisob-fakturani bosib chiqarish va qayd yozuvingiz haqidagi ma\'lumotlarni tahrirlash xizmatlaridan foydalanishingiz mumkin.';
$_['text_thanks']         = 'Rahmat,';
$_['text_new_customer']   = 'Yangi mijoz';
$_['text_signup']         = 'Yangi mijoz ro‘yxatdan o‘tkazildi:';
$_['text_website']        = 'Sayt:';
$_['text_customer_group'] = 'Mijozlar guruhi:';
$_['text_firstname']      = 'Ism, Otasining ismi:';
$_['text_lastname']       = 'Familiya:';
$_['text_email']          = 'E-Mail:';
$_['text_telephone']      = 'Telefon raqami:';
