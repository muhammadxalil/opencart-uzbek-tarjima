<?php
// Text
$_['text_subject']  = 'Siz %s sovg\'a vaucherini yubordingiz';
$_['text_greeting'] = 'Tabriklaymiz, siz %s tomonidan Sovg\'a sertifikati oldingiz';
$_['text_from']     = 'Siz %s tomonidan Sovg\'a sertifikati oldingiz';
$_['text_message']  = 'Yuboruvchi sizga xabar qoldirdi';
$_['text_redeem']   = 'Ushbu Sovg\'a sertifikatidan foydalanish uchun <b>%s</b> kodini saqlang va keyin do\'konga boring va sizga yoqqan tovarlarga buyurtma bering. Buyurtmani berishdan oldin sovg\'a sertifikati kodini savatni ko\'rish sahifasiga kiritishingiz mumkin.';
$_['text_footer']   = 'Agar sizda biron bir savol bo\'lsa, ushbu xabarga javob bering.';
