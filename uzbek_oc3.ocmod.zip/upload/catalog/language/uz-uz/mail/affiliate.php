<?php
// Text
$_['text_subject']		        = '%s - Hamkorlik dasturi';
$_['text_welcome']		        = 'Tabriklaymiz. Siz bizning %s do\'konimizning hamkori bo\'ldingiz!';
$_['text_login']                = 'Hisob qaydnomangiz yaratildi va siz elektron pochta va parolingiz bilan ushbu havoladan foydalanib tizimga kirishingiz mumkin:';
$_['text_approval']		        = 'Hisob qaydnomangiz tekshirishni kutmoqda. Tasdiqdan so\'ng, siz bizning saytimizning filial bo\'limiga ushbu havolada kirishingiz mumkin:';
$_['text_services']		        = 'Hamkorlik bo\'limida siz referal kodi va havolalarni olishingiz, komissiyani kuzatishingiz va hisob qaydnomasi sozlamalarini o\'zgartirishingiz mumkin.';
$_['text_thanks']		        = 'Rahmat,';
$_['text_new_affiliate']        = 'Yangi hamkor';
$_['text_signup']		        = 'Yangi hamkor ro\'yxatdan o\'tdi:';
$_['text_store']		        = 'Do\'kon:';
$_['text_firstname']	        = 'Ism, Otasining ismi:';
$_['text_lastname']		        = 'Familiya:';
$_['text_company']		        = 'Kompaniya:';
$_['text_email']		        = 'E-Mail:';
$_['text_telephone']	        = 'Telefon raqami:';
$_['text_website']		        = 'Sayt:';
$_['text_order_id']             = 'Buyurtma raqami:';
$_['text_transaction_subject']  = '%s - hamkorlik komissiyalari';
$_['text_transaction_received'] = 'Siz %s komissiya oldingiz!';
$_['text_transaction_total']    = 'Jami komissiya qoldig\'i %s.';
