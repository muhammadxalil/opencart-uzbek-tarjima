<?php
// Text
$_['text_subject']		= '%s - yangi parol';
$_['text_greeting']		= 'Siz %s da yangi parol so\'radingiz.';
$_['text_change']		= 'Parolni tiklash uchun havolani bosing:';
$_['text_ip']				= 'Ushbu IP-dan yangi parol so\'raldi: %s';
