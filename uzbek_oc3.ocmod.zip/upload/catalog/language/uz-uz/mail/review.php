<?php
// Text
$_['text_subject']	= '%s - mahsulot haqida sharh';
$_['text_waiting']	= 'Yangi sharhlar sizning tasdig\'ingizni kutyapti.';
$_['text_product']	= 'Mahsulot: %s';
$_['text_reviewer']	= 'Sharhni qoldirgan: %s';
$_['text_rating']	= 'Baho: %s';
$_['text_review']	= 'Sharh:';

