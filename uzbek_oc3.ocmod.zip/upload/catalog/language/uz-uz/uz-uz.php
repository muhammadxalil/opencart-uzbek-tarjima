<?php
// Locale
$_['code']						= 'ru';
$_['direction']					= 'ltr';
$_['date_format_short']	= 'd.m.Y';
$_['date_format_long']		= 'l, d F Y';
$_['time_format']			= 'H:i:s';
$_['datetime_format']		= 'd/m/Y H:i:s';
$_['decimal_point']			= '.';
$_['thousand_point']		= '';

// Text
$_['text_home']				= '<i class="fa fa-home"></i>';
$_['text_yes']					= 'Ha';
$_['text_no']					= 'Yo\'q';
$_['text_none']				= ' --- Tanlanmagan --- ';
$_['text_select']				= ' --- Tanlang --- ';
$_['text_all_zones']		= 'Barcha hududlar';
$_['text_pagination']		= '%d dan %d gacha %d dan ko\'rsatildi(sahifalar: %d)';
$_['text_loading']			= 'Yuklanmoqda...';
$_['text_no_results']		= 'Ma\'lumotlar yo\'q!';

// Buttons
$_['button_address_add']		= 'Manzil qo\'shish';
$_['button_back']					= 'Orqaga';
$_['button_continue']				= 'Davom etish';
$_['button_cart']						= 'Xarid qilish';
$_['button_cancel']					= 'Bekor qilish';
$_['button_compare']				= 'Taqqoslaganda';
$_['button_wishlist']				= 'Xatcho\'plarga';
$_['button_checkout']				= 'Buyurtmani rasmiylashtirish';
$_['button_confirm']				= 'Buyurtmani tasdiqlash';
$_['button_coupon']				= 'Kupondan foydalanish';
$_['button_delete']					= 'Yo\'q qilish';
$_['button_download']				= 'Yuklab olish';
$_['button_edit']						= 'Tahrirlash';
$_['button_filter']						= 'Izlash';
$_['button_new_address']		= 'Yangi manzil';
$_['button_change_address']	= 'Manzilni o\'zgartirish';
$_['button_reviews']				= 'Sharhlar';
$_['button_write']					= 'Sharh yozish';
$_['button_login']					= 'Kirish';
$_['button_update']					= 'Yangilash';
$_['button_remove']				= 'Yo\'q qilish';
$_['button_reorder']					= 'Qo\'shimcha buyurtma';
$_['button_return']					= 'Qaytarib berish';
$_['button_shopping']				= 'Xarid qilishni davom etish';
$_['button_search']					= 'Qidirish';
$_['button_shipping']				= 'Yetkazib berishni qo\'llash';
$_['button_submit']					= 'Qo\'llash';
$_['button_guest']					= 'Ro\'yxatdan o\'tmasdan buyurtmani tasdiqlash';
$_['button_view']						= 'Ko\'rish';
$_['button_voucher']				= 'Sovg\'a sertifikatini qo\'llash';
$_['button_upload']					= 'Faylni yuklash';
$_['button_reward']					= 'Bonus ballarini qo\'llash';
$_['button_quote']					= 'Narxlarni bilish';
$_['button_list']						= 'Ro\'yxat';
$_['button_grid']						= 'Jadval';
$_['button_map']					= 'Xaritani ko\'rish';

// Error
$_['error_exception']       = 'Kod xatoligi (%s): %s da %s, %s qatorda';
$_['error_upload_1']        = 'Ogohlantirish: Yuklanayotgan fayl php.ini upload_max_filesize qiymatidan ko\'p!';
$_['error_upload_2']        = 'Ogohlantirish: Yuklangan fayllar sozlamalarda keltirilgan MAX_FILE_SIZE qiymatidan ortib ketadi!';
$_['error_upload_3']        = 'Ogohlantirish: Fayllar qisman yuklangan!';
$_['error_upload_4']        = 'Ogohlantirish: Yuklash uchun fayllar yo\'q!';
$_['error_upload_6']        = 'Ogohlantirish: Vaqtinchalik jild!';
$_['error_upload_7']        = 'Ogohlantirish: Yozuv xatosi!';
$_['error_upload_8']        = 'Ogohlantirish: Ushbu kengaytma bilan fayl yuklash taqiqlangan!';
$_['error_upload_999']		= 'Ogohlantirish: Noma\'lum xatolik!';
$_['error_curl']				= 'CURL: Kod xatoligi(%s): %s';


