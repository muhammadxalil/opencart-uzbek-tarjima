<?php
// Locale
$_['code']						= 'uz';
$_['direction']					= 'ltr';
$_['date_format_short']	= 'd.m.Y';
$_['date_format_long']		= 'l, d F Y';
$_['time_format']			= 'H:i:s';
$_['datetime_format']		= 'd/m/Y H:i:s';
$_['decimal_point']			= '.';
$_['thousand_point']		= '';

// Text
$_['text_home']				= '<i class="fa fa-home">Asosiy</i>';
$_['text_yes']					= 'Ha';
$_['text_no']					= 'Yo\'q';
$_['text_none']				= ' --- Tanlanmagan --- ';
$_['text_select']				= ' --- Iltimos tanlang --- ';
$_['text_all_zones']		= 'Barcha zonalar';
$_['text_pagination']		= 'Ko\'rsatildi %d dan %d gacha %d (hammasi %d sahifa)';
$_['text_loading']			= 'Yuklanmoqda...';
$_['text_no_results']		= 'Ma\'lumot yo\'q!';

// Buttons
$_['button_address_add']		= 'Manzil qo\'shing';
$_['button_back']					= 'Orqaga';
$_['button_continue']				= 'Davom eting';
$_['button_cart']						= 'Sotib oling';
$_['button_cancel']					= 'Bekor qilish';
$_['button_compare']				= 'Taqqoslash';
$_['button_wishlist']				= 'Istaklarim';
$_['button_checkout']				= 'Buyurtma';
$_['button_confirm']				= 'Buyurtmani tasdiqlash';
$_['button_coupon']				= 'Kupon';
$_['button_delete']					= 'O\'chirish';
$_['button_download']				= 'Yuklab olish';
$_['button_edit']						= 'Tahrirlash';
$_['button_filter']						= 'Qidirmoq';
$_['button_new_address']		= 'Yangi manzil';
$_['button_change_address']	= 'Manzilni o\'zgartirish';
$_['button_reviews']				= 'Sharhlar';
$_['button_write']					= 'Mulohaza yozing';
$_['button_login']					= 'Kirish';
$_['button_update']					= 'Yangilang';
$_['button_remove']				= 'O\'chirish';
$_['button_reorder']					= 'Qo\'shimcha buyurtma';
$_['button_return']					= 'Qaytish';
$_['button_shopping']				= 'Xaridda davom eting';
$_['button_search']					= 'Qidirmoq';
$_['button_shipping']				= 'Yuk tashishga murojaat qiling';
$_['button_submit']					= 'Ariza berish';
$_['button_guest']					= 'Ro\'yxatdan o\'tmasdan to\'lov';
$_['button_view']						= 'Ko\'rinish';
$_['button_voucher']				= 'Sovg\'a sertifikatini qo\'llang';
$_['button_upload']					= 'Faylni yuklang';
$_['button_reward']					= 'Bonus ballarini qo\'llang';
$_['button_quote']					= 'Narxlarni tekshiring';
$_['button_list']						= 'Ro\'yxat';
$_['button_grid']						= 'Tarmoq';
$_['button_map']					= 'Xaritani ko\'rish';

// Error
$_['error_exception']       = 'Ошибка кода(%s): %s в %s на строке %s';
$_['error_upload_1']        = 'Предупреждение: Размер загружаемого файла превышает значение upload_max_filesize в php.ini!';
$_['error_upload_2']        = 'Предупреждение: Загруженный файл превышает MAX_FILE_SIZE значение, которая была указана в настройках!';
$_['error_upload_3']        = 'Предупреждение: Загруженные файлы были загружены лишь частично!';
$_['error_upload_4']        = 'Предупреждение: Нет файлов для загрузки!';
$_['error_upload_6']        = 'Предупреждение: Временная папка!';
$_['error_upload_7']        = 'Предупреждение: Ошибка записи!';
$_['error_upload_8']        = 'Предупреждение: Запрещено загружать файл с данным расширением!';
$_['error_upload_999']		= 'Предупреждение: Неизвестная ошибка!';
$_['error_curl']				= 'CURL: Ошибка кода(%s): %s';


