<?php
// Text
$_['text_upload']    = 'Fayl muvaffaqiyatli yuklandi!';

// Error
$_['error_filename'] = 'Fayl nomi 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_filetype'] = 'Fayl turi noto\'g\'ri!';
$_['error_upload']   = 'Faylni yuklash kerak!';


