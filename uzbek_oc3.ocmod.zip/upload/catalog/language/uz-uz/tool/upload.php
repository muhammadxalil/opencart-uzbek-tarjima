<?php
// Text
$_['text_upload']    = 'Fayl yuklandi!';

// Error
$_['error_filename'] = 'Имя файла должно быть от 3 до 64 символов!';
$_['error_filetype'] = 'Неправильный тип файла!';
$_['error_upload']   = 'Необходимо загрузить файл!';


