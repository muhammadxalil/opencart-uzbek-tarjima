<?php
// Text
$_['text_success'] = 'API sessiya omadli ishga tushirildi!';

// Error
$_['error_key']  = 'Diqqat: Noto\'g\'ri API Key!';
$_['error_ip']   = 'Diqqat: Sizning IP %singiz API kirish ro\'yxatiga qo\'shilmagan!';


