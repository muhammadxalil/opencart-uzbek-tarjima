<?php
// Text
$_['text_success']           = 'Buyurtma yangilandi';

// Error
$_['error_permission']       = 'Diqqat! APIga kirish taqiqlangan!';
$_['error_customer']         = 'Mijoz ma\'lumotlari talab qilinadi!';
$_['error_payment_address']  = 'To\'lovchining manzili talab qilinadi!';
$_['error_payment_method']   = 'To\'lov usuli kerak!';
$_['error_shipping_address'] = 'Yetkazib berish manzili talab qilinadi!';
$_['error_shipping_method']  = 'Yetkazib berish usuli talab qilinadi!';
$_['error_stock']            = '*** bilan belgilangan mahsulotlar kerakli miqdorda yo\'q yoki omborda mavjud emas!';
$_['error_minimum']          = '%s buyurtma uchun minimal miqdor %s!';
$_['error_not_found']        = 'Diqqat! Buyurtma topilmadi';

