<?php
// Heading
$_['heading_title']   = 'Parolni unutdingizmi?';

// Text
$_['text_account']    = 'Hamkor kabineti';
$_['text_forgotten']  = 'Parolni unutdingizmi?';
$_['text_your_email'] = 'Sizning E-Mail';
$_['text_email']      = 'Hisob qaydnomangizning elektron pochta manzilini kiriting. Parolingizni elektron pochta orqali olish uchun "Davom etish" ni bosing.';
$_['text_success']    = 'Sizning elektron pochtangizga yangi parol yuborildi.';

// Entry
$_['entry_email']     = 'E-Mail manzil';

// Error
$_['error_email']     = 'Ushbu elektron pochta manzili topilmadi, qayta urinib ko\'ring!';
$_['error_approved']  = 'Diqqat! Sizning hisobingiz hali faollashtirilmagan.';
