<?php
// Heading
$_['heading_title']   = 'Parolni unutdingizmi?';

// Text
$_['text_account']    = 'Hamkorlar kabineti';
$_['text_forgotten']  = 'Parolni unutdingizmi?';
$_['text_your_email'] = 'Sizning elektron manzilingiz';
$_['text_email']      = 'Hisobingizdan elektron pochta manzilini kiriting. Parolingizni elektron pochta orqali olish uchun Davom etish tugmasini bosing.';
$_['text_success']    = 'Elektron pochtangizga yangi parol yuborildi.';

// Entry
$_['entry_email']     = 'Elektron pochta manzili';

// Error
$_['error_email']     = 'Ushbu elektron pochta manzili topilmadi, qayta urinib ko\'ring!';
$_['error_approved']  = 'Diqqat! Sizning hisob qaydnomangiz hali faollashtirilmagan.';
