<?php
// Heading
$_['heading_title']    = 'Hamkorning referal kodlari';

// Text
$_['text_account']     = 'Hamkor kabineti';
$_['text_description'] = 'Hamkorlik dasturi orqali pul ishlash uchun siz bizga yo\'naltiruvchi havolani qo\'yishingiz kerak. %s havolalarni yaratish uchun quyidagi vositadan foydalaning.';

// Entry
$_['entry_code']       = 'Sizning referal kodingiz';
$_['entry_generator']  = 'Yo\'llanma havolasini yaratish';
$_['entry_link']       = 'Yo\'llanma havola';

// Help
$_['help_generator']  = 'Siz havola yaratmoqchi bo\'lgan mahsulot nomini kiriting.';
