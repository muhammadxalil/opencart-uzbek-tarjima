<?php
// Heading
$_['heading_title']  = 'Parolni o\'zgartirish';

// Text
$_['text_account']   = 'Hamkor kabineti';
$_['text_password']  = 'Sizning parol';
$_['text_success']   = 'Sizning parol muvaffaqiyatli o\'zgartirildi!';

// Entry
$_['entry_password'] = 'Parol';
$_['entry_confirm']  = 'Parolni tasdiqlash';

// Error
$_['error_password'] = 'Parol 4 tadan 20 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_confirm']  = 'Parol va tasdiqlash paroli bir-biriga mos kelmadi!';
