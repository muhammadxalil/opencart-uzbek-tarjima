<?php
// Heading
$_['heading_title']     = 'Mening ma\'lumotim';

// Text
$_['text_account']      = 'Hamkor kabineti';
$_['text_edit']         = 'Ma\'lumotni tahrirlash';
$_['text_your_details'] = 'Sizning shaxsiy ma\'lumotlaringiz';
$_['text_your_address'] = 'Sizning manzil';
$_['text_success']      = 'Sizning hisob qaydnomangiz muvaffaqiyatli yangilandi.';

// Entry
$_['entry_firstname']   = 'Ism, Otasining ismi';
$_['entry_lastname']    = 'Familiya';
$_['entry_email']       = 'E-Mail';
$_['entry_telephone']   = 'Telefon raqami';
$_['entry_fax']         = 'Faks';
$_['entry_company']     = 'Kompaniya';
$_['entry_website']     = 'Veb sayt';
$_['entry_address_1']   = 'Manzil';
$_['entry_address_2']   = 'Manzil (davomi)';
$_['entry_postcode']    = 'Pochta indeksi';
$_['entry_city']        = 'Shahar';
$_['entry_country']     = 'Mamlakat';
$_['entry_zone']        = 'Tuman / Viloyat';

// Error
$_['error_exists']      = 'Ushbu elektron pochta allaqachon ro'yxatdan o'tgan!';
$_['error_firstname']   = 'Ism 1-32 belgidan iborat bo\'lishi kerak!';
$_['error_lastname']    = 'Familiya 1-32 belgidan iborat bo\'lishi kerak!';
$_['error_email']       = 'Elektron pochta manzili noto\'g\'ri kiritilgan!';
$_['error_telephone']   = 'Telefon raqami 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_address_1']   = 'Manzil 3-128 belgidan iborat bo\'lishi kerak!';
$_['error_city']        = 'Shahar nomi 2 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_country']     = 'Iltimos, mamlakatni tanlang!';
$_['error_zone']        = 'Iltimos, tuman / viloyatni tanlang!';
$_['error_postcode']    = 'Pochta indeksi 2 tadan 10 tagacha belgidan iborat bo\'lishi kerak!';
