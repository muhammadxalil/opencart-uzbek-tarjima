<?php
// Heading
$_['heading_title']     = 'Mening ma\'lumotlarim';

// Text
$_['text_account']      = 'Hamkorlar kabineti';
$_['text_edit']         = 'Ma\'lumotni tahrirlash';
$_['text_your_details'] = 'Sizning shaxsiy ma\'lumotlaringiz';
$_['text_your_address'] = 'Sizning manzilingiz';
$_['text_success']      = 'Sizning hisobingiz muvaffaqiyatli yangilandi.';

// Entry
$_['entry_firstname']   = 'Ism';
$_['entry_lastname']    = 'Familiya';
$_['entry_email']       = 'E-Mail';
$_['entry_telephone']   = 'Telefon';
$_['entry_fax']         = 'Faks';
$_['entry_company']     = 'Kompaniya';
$_['entry_website']     = 'Veb-sayt';
$_['entry_address_1']   = 'Manzil';
$_['entry_address_2']   = 'Manzil (davomi)';
$_['entry_postcode']    = 'Pochta indeksi';
$_['entry_city']        = 'Shahar';
$_['entry_country']     = 'Mamlakat';
$_['entry_zone']        = 'Viloyat / tuman';

// Error
$_['error_exists']      = 'Данный E-Mail уже зарегистрирован!';
$_['error_firstname']   = 'Имя должно быть от 1 до 32 символов!';
$_['error_lastname']    = 'Фамилия должна быть от 1 до 32 символов!';
$_['error_email']       = 'E-Mail адрес введен неверно!';
$_['error_telephone']   = 'Номер телефона должен быть от 3 до 32 символов!';
$_['error_address_1']   = 'Адрес должен быть от 3 до 128 символов!';
$_['error_city']        = 'Название города должно быть от 2 до 128 символов!';
$_['error_country']     = 'Пожалуйста, выберите страну!';
$_['error_zone']        = 'Пожалуйста, выберите регион / область';
$_['error_postcode']    = 'Индекс должен быть от 2 до 10 символов!';
