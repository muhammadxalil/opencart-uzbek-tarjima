<?php
// Heading
$_['heading_title'] = 'Hamkor kabinetidan chiqish';

// Text
$_['text_message']  = '<p>Siz Hamkorlik hisob qaydnomangizdan muvaffaqiyatli chiqdingiz.</p>';
$_['text_account']  = 'Hamkor hisob qaydnomasi';
$_['text_logout']   = 'Chiqish';
