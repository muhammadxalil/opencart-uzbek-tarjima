<?php
// Heading
$_['heading_title']             = 'To\'lov usuli';

// Text
$_['text_account']              = 'Hamkor kabineti';
$_['text_payment']              = 'To\'lov';
$_['text_your_payment']         = 'Sizning o\'tkazmalaringiz';
$_['text_your_password']        = 'Parol';
$_['text_cheque']               = 'Chek';
$_['text_paypal']               = 'PayPal';
$_['text_bank']                 = 'Bank o\'tkazmasi';
$_['text_success']              = 'Hamkorning qaydnoma ma\'lumotlari muvaffaqiyatli yangilandi.';

// Entry
$_['entry_tax']                 = 'INN';
$_['entry_payment']             = 'To\'lov usuli';
$_['entry_cheque']              = 'Chekni oluvchining ismi.';
$_['entry_paypal']              = 'PayPal Email akkaunt';
$_['entry_bank_name']           = 'Bank nomi';
$_['entry_bank_branch_number']  = 'Bo\'lim raqami';
$_['entry_bank_swift_code']     = 'BIK';
$_['entry_bank_account_name']   = 'Hisob raqami nomi';
$_['entry_bank_account_number'] = 'Hisob raqami';

