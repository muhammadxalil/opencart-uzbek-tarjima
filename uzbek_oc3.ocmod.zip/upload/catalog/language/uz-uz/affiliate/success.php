<?php
// Heading
$_['heading_title'] = 'Hamkor hisobi muvaffaqiyatli yaratildi!';

// Text
$_['text_message']  = '<p>Tabriklaymiz. Sizning Hamkorlik hisob qaydnomangiz muvaffaqiyatli yaratildi!</p> <p>Endi siz biz bilan daromadingizni oshirish uchun hamkorning afzalliklaridan foydalanishingiz mumkin.</p> <p>.</p> <p>Hamkorlik dasturi haqida savollaringiz bo\'lsa, iltimos <a href="%s"> biz bilan bog\'laning</a>.</p>';
$_['text_approval'] = '<p>Yangi %s hamkorni ro\'yxatdan o\'tkazganingiz uchun tashakkur!</p><p>Hisobni do\'kon ma\'muriyati faollashtirgandan so\'ng siz elektron pochta xabarini olasiz.</p><p>Hamkorlik dasturi haqida savollaringiz bo\'lsa, iltimos <a href="%s"> biz bilan bog\'laning</a>.</p>';
$_['text_account']  = 'Hamkor kabineti';
$_['text_success']  = 'Muvaffaqiyatli';


