<?php
// Heading
$_['heading_title']      = 'To\'lovlar tarixi';

// Column
$_['column_date_added']  = 'Qo\'shilgan';
$_['column_description'] = 'Ta\'rif';
$_['column_amount']      = 'Miqdor (%s)';

// Text
$_['text_account']       = 'Hamkor kabineti';
$_['text_transaction']   = 'To\'lovlar';
$_['text_balance']       = 'Sizning joriy balansingiz';
$_['text_empty']         = 'Sizda to\'lovlar yo\'q!';

