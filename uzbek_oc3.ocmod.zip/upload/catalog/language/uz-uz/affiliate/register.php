<?php
// Heading
$_['heading_title']             = 'Hamkorlik dasturi';

// Text
$_['text_account']              = 'Hamkor kabineti';
$_['text_register']             = 'Hamkorni ro\'yxatdan o\'tkazish';
$_['text_account_already']      = 'Agar siz allaqachon hamkorlik loginiga ega bo\'lsangiz, iltimos <a href="%s"> tizimga kiring </a>.';
$_['text_signup']               = 'Hamkor hisobini yaratish uchun siz ro\'yxatdan o\'tish anketasini to\'ldirishingiz kerak';
$_['text_your_details']         = 'Shaxsiy ma\'lumotlaringiz';
$_['text_your_address']         = 'Sizning manzilingiz';
$_['text_payment']              = 'To\'lov ma\'lumotlari';
$_['text_your_password']        = 'Parol';
$_['text_cheque']               = 'Chek';
$_['text_paypal']               = 'PayPal';
$_['text_bank']                 = 'Bank o\'tkazmasi';
$_['text_agree']                = 'Men <a href="%s" class="agree"> <b>% s </b> </a> ni o\'qib chiqdim va shartlariga roziman';

// Entry
$_['entry_firstname']           = 'Ism, Otasining ismi';
$_['entry_lastname']            = 'Familiya';
$_['entry_email']               = 'E-Mail';
$_['entry_telephone']           = 'Telefon raqami';
$_['entry_fax']                 = 'Faks';
$_['entry_company']             = 'Kompaniya';
$_['entry_website']             = 'Sayt';
$_['entry_address_1']           = 'Manzil 1';
$_['entry_address_2']           = 'Manzil 2';
$_['entry_postcode']            = 'Indeks';
$_['entry_city']                = 'Shahar';
$_['entry_country']             = 'Mamlakat';
$_['entry_zone']                = 'Tuman / Viloyat';
$_['entry_tax']                 = 'INN';
$_['entry_payment']             = 'To\'lov usuli';
$_['entry_cheque']              = 'Chek qabul qiluvchining ismi';
$_['entry_paypal']              = 'PayPal Email hisobi';
$_['entry_bank_name']           = 'Bank nomi';
$_['entry_bank_branch_number']  = 'Filial raqami';
$_['entry_bank_swift_code']     = 'BIK';
$_['entry_bank_account_name']   = 'Tuzatish hisobi';
$_['entry_bank_account_number'] = 'Hisob raqami';
$_['entry_password']            = 'Parol';
$_['entry_confirm']             = 'Parolni tasdiqlash';

// Error
$_['error_exists']              = 'Ushbu elektron pochta allaqachon ro\'yxatdan o\'tgan!';
$_['error_firstname']           = 'Ism 1-32 belgidan iborat bo\'lishi kerak!';
$_['error_lastname']            = 'Familiya 1-32 belgidan iborat bo\'lishi kerak!';
$_['error_email']               = 'Elektron pochta manzili noto\'g\'ri kiritilgan!';
$_['error_telephone']           = 'Telefon raqami 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_password']            = 'Parol 4 tadan 20 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_confirm']             = 'Parol va tasdiqlash paroli bir-biriga mos emas!';
$_['error_address_1']           = 'Manzil 3-128 belgidan iborat bo\'lishi kerak!';
$_['error_city']                = 'Shahar nomi 2 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_country']             = 'Iltimos, mamlakatni tanlang!';
$_['error_zone']                = 'Iltimos, tuman / viloyatni tanlang!';
$_['error_postcode']            = 'Pochta indeksi 2 tadan 10 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_agree']               = 'Diqqat. Siz %s ni o\'qib, unga rozi bo\'lishingiz kerak!';
