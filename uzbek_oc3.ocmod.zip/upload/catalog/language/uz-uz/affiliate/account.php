<?php
// Heading
$_['heading_title']        = 'Hamkorlik bo\'limi';

// Text
$_['text_account']         = 'Hamkorning kabineti';
$_['text_my_account']      = 'Mening hisob qaydnomam';
$_['text_my_tracking']     = 'Mening referal kodlarim';
$_['text_my_transactions'] = 'To\'lovlar tarixi';
$_['text_edit']            = 'Hisob qaydnomasini tahrirlash';
$_['text_password']        = 'Parolni o\'zgartirish';
$_['text_payment']         = 'To\'lov rekvizitlarini o\'zgartirish';
$_['text_tracking']        = 'Yo\'llanma(referal) kodi';
$_['text_transaction']     = 'To\'lovlar tarixini ko\'rish';

