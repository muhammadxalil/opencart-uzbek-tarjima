<?php
// Heading
$_['heading_title']        = 'Hamkorlar bo\'limi';

// Text
$_['text_account']         = 'Hamkorlar kabineti';
$_['text_my_account']      = 'Mening hisobim';
$_['text_my_tracking']     = 'Mening tavsiyam';
$_['text_my_transactions'] = 'To\'lov tarixi';
$_['text_edit']            = 'Hisobni tahrirlash';
$_['text_password']        = 'Kalit so\'zni o\'zgartirish';
$_['text_payment']         = 'To\'lov ma\'lumotlarini o\'zgartiring';
$_['text_tracking']        = 'Yo\'naltiruvchi kod';
$_['text_transaction']     = 'To\'lov tarixini ko\'rish';

