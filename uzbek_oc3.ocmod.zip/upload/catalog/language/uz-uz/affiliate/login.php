<?php
// Heading
$_['heading_title']                 = 'Hamkorlik dasturi';

// Text
$_['text_account']                  = 'Hamkor kabineti';
$_['text_login']                    = 'Kirish';
$_['text_description']              = '<p>%s hamkorlik dasturi mutlaqo bepul va a\'zolarga bizning %s do\'konimizga yoki individual mahsulotlarimizga havolalar qo\'yib qo\'shimcha daromad olish imkonini beradi. Hamkorlik aloqasi orqali amalga oshirilgan har bir xarid agentlik komissiyasini olib keladi. Oddiy to\'lov - %s. </p> <p> Qo\'shimcha ma\'lumot olish uchun hamkorlar ma\'lumot sahifasiga murojaat qiling.</p>';
$_['text_new_affiliate']            = 'Yangi Hamkor';
$_['text_register_account']         = '<strong>Men Hamkor emasman.</strong><p>Hamkor hisobini yaratish uchun "Oldinga" ni bosing. Esda tutingki, bu hisob har qanday mijozlar hisobi bilan bog\'liq emas!</p>';
$_['text_returning_affiliate']      = 'Hamkorning logini';
$_['text_i_am_returning_affiliate'] = 'Men allaqachon ro\'yxatdan o\'tganman.';
$_['text_forgotten']                = 'Parolni unutdingizmi?';

// Entry
$_['entry_email']                   = 'Hamkorlik E-Maili:';
$_['entry_password']                = 'Parol:';

// Error
$_['error_login']                   = 'Kiritilgan elektron pochta manzili topilmadi va / yoki parol noto\'g\'ri.';
$_['error_attempts']               = 'Siz avtorizatsiya qilish urinishlarining maksimal miqdoridan oshib ketdingiz. 1 soatdan keyin saytda avtorizatsiyani qaytadan sinab ko\'ring';
$_['error_approved']                = 'Sizning hisobingiz hali tasdiqlanmagan. Ma\'muriyat sizning hisobingizni tez orada tasdiqlashini kuting.';
