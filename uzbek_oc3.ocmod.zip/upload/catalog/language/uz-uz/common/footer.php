<?php
// Text
$_['text_information']  = 'Ma\'lumot';
$_['text_service']      = 'Qo\'llab-quvvatlash xizmati';
$_['text_extra']        = 'Qo\'shimcha';
$_['text_contact']      = 'Qayta aloqa';
$_['text_return']       = 'Tovarni qaytarish';
$_['text_sitemap']      = 'Sayt xaritasi';
$_['text_manufacturer'] = 'Ishlab chiqaruvchilar';
$_['text_voucher']      = 'Sovg\'a vaucherlari';
$_['text_affiliate']    = 'Hamkorlik dasturi';
$_['text_special']      = 'Aktsiyalar';
$_['text_account']      = 'Shaxsiy kabinet';
$_['text_order']        = 'Buyurtmalar tarixi';
$_['text_wishlist']     = 'Xatcho\'plar';
$_['text_newsletter']   = 'Axborot byulleteni';
$_['text_powered']      = 'Ushbu havolada <a href="http://opencart3x.ru">OpenCart ruscha versiyasida ishlaydi</a><br /> %s &copy; %s';
