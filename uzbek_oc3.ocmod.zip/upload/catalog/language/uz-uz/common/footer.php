<?php
// Text
$_['text_information']  = 'Ma\'lumot';
$_['text_service']      = 'Qo\'llab-quvvatlash xizmati';
$_['text_extra']        = 'Qo\'shimcha';
$_['text_contact']      = 'Qayta aloqa';
$_['text_return']       = 'Xarid qilish natijalari';
$_['text_sitemap']      = 'Sayt xaritasi';
$_['text_manufacturer'] = 'Ishlab chiqaruvchilar';
$_['text_voucher']      = 'Sovg\'a sertifikatlari';
$_['text_affiliate']    = 'Sheriklik dasturi';
$_['text_special']      = 'Aktsiyalar';
$_['text_account']      = 'Shaxsiy kabinet';
$_['text_order']        = 'Buyurtmalar tarixi';
$_['text_wishlist']     = 'Istaklar';
$_['text_newsletter']   = 'Axborot byulleteni';
$_['text_powered']      = 'All rights reserved. <a href="https://wasaf.uz">Wasaf.uz</a><br /> %s &copy; %s';
