<?php
// Text
$_['text_home']          = 'Asosiy';
$_['text_wishlist']      = 'Istaklar (%s)';
$_['text_shopping_cart'] = 'Savat';
$_['text_category']      = 'Kategoriyalar';
$_['text_account']       = 'Shaxsiy kabinet';
$_['text_register']      = 'Belgilanish';
$_['text_login']         = 'Ruxsat';
$_['text_order']         = 'Buyurtmalar tarixi';
$_['text_transaction']   = 'Tranzaksiyalar';
$_['text_download']      = 'Yuklamalar';
$_['text_logout']        = 'Chiqish';
$_['text_checkout']      = 'Buyurtma';
$_['text_search']        = 'Qidirmoq';
$_['text_all']           = 'Barchasini ko\'ring';
