<?php
// Text
$_['text_home']          = 'Asosiy';
$_['text_wishlist']      = 'Xatcho\'plar (%s)';
$_['text_shopping_cart'] = 'Savat';
$_['text_category']      = 'Toifalar';
$_['text_account']       = 'Shaxsiy kabinet';
$_['text_register']      = 'Ro\'yxatdan o\'tish';
$_['text_login']         = 'Kirish';
$_['text_order']         = 'Buyurtmalar tarixi';
$_['text_transaction']   = 'Bitimlar';
$_['text_download']      = 'Yuklamalar';
$_['text_logout']        = 'Chiqish';
$_['text_checkout']      = 'Buyurtmani rasmiylashtirish';
$_['text_search']        = 'Izlash';
$_['text_all']           = 'Hammasini ko\'rish';
