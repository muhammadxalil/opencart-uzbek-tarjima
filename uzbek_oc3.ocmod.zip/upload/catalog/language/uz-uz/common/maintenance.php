<?php
// Heading
$_['heading_title']    = 'Hizmat ko\'rsatish tartibi';

// Text
$_['text_maintenance'] = 'Do\'kon vaqtinchalik yopiq';
$_['text_message']     = '<h1 style="text-align:center;">Do\'kon vaqtinchalik yopiq. Profilaktika ishlari olib borilyapti.<br />Tez kunda do\'kon ochiladi. Iltimos, keyinroq kiring.</h1>';

