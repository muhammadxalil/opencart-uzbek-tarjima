<?php
// Heading
$_['heading_title']    = 'Xizmat qilish tartibi';

// Text
$_['text_maintenance'] = 'Do\'kon vaqtincha yopilgan';
$_['text_message']     = '<h1 style="text-align:center;">Магазин временно закрыт. Мы выполняем профилактические работы.<br />Вскоре магазин будет доступен. Пожалуйста, зайдите позже.</h1>';

