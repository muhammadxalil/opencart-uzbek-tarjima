<?php
// Text
$_['text_items']    = 'Mahsulotlar %s (%s)';
$_['text_empty']    = 'Savatingiz bo\'sh!';
$_['text_cart']     = 'Savatga o\'ting';
$_['text_checkout'] = 'Tekshirib ko\'rmoq';
$_['text_recurring']  = 'To\'lov profili';

