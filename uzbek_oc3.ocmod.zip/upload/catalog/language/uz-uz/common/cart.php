<?php
// Text
$_['text_items']    = 'Tovarlar %s (%s)';
$_['text_empty']    = 'Savatingiz bo\'sh!';
$_['text_cart']     = 'Savatga o\'tish';
$_['text_checkout'] = 'Buyurtma berish';
$_['text_recurring']  = 'Hisob-kitob profili';

