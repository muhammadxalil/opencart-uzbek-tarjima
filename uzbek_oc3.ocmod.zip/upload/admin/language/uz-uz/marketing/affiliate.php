<?php
// Heading
$_['heading_title']             = 'Hamkorlik dasturi';

// Text
$_['text_success']              = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_approved']             = 'Ожидают активации %s аккаунта!';
$_['text_list']                 = 'Список партнеров';
$_['text_add']                  = 'Qo\'shish';
$_['text_edit']                 = 'Tahrirlash';
$_['text_affiliate_detail']     = 'Ma\'lumot';
$_['text_affiliate_address']    = 'Manzil';
$_['text_balance']              = 'Balans';
$_['text_cheque']               = 'Chek';
$_['text_paypal']               = 'PayPal';
$_['text_bank']                 = 'Bank o\'tkazmasi';

// Column
$_['column_name']               = 'Hamkorning ismi';
$_['column_email']              = 'E-Mail';
$_['column_code']               = 'Yo\'llanma kodi';
$_['column_balance']            = 'Balans';
$_['column_status']             = 'Holati';
$_['column_approved']           = 'Faollashtirish';
$_['column_date_added']         = 'Sana';
$_['column_description']        = 'Ta\'rif';
$_['column_amount']             = 'Miqdor';
$_['column_action']             = 'Harakat';

// Entry
$_['entry_firstname']           = 'Ism';
$_['entry_lastname']            = 'Familiya';
$_['entry_email']               = 'E-Mail';
$_['entry_telephone']           = 'Telefon';
$_['entry_fax']                 = 'Faks';
$_['entry_status']              = 'Holati';
$_['entry_password']            = 'Parol';
$_['entry_confirm']             = 'Parolni tasdiqlang';
$_['entry_company']             = 'Kompaniya';
$_['entry_website']             = 'Veb-sayt';
$_['entry_address_1']           = 'Manzil 1';
$_['entry_address_2']           = 'Manzil 2';
$_['entry_city']                = 'Shahar';
$_['entry_postcode']            = 'Indeks';
$_['entry_country']             = 'Davlat';
$_['entry_zone']                = 'Tuman / Viloyat';
$_['entry_code']                = 'Referal kod';
$_['entry_commission']          = 'Komissiya (%)';
$_['entry_tax']                 = 'INN';
$_['entry_payment']             = 'To\'lov usuli';
$_['entry_cheque']              = 'Chek qabul qiluvchining ismi';
$_['entry_paypal']              = 'PayPal E-Mail akkaunti';
$_['entry_bank_name']           = 'Bank nomi';
$_['entry_bank_branch_number']  = 'Bo\'lim nomi';
$_['entry_bank_swift_code']     = 'BIK';
$_['entry_bank_account_name']   = 'Hisob raqam nomi';
$_['entry_bank_account_number'] = 'Hisob raqami';
$_['entry_amount']              = 'Miqdor';
$_['entry_description']         = 'Ta\'rif';
$_['entry_name']                = 'Hamkor ismi';
$_['entry_approved']            = 'Faollashtirilgan';
$_['entry_date_added']          = 'Sana';

// Help
$_['help_code']                 = 'Ushbu kod yo\'llangan kodlarni kuzatish uchun ishlatiladi.';
$_['help_commission']           = 'Hamkor har bir buyurtma uchun oladigan foiz.';

// Error
$_['error_warning']             = 'Diqqat! Formani xatolarini tekshiring!';
$_['error_permission']          = 'Sizda sheriklik dasturi sozlamalarini o\'zgartirish huquqin yo\'q!';
$_['error_exists']              = 'Ushbu elektron pochta allaqachon kimdir tomonidan ro\'yxatga olingan!';
$_['error_firstname']           = 'Ism 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_lastname']            = 'Familiya 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_email']               = 'Noto\'g\'ri E-Mail';
$_['error_cheque']              = 'To\'ldirilishi zarur!';
$_['error_paypal']              = 'Noto\'g\'ri PayPal E-Mail!';
$_['error_bank_account_name']   = 'To\'ldirilishi shart!';
$_['error_bank_account_number'] = 'To\'ldirilishi shart!';
$_['error_telephone']           = 'Telefon 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_password']            = 'Parol 3 tadan 20 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_confirm']             = 'Parol va tasdiqlash parollari bir-biriga mos kelmaydi!';
$_['error_address_1']           = 'Manzil 3 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_city']                = 'Shahar 2 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_postcode']            = 'Indeks 2 tadan 10 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_country']             = 'Shaharni tanlang!';
$_['error_zone']                = 'Tuman / Viloyatni tanlang';
$_['error_code']                = 'Yo\'llanma kodni kiritish zarur!';
$_['error_code_exists']         = 'Ko\'rsatilgan kuzatuv kodi boshqa hamkor tomonidan ishlatilyapti!';


