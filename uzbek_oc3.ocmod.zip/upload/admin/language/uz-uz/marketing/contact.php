<?php
// Heading
$_['heading_title']        = 'Pochta';

// Text
$_['text_success']         = 'Xabar muvaffaqiyatli yuborildi!';
$_['text_sent']            = 'Xabar %s qabul qiluvchilardan %stasiga muvaffaqiyatli yuborildi!';
$_['text_list']            = 'Pochta';
$_['text_default']         = 'Sukut bo\'yicha';
$_['text_newsletter']      = 'Barcha obunachilar yangiliklariga';
$_['text_customer_all']    = 'Barcha mijozlarga';
$_['text_customer_group']  = 'Mijozlar guruhi';
$_['text_customer']        = 'Mijozlar';
$_['text_affiliate_all']   = 'Barcha hamkorlarga';
$_['text_affiliate']       = 'Hamkorlar';
$_['text_product']         = 'Mahsulotlar';

// Entry
$_['entry_store']          = 'Kimdan';
$_['entry_to']             = 'Kimga';
$_['entry_customer_group'] = 'Mijozlar guruhi';
$_['entry_customer']       = 'Mijoz';
$_['entry_affiliate']      = 'Hamkor';
$_['entry_product']        = 'Mahsulotlar';
$_['entry_subject']        = 'Sarlavha';
$_['entry_message']        = 'Xabar';

// Help
$_['help_customer']        = 'Avtomatik tugatish';
$_['help_affiliate']       = 'Avtomatik tugatish';
$_['help_product']         = 'Ro\'yxatdagi narsalarga buyurtma bergan mijozlarga yuboring. (Avtomatik tugatish)';

// Error
$_['error_permission']     = 'Sizda xabar yuborish huquqi yo\'q!';
$_['error_subject']        = 'Xabar sarlavhasini kiritish kerak!';
$_['error_message']        = 'Xabar matnini kiritish kerak!';


