<?php
// Heading
$_['heading_title']       = 'Kuponlar';

// Text
$_['text_success']        = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']           = 'Kuponlar';
$_['text_add']            = 'Qo\'shish';
$_['text_edit']           = 'Tahrirlash';
$_['text_percent']        = 'Foiz';
$_['text_amount']         = 'Qat\'iy belgilangan miqdor';

// Column
$_['column_name']         = 'Kupon nomi';
$_['column_code']         = 'Kod';
$_['column_discount']     = 'Chegirma';
$_['column_date_start']   = 'Boshlanish sanasi';
$_['column_date_end']     = 'Tugash muddati';
$_['column_status']       = 'Holati';
$_['column_order_id']     = 'Buyurtma raqami';
$_['column_customer']     = 'Xaridor';
$_['column_amount']       = 'Miqdor';
$_['column_date_added']   = 'Sana';
$_['column_action']       = 'Harakat';

// Entry
$_['entry_name']          = 'Kupon nomi';
$_['entry_code']          = 'Kod';
$_['entry_type']          = 'Turi';
$_['entry_discount']      = 'Chegirma';
$_['entry_logged']        = 'Mijozni avtorizatsiya qilish';
$_['entry_shipping']      = 'Bepul yetkazib berish';
$_['entry_total']         = 'Umumiy miqdor';
$_['entry_category']      = 'Kategoriya';
$_['entry_product']       = 'Mahsulotlar';
$_['entry_date_start']    = 'Boshlanish sanasi';
$_['entry_date_end']      = 'Tugash sanasi';
$_['entry_uses_total']    = 'Kupondan foydalanish soni';
$_['entry_uses_customer'] = 'Bir mijoz tomonidan foydalanilganlar soni';
$_['entry_status']        = 'Holati';

// Help
$_['help_code']           = 'Ushbu kodni mijoz chegirma olishga kiritadi.';
$_['help_type']           = 'Foiz bog\'liqligi yoki belgilangan miqdor.';
$_['help_logged']         = 'Kupondan foydalanish uchun mijoz tizimga kirishi kerak.';
$_['help_total']          = 'Kupon amal qila boshlaydigan minimal miqdor.';
$_['help_category']       = 'Kupon tanlangan toifadagi barcha mahsulotlar uchun amal qiladi..';
$_['help_product']        = 'Kupon tanlangan mahsulot (lar) uchun amal qiladi. Agar mahsulot tanlanmagan bo\'lsa, unda kupon butun savat uchun amal qiladi';
$_['help_uses_total']     = 'Kupondan maksimal necha marta foydalanishingiz mumkin. Cheksiz foydalanish uchun bo\'sh qoldiring.';
$_['help_uses_customer']  = 'Maksimal necha marta mijoz bitta kupondan foydalanishi mumkin. Cheksiz foydalanish uchun bo\'sh qoldiring.';

// Error
$_['error_permission']    = 'Kuponlar modulining sozlamalarini o\'zgartirish huquqiga ega emassiz!';
$_['error_exists']        = 'Ushbu kupon kodi allaqachon ishlatilyapti!';
$_['error_name']          = 'Kupon nomi 3 tadan 128 tagacha belgi bo\'lishi kerak!';
$_['error_code']          = 'Kupon kodi 3 tadan 10 tagacha belgidan iborat bo\'lishi kerak!';

