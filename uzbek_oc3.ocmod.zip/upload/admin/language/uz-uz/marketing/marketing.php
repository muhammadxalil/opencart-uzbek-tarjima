<?php
// Heading
$_['heading_title']     = 'Marketing aksiyasi';

// Text
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']         = 'Marketing aksiyasi';
$_['text_add']          = 'Qo\'shish';
$_['text_edit']         = 'Tahrirlash';

// Column
$_['column_name']       = 'Aksiya nomi';
$_['column_code']       = 'Kod';
$_['column_clicks']     = 'O\'tishlar';
$_['column_orders']     = 'Buyurtmalar';
$_['column_date_added'] = 'Sana';
$_['column_action']     = 'Harakat';

// Entry
$_['entry_name']        = 'Aksiya nomi';
$_['entry_description'] = 'Aksiya ta\'tifi';
$_['entry_code']        = 'Kuzatuv kodi';
$_['entry_example']     = 'Namuna';
$_['entry_date_added']  = 'Sana';

// Help
$_['help_code']         = 'Ushbu kod marketing aktsiyalarining sotilishini kuzatish uchun ishlatiladi.';
$_['help_example']      = 'Shunday qilib, URL-ning oxirida saytingizga yoki mahsulotingizga saytga bog\'langan kuzatuv kodini qo\'shishingiz mumkin.';

// Error
$_['error_permission']  = 'Sizga Marketing Aksiyasi moduli sozlamalarini o\'zgartirish huquqi yo\'q!';
$_['error_name']        = 'Aksiya nomida 3 tadan 32 tagacha belgi bo\'lishi kerak!';
$_['error_code']        = 'Kuzatuv kodini kiritish kerak!';
$_['error_exists']      = 'Kuzatish kodi boshqa taraf tomonidan ishlatilmoqda!';


