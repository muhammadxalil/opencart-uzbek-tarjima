<?php
// Heading
$_['heading_title']   = 'Ruxsat berilmadi!';

// Text
$_['text_permission'] = 'Sizda ushbu sahifaga kirish huquqi mavjud emas. Agar sizga kerak bo\'lsa, administratorga murojaat qiling.';

