<?php
// Heading
$_['heading_title']  = 'Sahifa topilmadi!';

// Text
$_['text_not_found'] = 'Siz so\'ragan sahifa topilmadi. Agar muammo takrorlansa, administratorga murojaat qiling.';

