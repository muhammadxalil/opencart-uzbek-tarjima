<?php
// Heading
$_['heading_title']                        = 'Davriy buyurtmalar';

// Text
$_['text_success']                         = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']                            = 'Davriy buyurtmalar';
$_['text_recurring_detail']                = 'Batafsil';
$_['text_order_detail']                    = 'Buyurtma';
$_['text_product_detail']                  = 'Mahsulot';
$_['text_transaction']                     = 'Bitimlar';
$_['text_order_recurring_id']              = 'Davriy buyurtma raqami';
$_['text_reference']                       = 'To\'lov';
$_['text_recurring_name']                  = 'Profil';
$_['text_recurring_description']           = 'Ta\'rif';
$_['text_recurring_status']                = 'Holati';
$_['text_payment_method']                  = 'To\'lov usuli';
$_['text_order_id']                        = 'Buyurtma raqami';
$_['text_customer']                        = 'Xaridor';
$_['text_email']                           = 'Email';
$_['text_date_added']                      = 'Sana';
$_['text_order_status']                    = 'Buyurtma holati';
$_['text_type']                            = 'Turi';
$_['text_action']                          = 'Harakat';
$_['text_product']                         = 'Mahsulot';
$_['text_quantity']                        = 'Miqdori';
$_['text_amount']                          = 'Miqdor';
$_['text_cancel_payment']                  = 'To\'lovni bekor qilish';
$_['text_status_1']                        = 'Faol';
$_['text_status_2']                        = 'Faol emas';
$_['text_status_3']                        = 'Bekor qilingan';
$_['text_status_4']                        = 'Muzlatilgan';
$_['text_status_5']                        = 'Muddati o\'tgan';
$_['text_status_6']                        = 'Kutilyapti';

$_['text_transactions']                    = 'Operatsiya';
$_['text_cancel_confirm']                  = 'Ushbu harakat orqaga qaytarilmaydi. Ishonchingiz komilmi?';
$_['text_transaction_date_added']          = 'Yaratilish sanasi';
$_['text_transaction_payment'] 			   = 'To\'lov';
$_['text_transaction_outstanding_payment'] = 'To\'lov qabul qilinmagan';
$_['text_transaction_skipped']             = 'To\'lov o\'tkazib yuborildi';
$_['text_transaction_failed']              = 'To\'lov muammosi';
$_['text_transaction_cancelled']           = 'Bekor qilingan';
$_['text_transaction_suspended']           = 'Muzlatilgan';
$_['text_transaction_suspended_failed']    = 'Muzlatilgan. To\'lov xatolari';
$_['text_transaction_outstanding_failed']  = 'To\'lov xatolari';
$_['text_transaction_expired']             = 'Muddati tugagan';
$_['text_cancelled']                       = 'Davriy to\'lov o\'chirilgan';

// Column
$_['column_order_recurring_id']             = 'Davriy buyurtma raqami';
$_['column_order_id']                       = 'Buyurtma raqami';
$_['column_reference']                      = 'Оплата';
$_['column_customer']                       = 'Xaridor';
$_['column_date_added']                     = 'Sana';
$_['column_status']                         = 'Holati';
$_['column_amount']                         = 'Miqdor';
$_['column_type']                           = 'Turi';
$_['column_action']                         = 'Harakat';

// Entry
$_['entry_order_recurring_id']             = 'Davriy buyurtma raqami';
$_['entry_order_id']                       = 'Buyurtma raqami';
$_['entry_reference']                      = 'To\'lov usuli';
$_['entry_customer']                       = 'Xaridor';
$_['entry_date_added']                     = 'Yaratilish sanasi';
$_['entry_status']                         = 'Holati';
$_['entry_type']                           = 'Turi';
$_['entry_action']                         = 'Harakat';
$_['entry_email']                          = 'Email';
$_['entry_description']                    = 'Profil tavsifi';
$_['entry_product']                        = 'Mahsulot';
$_['entry_quantity']                       = 'Miqdori';
$_['entry_amount']                         = 'Miqdor';
$_['entry_recurring']                      = 'Profil';
$_['entry_payment_method']                 = 'To\'lov usuli';
$_['entry_cancel_payment']                 = 'To\'lovni bekor qilish';

// Error
$_['error_not_cancelled']                  = 'Xatolik: %s';
$_['error_not_found']                      = 'Profilni o\'chirib bo\'lmaydi';

