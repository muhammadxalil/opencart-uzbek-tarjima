<?php
// Heading
$_['heading_title']     = 'Sovg\'a vaucheri';

// Text
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']         = 'Sovg\'a vaucherlari';
$_['text_add']          = 'Qo\'shish';
$_['text_edit']         = 'Tahrirlash';
$_['text_sent']         = 'Sovg\'a vaucheri e-mailga jo\'natildi!';

// Column
$_['column_name']       = 'Sovg\'a vaucherining nomi';
$_['column_code']       = 'Kod';
$_['column_from']       = 'Kimdan';
$_['column_to']         = 'Kimga';
$_['column_theme']      = 'Mavzu';
$_['column_amount']     = 'Miqdor';
$_['column_status']     = 'Holati';
$_['column_order_id']   = 'Buyurtma raqami';
$_['column_customer']   = 'Mijoz';
$_['column_date_added'] = 'Qo\'shilgan sanasi';
$_['column_action']     = 'Harakat';

// Entry
$_['entry_code']        = 'Kod';
$_['entry_from_name']   = 'Jo\'natuvchi ismi';
$_['entry_from_email']  = 'Jo\'natuvchi E-Maili';
$_['entry_to_name']     = 'Qabul qiluvchi ismi';
$_['entry_to_email']    = 'Qabul qiluvchi E-Maili';
$_['entry_theme']       = 'Mavzu';
$_['entry_message']     = 'Xabar';
$_['entry_amount']      = 'Miqdor';
$_['entry_status']      = 'Holati';

// Help
$_['help_code']         = 'Sovg\'a sertifikatini faollashtirish uchun mijoz kiritadigan kod';

// Error
$_['error_selection']   = 'Diqqat! Sertifikat tanlanmagan';
$_['error_permission']  = 'Sizda Sovg\'a vaucheri sozlamalarini o\'zgartirish huquqi yo\'q!';
$_['error_exists']      = 'Ushbu Sovg\'a sertifikati allaqachon ishlatilmoqda!';
$_['error_code']        = 'Kod 3 tadan 10 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_to_name']     = 'Qabul qiluvchining ismi 1-64 belgidan iborat bo\'lishi kerak!';
$_['error_from_name']   = 'Ismingiz 1 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_email']       = 'E-Mail manzil noto\'g\'ri kiritilgan!';
$_['error_amount']      = 'Miqdor birdan katta yoki teng bo\'lishi kerak!';
$_['error_order']       = 'Ushbu sertifikatni o\'chirib bo\'lmaydi chunki u <a href="%s">buyurtmaning bir qismi</a>!';

