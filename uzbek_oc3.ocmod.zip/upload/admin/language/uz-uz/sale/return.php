<?php
// Heading
$_['heading_title']       = 'Tovarlarning qaytarilishi';

// Text
$_['text_success']        = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']           = 'Tovarlarning qaytarilishi';
$_['text_add']            = 'Qo\'shish';
$_['text_edit']           = 'Tahrirlash';
$_['text_opened']         = 'O\'ram ochilgan';
$_['text_unopened']       = 'Ochilmagan';
$_['text_order']          = 'Buyurtma haqida ma\'lumot';
$_['text_product']        = 'Mahsulotlar';
$_['text_history']        = 'Qo\'shish';

// Column
$_['column_return_id']     = 'Qaytarma raqami';
$_['column_order_id']      = 'Buyurtma raqami';
$_['column_customer']      = 'Mijoz';
$_['column_product']       = 'Mahsulot';
$_['column_model']         = 'Model';
$_['column_status']        = 'Holati';
$_['column_date_added']    = 'Qo\'shilgan sanasi';
$_['column_date_modified'] = 'O\'zgartirilgan sanasi';
$_['column_comment']       = 'Izoh';
$_['column_notify']        = 'Xaridor xabardor';
$_['column_action']        = 'Harakat';

// Entry
$_['entry_customer']      = 'Mijoz';
$_['entry_order_id']      = 'Buyurtma raqami';
$_['entry_date_ordered']  = 'Buyurtma sanasi';
$_['entry_firstname']     = 'Ism, Otasining ismi';
$_['entry_lastname']      = 'Familiya';
$_['entry_email']         = 'E-Mail';
$_['entry_telephone']     = 'Telefon raqami';
$_['entry_product']       = 'Mahsulot';
$_['entry_model']         = 'Model';
$_['entry_quantity']      = 'Miqdori';
$_['entry_opened']        = 'Ochiq';
$_['entry_comment']       = 'Sharh';
$_['entry_return_reason'] = 'Qaytarilish sababi';
$_['entry_return_action'] = 'Qaytarilish bo\'yicha harakat';
$_['entry_return_status'] = 'Qaytarilish holati';
$_['entry_notify']        = 'Xaridor xabardor';
$_['entry_return_id']     = 'Qaytarilish raqami';
$_['entry_date_added']    = 'Qo\'shilgan sanasi';
$_['entry_date_modified'] = 'O\'zgartirilgan sanasi.';

// Help
$_['help_product']        = '(Avtomatik tugatish)';

// Error
$_['error_warning']       = 'Formani xatolarini ehtiyotkorlik bilan tekshiring!';
$_['error_permission']    = 'Qaytarilish parametrlarini o\'zgartirish huquqiga ega emassiz!';
$_['error_order_id']      = 'Buyurtma raqami talab qilinadi!';
$_['error_firstname']     = 'Ism 1 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_lastname']      = 'Familiya 1 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_email']         = 'Elektron pochta manzili noto\'g\'ri kiritilgan!';
$_['error_telephone']     = 'Telefon raqami 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_product']       = 'Mahsulot nomi 3 tadan 255 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_model']         = 'Mahsulot modeli 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';

