<?php
// Heading
$_['heading_title']              = 'Buyurtmalar';

// Text
$_['text_success']               = 'Buyurtmalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']                  = 'Buyurtmalar';
$_['text_add']                   = 'Qo\'shish';
$_['text_edit']                  = 'Tahrirlash';
$_['text_order_detail']          = 'Buuyurtma';
$_['text_customer_detail']       = 'Mijoz';
$_['text_option']                = 'Tanlovlar';
$_['text_store']                 = 'Do\'kon';
$_['text_date_added']            = 'Qo\'shilgan sanasi';
$_['text_payment_method']        = 'To\'lov usuli';
$_['text_shipping_method']       = 'Yetkazib berish usuli';
$_['text_customer']              = 'Mijoz';
$_['text_customer_group']        = 'Mijozlar guruhi';
$_['text_email']                 = 'E-Mail';
$_['text_telephone']             = 'Telefon';
$_['text_invoice']               = 'Hisob';
$_['text_reward']                = 'Mukofot ballari';
$_['text_affiliate']             = 'Hamkor';
$_['text_order']                 = '%s buyurtma tafsilotlari';
$_['text_payment_address']       = 'To\'lovchi manzili';
$_['text_shipping_address']      = 'Yetkazib berish manzili';
$_['text_comment']               = 'Sharh';
$_['text_history']               = 'Buyurtma tarixi';
$_['text_history_add']           = 'Tarixga qo\'shish';
$_['text_account_custom_field']  = 'Mijoz (qo\'shimcha maydon)';
$_['text_payment_custom_field']  = 'To\'lov manzili (qo\'shimcha maydon)';
$_['text_shipping_custom_field'] = 'Yetkazib berish manzili (qo\'shimcha maydon)';
$_['text_browser']               = 'Browser';
$_['text_ip']                    = 'IP manzil';
$_['text_forwarded_ip']          = 'IPni boshqa yo\'nalishga yo\'naltirish ';
$_['text_user_agent']            = 'User Agent';
$_['text_accept_language']       = 'Til';
$_['text_order_id']              = 'Buyurtma raqami';
$_['text_fax']                   = 'Faks';
$_['text_website']               = 'Veb-sayt';
$_['text_invoice_no']            = 'Hisob raqami';
$_['text_invoice_date']          = 'To\'lov sanasi';
$_['text_sku']                   = 'SKU';
$_['text_upc']                   = 'UPC';
$_['text_ean']                   = 'EAN';
$_['text_jan']                   = 'JAN';
$_['text_isbn']                  = 'ISBN';
$_['text_mpn']                   = 'MPN';
$_['text_missing']               = 'Yo\'qolgan buyurtmalar';
$_['text_default']               = 'Odatiy qiymat';
$_['text_product']               = 'Tovar(lar) ni qo\'shish';
$_['text_voucher']               = 'Sertifikat(lar) ni qo\'shish';
$_['text_shipping']              = 'Yetkazib berish';
$_['text_contact']               = 'Aloqa ma\'lumotlari';
$_['text_reward_added']          = 'Bonus ballari qo\'shildi!';
$_['text_reward_removed']        = 'Bonus ballari olib tashlandi!';
$_['text_commission_added']      = 'Soliq qo\'shildi!';
$_['text_commission_removed']    = 'Soliq olib tashlandi!';
$_['text_restock']               = 'Bajarildi: Omborxona zaxiralari yangilandi';
$_['text_upload']                = 'Fayl muvaffaqiyatli yuklandi!';
$_['text_picklist']              = 'Yetkazib berish ro\'yxati';

// Column
$_['column_order_id']            = 'Buyurtma raqami';
$_['column_customer']            = 'Mijoz';
$_['column_status']              = 'Holati';
$_['column_date_added']          = 'Qo\'shilgan sana';
$_['column_date_modified']       = 'O\'zgartirilgan sana';
$_['column_total']               = 'Jami';
$_['column_product']             = 'Tovar';
$_['column_model']               = 'Model';
$_['column_quantity']            = 'Miqdor';
$_['column_price']               = 'Birlik uchun narx';
$_['column_comment']             = 'Sharh';
$_['column_notify']              = 'Xaridor xabardor qilindi';
$_['column_location']            = 'Joylashuvi';
$_['column_reference']           = 'Havola';
$_['column_action']              = 'Harakat';
$_['column_weight']              = 'Mahsulot vazni';

// Entry
$_['entry_store']                = 'Do\'kon';
$_['entry_customer']             = 'Xaridor';
$_['entry_customer_group']       = 'Xaridorlar guruhi';
$_['entry_firstname']            = 'Ism, Otasining ismi';
$_['entry_lastname']             = 'Familiya';
$_['entry_email']                = 'E-Mail';
$_['entry_telephone']            = 'Telefon';
$_['entry_fax']                  = 'Faks';
$_['entry_address']              = 'Manzilni tanlash';
$_['entry_company']              = 'Kompaniya';
$_['entry_address_1']            = 'Manzil 1';
$_['entry_address_2']            = 'Manzil 2';
$_['entry_city']                 = 'Shahar';
$_['entry_postcode']             = 'Indeks:';
$_['entry_country']              = 'Davlat';
$_['entry_zone']                 = 'Viloyat/Hudud';
$_['entry_zone_code']            = 'Hudud kodi';
$_['entry_product']              = 'Mahsulotni tanlang';
$_['entry_option']               = 'Variant(lar)ni tanlang';
$_['entry_quantity']             = 'Miqdor';
$_['entry_to_name']              = 'Oluvchining ismi';
$_['entry_to_email']             = 'Oluvchining Emaili';
$_['entry_from_name']            = 'Jo\'natuvchining ismi';
$_['entry_from_email']           = 'Jo\'natuvchining Emaili';
$_['entry_theme']                = 'Sovg\'a vaucheri mavzusi';
$_['entry_message']              = 'Xabar';
$_['entry_amount']               = 'Miqdor';
$_['entry_affiliate']            = 'Hamkor';
$_['entry_order_status']         = 'Buyurtma holati';
$_['entry_notify']               = 'Xaridorni xabardor qilish';
$_['entry_override']             = 'Qayta belgilash';
$_['entry_comment']              = 'Izohlar';
$_['entry_currency']             = 'Valyuta';
$_['entry_shipping_method']      = 'Yetkazib berish usuli';
$_['entry_payment_method']       = 'To\'lov usuli';
$_['entry_coupon']               = 'Kupon';
$_['entry_voucher']              = 'Sertifikat';
$_['entry_reward']               = 'Ballar';
$_['entry_order_id']             = 'Buyurtma raqami';
$_['entry_total']                = 'Jami';
$_['entry_date_added']           = 'Qo\'shilgan sanasi';
$_['entry_date_modified']        = 'O\'zgartirilgan sanasi';

// Help
$_['help_override']              = 'Agar buyurtma Firibgarlikka qarshi tizim tomonidan bloklangan bo\'lsa, u holda tomlarni o\'rnatish orqali siz himoya tizimidan qat\'i nazar, buyurtma holatini o\'rnatishingiz mumkin.';

// Error
$_['error_warning']              = 'Formani xatolarini ehtiyotkorlik bilan tekshiring!';
$_['error_permission']           = 'Sizda Buyurtma sozlamalarini o\'zgartirish huquqingiz yo\'q!';
$_['error_action']               = 'Amalni tugallab bo‘lmadi!';
$_['error_filetype']			 = 'Fayl turi noto\'g\'ri!';


