<?php
// Heading
$_['heading_title']     = 'Sovg\'a sertifikati mavzusi';

// Text
$_['text_success']      = 'Sovg\'a sertifikati mavzusi o\'zgartirildi!';
$_['text_list']         = 'Mavzular ro\'yxati';
$_['text_add']          = 'Qo\'shish';
$_['text_edit']         = 'Tahrirlash';

// Column
$_['column_name']       = 'Mavzu nomi';
$_['column_action']     = 'Harakat';

// Entry
$_['entry_name']        = 'Mavzu nomi';
$_['entry_description'] = 'Mavzu tavsifi';
$_['entry_image']       = 'Rasm';

// Error
$_['error_permission']  = 'Sizda sertifikatlar mavzusini o\'zgartirish huquqingiz yo\'q!';
$_['error_name']        = 'Nom 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_image']       = 'Rasm majburiy!';
$_['error_voucher']     = 'Ushbu mavzuni o\'chirib bo\'lmaydi, chunki u %s sertifikat(lar)ga belgilangan!';

