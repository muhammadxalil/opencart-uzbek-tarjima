<?php
// Heading
$_['heading_title']      = 'IP firibgarlikdan himoya';

// Text
$_['text_extension']     = 'Kengaytmalar';
$_['text_success']       = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']          = 'Modul sozlamalari';
$_['text_ip_add']        = 'IP manzilni qo\'shish';
$_['text_ip_list']       = 'Bloklangan IPlar ro\'yxati';

// Column
$_['column_ip']          = 'IP';
$_['column_total']       = 'Miqdori';
$_['column_date_added']  = 'Sana';
$_['column_action']      = 'Harakat';

// Entry
$_['entry_ip']           = 'IP';
$_['entry_status']       = 'Holati';
$_['entry_order_status'] = 'Buyurtma holati';

// Help
$_['help_order_status']  = 'IPsi bloklagan mijozlar, ularning hisobi buyurtma holati bilan bog\'liq bo\'ladi va buyurtmani avtomatik ravishda bajarishga imkon bermaydi.';

// Error
$_['error_permission']   = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';


