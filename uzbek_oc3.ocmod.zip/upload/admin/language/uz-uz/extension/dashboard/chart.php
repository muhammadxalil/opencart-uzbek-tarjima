<?php
// Heading
$_['heading_title']    = 'Savdo tahlillari';

// Text
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Yuklamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Sozlamalar';
$_['text_order']       = 'Buyurtmalar';
$_['text_customer']    = 'Xaridorlar';
$_['text_day']         = 'Bugun';
$_['text_week']        = 'Hafta';
$_['text_month']       = 'Oy';
$_['text_year']        = 'Yil';

// Entry
$_['entry_width']     = 'Eni';
$_['entry_status']     = 'Holati';
$_['entry_sort_order'] = 'Saralash tartibi';

// Error
$_['error_permission'] = 'Ushbu kengaytmani boshqarish uchun sizda ruxsat yo\'q!';

