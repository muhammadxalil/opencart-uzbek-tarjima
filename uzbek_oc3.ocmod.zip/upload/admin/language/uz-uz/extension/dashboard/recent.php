<?php
// Heading
$_['heading_title']     = 'So\'nggi buyurtmalar';

// Text
$_['text_extension']    = 'Kengaytmalar';
$_['text_success']      = 'Yuklamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']         = 'Yuklamalar';

// Column
$_['column_order_id']   = '№';
$_['column_customer']   = 'Xaridor';
$_['column_status']     = 'Holati';
$_['column_total']      = 'Miqdor';
$_['column_date_added'] = 'Qo\'shilgan';
$_['column_action']     = 'Harakat';


// Entry
$_['entry_width']     = 'Eni';
$_['entry_status']     = 'Holati';
$_['entry_sort_order']  = 'Saralash tartibi';

// Error
$_['error_permission']  = 'Ushbu kengaytmani boshqarish uchun sizda ruxsat yo\'q!';

