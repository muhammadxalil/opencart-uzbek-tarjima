<?php
// Heading
$_['heading_title']    = 'Buyurtmalar';

// Text
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Yuklamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Yuklamalar';
$_['text_view']        = 'batafsil...';

// Entry
$_['entry_width']     = 'Eni';
$_['entry_status']     = 'Holati';
$_['entry_sort_order'] = 'Saralash tartibi';

// Error
$_['error_permission'] = 'Ushbu kengaytmani boshqarish uchun sizda ruxsat yo\'q!';

