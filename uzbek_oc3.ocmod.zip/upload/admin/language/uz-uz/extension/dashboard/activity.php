<?php
// Heading
$_['heading_title']                = 'So\'nggi faoliyat';

// Text
$_['text_extension']               = 'Kengaytmalar';
$_['text_success']                 = 'Yuklamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']                    = 'Yuklamalar';
$_['text_customer_address_add']    = '<a href="customer_id=%d">%s</a> - yangi manzil qo\'shildi.';
$_['text_customer_address_edit']   = '<a href="customer_id=%d">%s</a> - manzil yangilangan.';
$_['text_customer_address_delete'] = '<a href="customer_id=%d">%s</a> - manzillardan biri o\'chirilgan.';
$_['text_customer_edit']           = '<a href="customer_id=%d">%s</a> - hisob ma\'lumotlari yangilandi.';
$_['text_customer_forgotten']      = '<a href="customer_id=%d">%s</a> - yangi parol so\'raldi.';
$_['text_customer_reset']          = '<a href="customer_id=%d">%s</a> - hisob paroli o\'chirildi.';
$_['text_customer_login']          = '<a href="customer_id=%d">%s</a> - tizimga kirildi.';
$_['text_customer_password']       = '<a href="customer_id=%d">%s</a> - parol yangilandi.';
$_['text_customer_register']       = '<a href="customer_id=%d">%s</a> - hisob ro\'yxatdan o\'tkazildi.';
$_['text_customer_return_account'] = '<a href="customer_id=%d">%s</a> - mahsulotni <a href="return_id=%d">qaytarish</a> so\'rovi.';
$_['text_customer_return_guest']   = '%s - mahsulotni <a href="return_id=%d">qaytarish</a> so\'rovi.';
$_['text_customer_order_account']  = '<a href="customer_id=%d">%s</a> - yangi buyurtma <a href="order_id=%d">yaratildi</a>.';
$_['text_customer_order_guest']    = '%s - yangi buyurtma <a href="order_id=%d">yaratildi</a>.';
$_['text_affiliate_edit']          = '<a href="affiliate_id=%d">%s</a> - hisob ma\'lumotlari yangilandi.';
$_['text_affiliate_forgotten']     = '<a href="affiliate_id=%d">%s</a> -  yangi parol so\'raldi.';
$_['text_affiliate_login']         = '<a href="affiliate_id=%d">%s</a> - tizimga kirildi.';
$_['text_affiliate_password']      = '<a href="affiliate_id=%d">%s</a> - parol yangilandi.';
$_['text_affiliate_payment']       = '<a href="affiliate_id=%d">%s</a> - to\'lov tafsilotlari yangilandi.';
$_['text_affiliate_register']      = '<a href="affiliate_id=%d">%s</a> - yangi hisob qayd etildi.';

// Entry
$_['entry_width']     = 'Eni';
$_['entry_status']     = 'Holati';
$_['entry_sort_order']             = 'Saralash tartibi';

// Error
$_['error_permission']             = 'Ushbu kengaytmani boshqarish uchun sizda ruxsat yo\'q!';

