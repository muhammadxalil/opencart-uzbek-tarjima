<?php
// Heading
$_['heading_title']    = 'Магазин расширений и тем';

// Text
$_['text_success']     = 'Настройки успешно изменены!';
$_['text_list']        = 'Список';
$_['text_license']     = 'Лицензия';
$_['text_free']        = 'Бесплатно';
$_['text_commercial']  = 'Платно';
$_['text_category']    = 'Все категории';
$_['text_theme']       = 'Темы';
$_['text_payment']     = 'Оплата';
$_['text_shipping']    = 'Доставка';
$_['text_module']      = 'Модули';
$_['text_total']       = 'Учитывать в заказе';
$_['text_feed']        = 'Продвижение';
$_['text_report']      = 'Отчеты';
$_['text_other']       = 'Другое';

// Error
$_['error_permission'] = 'У Вас нет прав для изменения настроек!';

