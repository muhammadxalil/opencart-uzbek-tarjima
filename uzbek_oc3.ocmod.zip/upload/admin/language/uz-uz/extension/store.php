<?php
// Heading
$_['heading_title']    = 'Kengaytmalar va mavzular do\'koni';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']        = 'Ro\'yxat';
$_['text_license']     = 'Litsenziya';
$_['text_free']        = 'Tekin';
$_['text_commercial']  = 'Pullik';
$_['text_category']    = 'Barcha toifalar';
$_['text_theme']       = 'Mavzular';
$_['text_payment']     = 'To\'lov';
$_['text_shipping']    = 'Yetkazib berish';
$_['text_module']      = 'Modullar';
$_['text_total']       = 'Buyurtmada hisobga olib qo\'yish';
$_['text_feed']        = 'Targ\'ibot';
$_['text_report']      = 'Hisobotlar';
$_['text_other']       = 'Boshqalar';

// Error
$_['error_permission'] = 'Sozlamalarni o\'zgartirishga sizda ruxsat yo\'q!';

