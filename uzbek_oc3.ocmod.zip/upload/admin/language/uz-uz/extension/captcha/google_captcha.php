<?php
$_['heading_title']    = 'Google reCAPTCHA';

// Text
$_['text_captcha']     = 'Himoya';
$_['text_success']	   = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Modul sozlamalari';
$_['text_signup']      = 'Ushbu havolaga o\'ting <a href="https://www.google.com/recaptcha/intro/index.html" target="_blank"><u>Google reCAPTCHA</u></a> va ro\'yxatdan o\'ting.';

// Entry
$_['entry_key']        = 'Site key';
$_['entry_secret']     = 'Secret key';
$_['entry_status']     = 'Holati';

// Error
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
$_['error_key']	       = 'Site key zarur!';
$_['error_secret']	   = 'Secret key zarur!';


