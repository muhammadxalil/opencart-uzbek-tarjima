<?php
// Heading
$_['heading_title']    = 'Minimal buyurtmaning qo\'shimcha to\'lovi';

// Text
$_['text_total']       = 'Buyurtmada hisobga olib qo\'yish';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Sozlamalar';

// Entry
$_['entry_total']      = 'Buyurtma miqdori';
$_['entry_fee']        = 'To\'lov';
$_['entry_tax_class']  = 'Soliqlar';
$_['entry_status']     = 'Holati';
$_['entry_sort_order'] = 'Saralash tartibi';

// Help
$_['help_total']       = 'To\'lov olinadigan buyurtma miqdorining limiti.';

// Error
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';


