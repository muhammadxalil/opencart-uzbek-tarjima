<?php
// Heading
$_['heading_title']    = 'Налоги';

// Text
$_['text_total']       = 'Учитывать в заказе';
$_['text_success']     = 'Настройки успешно изменены!';
$_['text_edit']        = 'Настройки';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порядок сортировки';

// Error
$_['error_permission'] = 'У Вас нет прав для управления данным модулем!';

