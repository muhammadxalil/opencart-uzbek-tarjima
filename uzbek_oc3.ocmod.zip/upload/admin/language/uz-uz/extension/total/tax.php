<?php
// Heading
$_['heading_title']    = 'Soliqlar';

// Text
$_['text_total']       = 'Buyurtmada hisobga olib qo\'yish';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Sozlamalar';

// Entry
$_['entry_status']     = 'Holati';
$_['entry_sort_order'] = 'Saralash tartibi';

// Error
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';

