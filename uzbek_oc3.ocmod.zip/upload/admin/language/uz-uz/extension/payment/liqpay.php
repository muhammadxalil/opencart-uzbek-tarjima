<?php
// Heading
$_['heading_title']		 = 'LIQPAY';

// Text
$_['text_extension']	 = 'Kengaytma';
$_['text_success']		 = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']          = 'Tahrirlash';
$_['text_pay']			 = 'LIQPAY';
$_['text_card']			 = 'Kredit karta';
$_['text_liqpay']		 = '<img src="view/image/payment/liqpay.png" alt="LIQPAY" title="LIQPAY" style="border: 1px solid #EEEEEE;" />';

// Entry
$_['entry_merchant']	 = 'Merchant ID';
$_['entry_signature']	 = 'Signature';
$_['entry_type']		 = 'Turi';
$_['entry_total']		 = 'Quyi chegara';
$_['entry_order_status'] = 'To\'lovdan so\'ng buyurtma holati';
$_['entry_geo_zone']	 = 'Geografik hudud';
$_['entry_status']		 = 'Holati';
$_['entry_sort_order']	 = 'Saralash tartibi';

// Help
$_['help_total']		 = 'Buyurtmaning minimal miqdori. Ushbu miqdordan kam holatda to\'lov uslubi mavjud bo\'lmaydi.';

// Error
$_['error_permission']	 = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
$_['error_merchant']	 = 'Noto\'g\'ri Merchant ID !';
$_['error_signature']	 = 'Signature mavjud emas!';

