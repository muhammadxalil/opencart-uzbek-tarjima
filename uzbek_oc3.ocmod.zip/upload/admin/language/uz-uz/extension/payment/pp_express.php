<?php
// Heading
$_['heading_title']					 = 'PayPal Ekspress to\'lovlari';

// Text
$_['text_extension']				 = 'Kengaytma';
$_['text_success']				 	 = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']                      = 'Tahrirlash';
$_['text_pp_express']				 = '<a href="https://www.paypal.com/uk/mrb/pal=W9TBB5DTD6QJW" taget="_blank"><img src="view/image/payment/paypal.png" alt="PayPal" title="PayPal" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_authorization']			 = 'Kirish';
$_['text_sale']						 = 'Savdo';
$_['text_signup']                    = 'PayPalda ro\'yxatdan o\'ting va yangilanishdan oldin sozlamalarni saqlang';
$_['text_sandbox']                   = 'PayPal Sandboxda ro\'yxatdan o\'ting va yangilanishdan oldin sozlamalarni saqlang';

// Entry
$_['entry_username']				 = 'API Username';
$_['entry_password']				 = 'API Password';
$_['entry_signature']				 = 'API Signature';
$_['entry_sandbox_username']		 = 'API Sandbox Username';
$_['entry_sandbox_password']		 = 'API Sandbox Password';
$_['entry_sandbox_signature']		 = 'API Sandbox Signature';
$_['entry_ipn']						 = 'IPN URL';
$_['entry_test']					 = 'Sinov rejimi (Sandbox) Mode';
$_['entry_debug']					 = 'Xatolar yozuvi';
$_['entry_currency']				 = 'Standart valyuta';
$_['entry_recurring_cancel']	     = 'Mijozlarga takroriy to\'lovlarni bekor qilishga ruxsat berish';
$_['entry_transaction']		         = 'Transaktsiya usuli';
$_['entry_total']					 = 'Minimal buyurtma miqdori';
$_['entry_geo_zone']				 = 'Geografik hudud';
$_['entry_status']					 = 'Holati';
$_['entry_sort_order']				 = 'Saralash tartibi';
$_['entry_canceled_reversal_status'] = 'To\'lov bekor qilinsa, buyurtma holati';
$_['entry_completed_status']		 = 'To\'lovdan so\'ng buyurtma holati';
$_['entry_denied_status']			 = 'To\'lov rad etilgandagi buyurtma holati';
$_['entry_expired_status']			 = 'To\'lov kechiktirlgandagi buyurtma holati';
$_['entry_failed_status']			 = 'To\'lov vaqtidagi xatolik holati';
$_['entry_pending_status']			 = 'To\'lov kutilayotgandagi buyurtma holati';
$_['entry_processed_status']		 = 'To\'lov jarayonida buyurtma holati';
$_['entry_refunded_status']			 = 'To\'lov qaytarilgandagi buyurtma holati';
$_['entry_reversed_status']			 = 'Mablag\'lar qaytarilgandagi buyurtma holati';
$_['entry_voided_status']			 = 'To\'lov bekor qilingandagi buyurtma holati';
$_['entry_allow_notes']				 = 'Qaydlarga ruxsat berish';
$_['entry_colour']	      			 = 'Fon rangi';
$_['entry_logo']					 = 'Logotip';

// Tab
$_['tab_api']				         = 'API ma\'lumoti';
$_['tab_order_status']				 = 'Buyurtma holati';
$_['tab_checkout']					 = 'Bezak';

// Help
$_['help_ipn']						 = 'Obuna uchun talab qilinadi';
$_['help_total']					 = 'To\'lov usulini yoqish uchun minimal miqdor';
$_['help_logo']						 = 'Maksimal 750px(e) x 90px(b)<br />Agar siz SSL o\'rnatgan bo\'lsangiz, logotipdan foydalanishingiz kerak';
$_['help_colour']					 = 'HTML rangi HEX formatida, masalan, D6D7F5';
$_['help_currency']					 = 'Bitimni qidirishda foydalaning';

// Error
$_['error_permission']				 = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
$_['error_username']				 = 'API Usernameni to\'ldirish zarur!';
$_['error_password']				 = 'API Passwordni to\'ldirish zarur!';
$_['error_signature']				 = 'API Signatureni to\'ldirish zarur!';
$_['error_sandbox_username']	 	 = 'API Sandbox Username Required!';
$_['error_sandbox_password']		 = 'API Sandbox Password Required!';
$_['error_sandbox_signature']		 = 'API Sandbox Signature Required!';
$_['error_api']						 = 'Paypal Authorization Error';
$_['error_api_sandbox']				 = 'Paypal Sandbox Authorization Error';

