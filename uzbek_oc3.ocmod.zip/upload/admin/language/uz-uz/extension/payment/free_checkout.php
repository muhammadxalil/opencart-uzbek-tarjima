<?php
// Heading
$_['heading_title']		 = 'Tekin buyurtma';

// Text
$_['text_extension']	 = 'Kengaytma';
$_['text_success']		 = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']          = 'Tahrirlash';

// Entry
$_['entry_order_status'] = 'Buyurtma holati';
$_['entry_status']		 = 'Holati';
$_['entry_sort_order']	 = 'Saralash tartibi';

// Error
$_['error_permission']	 = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';

