<?php
// Heading
$_['heading_title']		 = 'Bank o\'tkazmasi';

// Text
$_['text_extension']	 = 'Kengaytma';
$_['text_success']		 = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']          = 'Tahrirlash';

// Entry
$_['entry_bank']		 = 'Pul o\'tkazish bo\'yicha yo\'riqnoma';
$_['entry_total']		 = 'Quyi chegara';
$_['entry_order_status'] = 'To\'lovdan so\'ng buyurtma holati';
$_['entry_geo_zone']	 = 'Geografik hudud';
$_['entry_status']		 = 'Holati';
$_['entry_sort_order']	 = 'Saralash tartibi';

// Help
$_['help_total']		 = 'Buyurtmaning minimal miqdori. Ushbu miqdordan kam holatda to\'lov uslubi mavjud bo\'lmaydi.'; 

// Error 
$_['error_permission']   = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
$_['error_bank']         = 'O\'tkazma bo\'yicha yo\'riqnomani to\'ldirish zarur!';

