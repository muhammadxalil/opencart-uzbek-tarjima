<?php
// Heading
$_['heading_title']			   = 'Tranzaksiyani qidirish';

// Text
$_['text_pp_express']		   = 'PayPal Экспресс-платежи';
$_['text_date_search']		   = 'Sana bo\'yicha qidirish';
$_['text_searching']		   = 'Qidiruv';
$_['text_name']				   = 'Ism';
$_['text_buyer_info']		   = 'Sotib oluvchi haqida ma\'lumot';
$_['text_view']				   = 'Ko\'rish';
$_['text_format']			   = 'Format';

// Column
$_['column_date']			   = 'Sana';
$_['column_type']			   = 'Tipi';
$_['column_email']			   = 'Email';
$_['column_name']			   = 'Ism';
$_['column_transid']		   = 'Tranzaksiya IDsi';
$_['column_status']			   = 'Holati';
$_['column_currency']		   = 'Pul birligi';
$_['column_amount']			   = 'Miqdori';
$_['column_fee']			   = 'Komissiya to\'lovi';
$_['column_netamt']		       = 'Miqdorsiz';
$_['column_action']		       = 'Harakat';

// Entry
$_['entry_trans_all']		   = 'Hammasi';
$_['entry_trans_sent']		   = 'Yuborilganlar';
$_['entry_trans_received']     = 'Qaytarilganlar';
$_['entry_trans_masspay']	   = 'Ommaviy to\'lovlar';
$_['entry_trans_money_req']	   = 'Mablag\'larni talab qilish';
$_['entry_trans_funds_add']	   = 'Pul mablag\'larini to\'ldirish';
$_['entry_trans_funds_with']   = 'Pulni yechib olish';
$_['entry_trans_referral']	   = 'Yo\'naltirilganlar';
$_['entry_trans_fee']		   = 'Badal';
$_['entry_trans_subscription'] = 'Obuna bo\'lish';
$_['entry_trans_dividend']     = 'Dividentlar';
$_['entry_trans_billpay']      = 'To\'lovni to\'lash';
$_['entry_trans_refund']       = 'Qaytarilganlar';
$_['entry_trans_conv']         = 'Konvertatsiya qilinayotganlar';
$_['entry_trans_bal_trans']	   = 'Hisobdan o\'tkazish';
$_['entry_trans_reversal']	   = 'O\'zgartirilganlar';
$_['entry_trans_shipping']	   = 'Yetkazilganlar';
$_['entry_trans_bal_affect']   = 'Hisobga ta\'siri';
$_['entry_trans_echeque']	   = 'E Check';
$_['entry_date']			   = 'Sana';
$_['entry_date_start']		   = 'Boshlanishi';
$_['entry_date_end']		   = 'Tugashi';
$_['entry_date_по']			   = 'tomonidan';
$_['entry_transaction']		   = 'Tranzaksiya';
$_['entry_transaction_type']   = 'Turi';
$_['entry_transaction_status'] = 'Holati';
$_['entry_email']			   = 'Email';
$_['entry_email_buyer']		   = 'Xaridor';
$_['entry_email_merchant']	   = 'Qabul qiluvchi';
$_['entry_receipt']			   = 'Qabul qiluvchi IDsi';
$_['entry_transaction_id']	   = 'Tranzaksiya IDsi';
$_['entry_invoice_no']		   = 'Hisob raqami';
$_['entry_auction']			   = 'Auksion raqami';
$_['entry_amount']			   = 'Miqdor';
$_['entry_recurring_id']	   = 'Davriy profil IDsi';
$_['entry_salutation']		   = 'Salomlashish';
$_['entry_firstname']		   = 'Ism';
$_['entry_middlename']		   = 'Otasining ismi';
$_['entry_lastname']		   = 'Familiya';
$_['entry_suffix']			   = 'Prefiks';
$_['entry_status_all']		   = 'Hammasi';
$_['entry_status_pending']	   = 'Kutilayotgan';
$_['entry_status_processing']  = 'Jarayondagi';
$_['entry_status_success']	   = 'Tugallanganlari';
$_['entry_status_denied']	   = 'Rad etilganlari';
$_['entry_status_reversed']	   = 'Qaytarilgan';

