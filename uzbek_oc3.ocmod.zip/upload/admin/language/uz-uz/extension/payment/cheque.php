<?php
// Heading
$_['heading_title']		 = 'Naqd pul to\'lov';

// Text
$_['text_extension']		 = 'Kengaytma';
$_['text_success']		 = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']          = 'Tahrirlash';

// Entry
$_['entry_payable']		 = 'Qabul qiluvchi';
$_['entry_total']		 = 'Quyi chegara';
$_['entry_order_status'] = 'To\'lovdan so\'ng buyurtma holati';
$_['entry_geo_zone']	 = 'Geografik hudud';
$_['entry_status']		 = 'Holati';
$_['entry_sort_order']	 = 'Saralash tartibi';

// Help
$_['help_total']		 = 'Buyurtmaning minimal miqdori. Ushbu miqdordan kam holatda to\'lov uslubi mavjud bo\'lmaydi.';

// Error
$_['error_permission']   = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
$_['error_payable']	     = 'Qabul qiluvchini kiriting!';

