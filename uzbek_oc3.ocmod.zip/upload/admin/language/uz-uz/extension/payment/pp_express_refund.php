<?php
// Heading
$_['heading_title']		   = 'O\'tkazmani qaytarish';

// Text
$_['text_pp_express']	   = 'PayPal Express to\'lovlari';
$_['text_current_refunds'] = 'Ushbu operatsiyani bajarish uchun allaqachon pul qaytarib berilgan. Qaytarilishning maksimal miqdori ';
$_['text_refund']		   = 'Qaytarish';

// Entry
$_['entry_transaction_id'] = 'Tranzaksiya IDsi';
$_['entry_full_refund']	   = 'To\'liq qaytarish';
$_['entry_amount']		   = 'Miqdor';
$_['entry_message']		   = 'Xabar';

// Button
$_['button_refund']		   = 'Qaytarishni rasmiylashtirish';

// Error
$_['error_partial_amt']	   = 'Miqdorning bir qismini kiritishingiz zarur';
$_['error_data']		   = 'Ma\'lumotlar yo\'q';

