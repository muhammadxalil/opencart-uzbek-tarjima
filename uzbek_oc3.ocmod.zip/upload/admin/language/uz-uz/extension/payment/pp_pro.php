<?php
// Heading
$_['heading_title']		 = 'PayPal Pro';

// Text
$_['text_success']		 = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']          = 'Tahrirlash';
$_['text_pp_pro']		 = '<a target="_BLANK" href="https://www.paypal.com/uk/mrb/pal=V4T754QB63XXL"><img src="view/image/payment/paypal.png" alt="PayPal Website Payment Pro" title="PayPal Website Payment Pro iFrame" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_authorization'] = 'Kirish';
$_['text_sale']						= 'Savdo';

// Entry
$_['entry_username']	 = 'API Username';
$_['entry_password']	 = 'API Password';
$_['entry_signature']	 = 'API Signature';
$_['entry_test']		 = 'Muammolarni bartaraf etish rejimi';
$_['entry_transaction']	 = 'Tranzaksiya uslubi';
$_['entry_total']		 = 'Pastki chegara';
$_['entry_order_status'] = 'To\'lovdan so\'ng buyurtma holati';
$_['entry_geo_zone']	 = 'Geografik hudud';
$_['entry_status']		 = 'Holati';
$_['entry_sort_order']	 = 'Saralash tartibi';

// Help
$_['help_test']			 = 'Use the live or testing (sandbox) gateway server to process transactions?';
$_['help_total']		 = 'The checkout total the order must reach before this payment method becomes active';

// Error
$_['error_permission']	 = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
$_['error_username']	 = 'API Usernameni to\'ldirish zarur!';
$_['error_password']	 = 'API Passwordni to\'ldirish zarur!';
$_['error_signature']	 = 'API Signatureni to\'ldirish zarur!';

