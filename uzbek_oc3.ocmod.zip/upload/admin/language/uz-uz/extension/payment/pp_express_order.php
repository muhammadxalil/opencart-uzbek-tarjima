<?php
// Text
$_['text_extension']		 = 'Hisob-kitob haqida ma\'lumot';
$_['text_capture_status']	 = 'Holatni ushlab qolish';
$_['text_amount_authorised'] = 'Ruxsat berilgan miqdor';
$_['text_amount_captured']	 = 'Olingan miqdor';
$_['text_amount_refunded']	 = 'Qaytarilgan miqdor';
$_['text_transaction']		 = 'Tranzaksiyalar';
$_['text_complete']			 = 'Tugallangan';
$_['text_confirm_void']		 = 'Agar bekor qilsangiz, qo\'shimcha mablag\'larni ololmaysiz';
$_['text_view']				 = 'Ko\'rish';
$_['text_refund']			 = 'Qaytarib berish';
$_['text_resend']			 = 'Qayta yuborish';
$_['text_success']           = 'O‘tkazma muvaffaqiyatli yuborildi';
$_['text_full_refund']		 = 'To\'liq qaytarish';
$_['text_partial_refund']	 = 'Qisman qaytarish';

$_['text_current_refunds']   = 'Ushbu kelishuv uchun allaqachon to\'lov qaytarilgan. Maks qaytarish';

// Column
$_['column_transaction']	 = 'O\'tkazma IDsi';
$_['column_amount']			 = 'Miqdor';
$_['column_type']			 = 'To\'lov turi';
$_['column_status']			 = 'Holati';
$_['column_pending_reason']	 = 'Kutish sababi';
$_['column_date_added']		 = 'Создан';
$_['column_action']			 = 'Действие';

// Entry
$_['entry_capture_amount']	 = 'Сумма захвата';
$_['entry_capture_complete'] = 'Захват завершен';
$_['entry_full_refund']		 = 'Полный возврат';
$_['entry_amount']			 = 'Сумма';
$_['entry_note']             = 'Заметка';

// Help
$_['help_capture_complete']  = 'Если это последний захват.';

// Tab
$_['tab_capture']		     = 'Ushlash';
$_['tab_refund']             = 'Qaytarish';

// Button
$_['button_void']			 = 'Bekor qilmoq';
$_['button_capture']		 = 'Ushlamoq';
$_['button_refund']		     = 'Ushlab turish bo\'yicha savol';

// Error
$_['error_capture']		     = 'Ushlab turilishi kerak bo\'lgan summani kiriting';
$_['error_transaction']	     = 'Tranzaktsiyani amalga oshirib bo\'lmaydi.!';
$_['error_not_found']	     = 'Tranzaktsiya topilmadi!';
$_['error_partial_amt']		 = 'Qisman qaytariladigan summani kiritish zarur';

