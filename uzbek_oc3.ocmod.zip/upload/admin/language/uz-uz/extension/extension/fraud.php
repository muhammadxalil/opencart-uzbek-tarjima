<?php
// Heading
$_['heading_title']    = 'Firibgarlikdan himoya';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli yangilandi!';
$_['text_list']        = 'Modullar ro\'yxati';

// Column
$_['column_name']      = 'Nomi';
$_['column_status']    = 'Holati';
$_['column_action']    = 'Harakat';

// Error
$_['error_permission'] = 'Siz o\'zgartirish huquqiga ega emassiz!';

