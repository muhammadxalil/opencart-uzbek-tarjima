<?php
// Heading
$_['heading_title']     = 'Yetkazib berish';

// Text
$_['text_success']      = 'Sozlamalar muvaffaqiyatli yangilandi!';
$_['text_list']         = 'Yetkazib berish usulllari ro\'yxati';

// Column
$_['column_name']       = 'Yetkazib berish usuli';
$_['column_status']     = 'Holati';
$_['column_sort_order'] = 'Saralash tartibi';
$_['column_action']     = 'Harakat';

// Error
$_['error_permission']  = 'Sizda yetkazib berishni boshqarish huquqi yo\'q!';

