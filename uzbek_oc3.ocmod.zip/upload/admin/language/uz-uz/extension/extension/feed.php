<?php
// Heading
$_['heading_title']    = 'Reklama kanallari';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli yangilandi!';
$_['text_list']        = 'Kanallar ro\'yxati';

// Column
$_['column_name']      = 'Kanal nomi';
$_['column_status']    = 'Holati';
$_['column_action']    = 'Harakat';

// Error
$_['error_permission'] = 'Sizda mahsulotlar kanalini o\'zgartirish huquqi yo\'q!';

