<?php
// Heading
$_['heading_title']     = 'Boshqaruv paneli';

// Text
$_['text_success']      = 'Sozlamalar muvaffaqiyatli yangilandi!';
$_['text_list']         = 'Ro\'yxat';

// Column
$_['column_name']       = 'Nomi';
$_['column_width']      = 'Eni';
$_['column_status']     = 'Holati';
$_['column_sort_order'] = 'Saralash tartibi';
$_['column_action']     = 'Harakat';

// Error
$_['error_permission']  = 'Boshqaruv panelini o\'zgartirishga sizda ruxsat yo\'q!';

