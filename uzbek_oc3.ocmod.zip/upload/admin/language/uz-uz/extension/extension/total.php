<?php
// Heading
$_['heading_title']     = 'Buyurtmada hisobga olib qo\'yish';

// Text
$_['text_success']      = 'Sozlamalar muvaffaqiyatli yangilandi!';
$_['text_list']         = 'Buyurtmada hisobga olib qo\'yish';

// Column
$_['column_name']       = 'Buyurtmada hisobga olib qo\'yish';
$_['column_status']     = 'Holati';
$_['column_sort_order'] = 'Saralash tartibi';
$_['column_action']     = 'Harakat';

// Error
$_['error_permission']  = 'Ushbu modulni boshqarish uchun sizda ruxsat yo\'q!';

