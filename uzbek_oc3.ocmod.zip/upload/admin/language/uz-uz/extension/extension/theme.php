<?php
// Heading
$_['heading_title']    = 'Mavzular';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli yangilandi!';
$_['text_list']        = 'Mavzular ro\'yxati';

// Column
$_['column_name']      = 'Nomi';
$_['column_status']    = 'Holati';
$_['column_action']    = 'Harakat';

// Error
$_['error_permission'] = 'Ushbu modulni boshqarish uchun sizda ruxsat yo\'q!';

