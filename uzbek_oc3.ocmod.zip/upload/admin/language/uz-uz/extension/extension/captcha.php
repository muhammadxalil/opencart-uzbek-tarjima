<?php
// Heading
$_['heading_title']    = 'Robotlardan himoya';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli yangilandi!';
$_['text_list']        = 'Ro\'yxat';

// Column
$_['column_name']      = 'Nomi';
$_['column_status']    = 'Holati';
$_['column_action']    = 'Harakat';

// Error
$_['error_permission'] = 'Sizda mahsulotlar kanalini o\'zgartirish huquqi yo\'q!';

