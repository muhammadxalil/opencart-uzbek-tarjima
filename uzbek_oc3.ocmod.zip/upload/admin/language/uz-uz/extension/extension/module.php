<?php
// Heading
$_['heading_title']    = 'Modullar';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli yangilandi!';
$_['text_layout']      = 'Modulni o\'rnatgandan va sozlaganingizdan so\'ng siz uni ushbu bo\'limga qo\'shishingiz mumkin <a href="%s" class="alert-link">Dizayn - Sxemalar</a>!';
$_['text_add']         = 'Qo\'shish';
$_['text_list']        = 'Modullar';

// Column
$_['column_name']      = 'Modul nomi';
$_['column_action']    = 'Harakat';

// Entry
$_['entry_code']       = 'Modul';
$_['entry_name']       = 'Modul nomi';

// Error
$_['error_permission'] = 'Ushbu modulni boshqarish uchun sizda ruxsat yo\'q!';
$_['error_name']       = 'Modul nomi 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_code']       = 'Zarur!';

