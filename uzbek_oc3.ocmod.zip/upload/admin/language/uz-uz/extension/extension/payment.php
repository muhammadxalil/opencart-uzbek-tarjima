<?php
// Heading
$_['heading_title']     = 'To\'lov';

// Text
$_['text_success']      = 'Sozlamalar muvaffaqiyatli yangilandi!';
$_['text_list']         = 'To\'lov usullari ro\'yxati';

// Column
$_['column_name']       = 'To\'lov usullari';
$_['column_status']     = 'Holati';
$_['column_sort_order'] = 'Saralash tartibi';
$_['column_action']     = 'Harakat';

// Error
$_['error_permission']  = 'Ushbu To\'lov modulini boshqarish uchun sizda ruxsat yo\'q!';

