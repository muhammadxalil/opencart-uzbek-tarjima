<?php
// Heading
$_['heading_title']                    = 'Standart mavzu';

// Text
$_['text_theme']                       = 'Mavzular';
$_['text_success']                     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']                        = 'Tahrirlash';
$_['text_general']                     = 'Asosiy';
$_['text_product']                     = 'Mahsulotlar';
$_['text_image']                       = 'Rasmlar';
$_['text_extension']                       = 'Kengaytmalar';

// Entry
$_['entry_directory']                  = 'Mavzu katalogi';
$_['entry_status']                     = 'Holati';
$_['entry_product_limit']              = 'Mahsulotlar limiti (Rasta)';
$_['entry_product_description_length'] = 'Belgilar soni (Rasta)';
$_['entry_image_category']             = 'Kategoriyalar ro\'yxatidagi rasm hajmi';
$_['entry_image_thumb']                = 'Mahsulotning katta rasmi hajmi';
$_['entry_image_popup']                = 'Mahsulotning qalqib chiqadigan rasmi hajmi';
$_['entry_image_product']              = 'Mahsulotlar ro\'yxatidagi rasmining hajmi';
$_['entry_image_additional']           = 'Mahsulotning qo\'shimcha rasmlari hajmi';
$_['entry_image_related']              = 'O\'xshash mahsulotlarning rasm hajmi';
$_['entry_image_compare']              = 'Taqqoslash ro\'yxatidagi rasm hajmi';
$_['entry_image_wishlist']             = 'Qaydlar ro\'yxatidagi mahsulot rasmi hajmi';
$_['entry_image_cart']                 = 'Savatchadagi mahsulot rasmi hajmi';
$_['entry_image_location']             = 'Do\'kon rasmi hajmi';
$_['entry_width']                      = 'Eni';
$_['entry_height']                     = 'Bo\'yi';

// Help
$_['help_directory'] 	               = 'Ushbu maydon eski andozalar (2.0.x va .2.1.x versiyalaridan boshlab) mavzuning yangi funktsiyalari bilan mos bo\'lishi uchun zarur. Belgilangan maydonda siz mavzular katalogini tanlashingiz mumkin';
$_['help_product_limit'] 	           = 'Sahifada qancha mahsulot ko\'rsatilishini aniqlaydi. (Mahsulotlar ro\'yxati).';
$_['help_product_description_length']  = 'Mahsulot qisqacha ta\'rifidagi belgilar soni (Mahsulotlar ro\'yxati)';

// Error
$_['error_permission']                 = 'Sozlamalarni o\'zgartirishga sizda ruxsat yo\'q!';
$_['error_limit']       	           = 'Limitni belgilang!';
$_['error_image_thumb']                = 'Mahsulotning katta rasmining hajmini ko\'rsatishz zarur!';
$_['error_image_popup']                = 'Tovarlarning qalqib chiqadigan rasmning hajmini ko\'rsatish zarur!';
$_['error_image_product']              = 'Mahsulotlar ro\'yxatidagi rasm hajmini ko\'rsatish zarur!';
$_['error_image_category']             = 'Kategoriyalar ro\'yxatidagi rasm hajmini ko\'rsatish zarur!';
$_['error_image_additional']           = 'Tovarlarning qo\'shimcha rasmlarining hajmini ko\'rsatish zarur!';
$_['error_image_related']              = 'O\'xshash mahsulotlarning qo\'shimcha rasmlarining hajmini ko\'rsatish zarur!';
$_['error_image_compare']              = 'Taqqoslash ro\'yxatidagi rasm hajmini ko\'rsatish zarur!';
$_['error_image_wishlist']             = 'Qaydlar ro\'yxatidagi mahsulot rasmi hajmini ko\'rsatish zarur!';
$_['error_image_cart']                 = 'Savatchadagi mahsulot rasmi hajmini ko\'rsatish zarur!';
$_['error_image_location']             = 'Do\'kon rasmi hajmini ko\'rsatish zarur!';

