<?php
$_['heading_title']    = 'Google Analytics';

// Text
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']	   = 'Yuklamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_signup']      = 'Ushbu <a href="http://www.google.com/analytics/" target="_blank"><u>Google Analytics</u></a> hisob qaydnomasiga kiring va sayt profilini yaratgandan so\'ng, ushbu maydonga kodni ko\'chirib qo\'ying.';
$_['text_default']     = 'Odatiy';
$_['text_edit']        = 'Modul sozlamalari';

// Entry
$_['entry_code']       = 'Google Analytics kodi';
$_['entry_status']     = 'Holati';

// Error
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
$_['error_code']	   = 'Kod kerak!';


