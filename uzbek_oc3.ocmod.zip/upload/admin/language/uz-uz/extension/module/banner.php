<?php
// Heading
$_['heading_title']    = 'Banner';

// Text
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Modul sozlamalari';

// Entry
$_['entry_name']       = 'Modul nomi';
$_['entry_banner']     = 'Banner';
$_['entry_dimension']  = 'O\'lchamlari (Eni x Bo\'yi)';
$_['entry_width']      = 'Eni';
$_['entry_height']     = 'Bo\'yi';
$_['entry_status']     = 'Holati';

// Error
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
$_['error_name']       = 'Modul nomi 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_width']      = 'Rasmning enini kiritng!';
$_['error_height']     = 'Rasmning bo\'yini kiritng!';

