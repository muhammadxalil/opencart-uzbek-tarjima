<?php
// Heading
$_['heading_title']    = 'Google Hangouts chati';

// Text
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Modul sozlamalari';

// Entry
$_['entry_code']       = 'Google Hangouts kodi';
$_['entry_status']     = 'Holati';

// Help
$_['help_code']        = 'Ushbu havolaga o\'ting <a href="https://developers.google.com/+/hangouts/button" target="_blank">Google Hangout profilini yarating </a>, keyin olingan koddan nusxa oling va matn maydoniga qo\'ying .';

// Error
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
$_['error_code']       = 'Kod zarur';

