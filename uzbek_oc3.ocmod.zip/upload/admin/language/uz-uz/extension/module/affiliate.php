<?php
// Heading
$_['heading_title']    = 'Hamkorlik dasturi';

// Text
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Modul sozlamalari';

// Entry
$_['entry_status']     = 'Holati';

// Error
$_['error_permission'] = 'Hamkorlik dasturi modulini o\'zgartirish huquqingiz yo\'q!';

