<?php
// Heading
$_['heading_title']    = 'PayPal Express to\'lov tugmasi';

// Text
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Modul sozlamalari';

// Entry
$_['entry_status']     = 'Holati';

// Error
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';

