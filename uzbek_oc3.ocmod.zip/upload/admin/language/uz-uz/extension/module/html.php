<?php
// Heading
$_['heading_title']     = 'HTML - matn bloki';

// Text
$_['text_extension']    = 'Kengaytmalar';
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']         = 'Modul sozlamalari';

// Entry
$_['entry_name']        = 'Modul nomi';
$_['entry_title']       = 'Sarlavha';
$_['entry_description'] = 'Matn';
$_['entry_status']      = 'Holati';

// Error
$_['error_permission']  = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
$_['error_name']        = 'Modul nomi 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';

