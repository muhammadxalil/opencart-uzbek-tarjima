<?php
// Heading
$_['heading_title']          = 'Google Base';

// Text
$_['text_extension']         = 'Kengaytmalar';
$_['text_success']           = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']              = 'Tahrirlash';
$_['text_import']            = 'Toifalar ro\'yxatini yuklab oling <a href="https://support.google.com/merchants/answer/160081?hl=ru" target="_blank" class="alert-link">bu yerni bosing</a> va ID raqamini fayldan tanlang (. txt). Yashil import tugmasi yordamida import qiling.';

// Column
$_['column_google_category'] = 'Google Kategoriya';
$_['column_category']        = 'Kategoriya';
$_['column_action']          = 'Harakat';

// Entry
$_['entry_google_category']  = 'Google Kategoriya';
$_['entry_category']         = 'Kategoriyalar';
$_['entry_data_feed']        = 'Kanal URLi';
$_['entry_status']           = 'Holati';

// Error
$_['error_permission']       = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
$_['error_upload']           = 'Faylni yuklab bo\'lmadi!';
$_['error_filetype']         = 'Fayl turi noto\'g\'ri';


