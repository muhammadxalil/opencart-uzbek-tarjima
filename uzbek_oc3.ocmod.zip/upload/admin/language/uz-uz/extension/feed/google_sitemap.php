<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli yangilandi!';
$_['text_edit']        = 'Tahrirlash';

// Entry
$_['entry_status']     = 'Holati';
$_['entry_data_feed']  = 'Manzil';

// Error
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';

