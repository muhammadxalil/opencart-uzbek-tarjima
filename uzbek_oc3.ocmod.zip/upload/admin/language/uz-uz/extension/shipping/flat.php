<?php
// Heading
$_['heading_title']    = 'Yetkazib berish belgilangan narxi';

// Text
$_['text_extension']	 = 'Kengaytmalar';
$_['text_shipping']    = 'Yetkazib berish';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Tahrirlash';

// Entry
$_['entry_cost']       = 'Narxi';
$_['entry_tax_class']  = 'Soliq klassi';
$_['entry_geo_zone']   = 'Geografik hudud';
$_['entry_status']     = 'Holati';
$_['entry_sort_order'] = 'Saralash tartibi';

// Error
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';

