<?php
// Heading
$_['heading_title']    = 'Bepul yetkazib berish';

// Text
$_['text_extension']	 = 'Kengaytmalar';
$_['text_shipping']    = 'Yetkazib berish';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Tahrirlash';

// Entry
$_['entry_total']      = 'Miqdor limiti';
$_['entry_geo_zone']   = 'Geografik hudud';
$_['entry_status']     = 'Holati';
$_['entry_sort_order'] = 'Saralash tartibi';

// Help
$_['help_total']       = 'Bepul yetkazib berish mumkin bo\'lishi uchun buyurtmaning minimal miqdori zarur.';

// Error
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';

