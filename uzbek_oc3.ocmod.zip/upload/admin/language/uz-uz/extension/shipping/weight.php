<?php
// Heading
$_['heading_title']    = 'Og\'irligiga qarab yetkazib berish';

// Text
$_['text_extension']	 = 'Kengaytmalar';
$_['text_shipping']    = 'Yetkazib berish';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Tahrirlash';

// Entry
$_['entry_rate']       = 'Stavkalar';
$_['entry_tax_class']  = 'Soliq klassi';
$_['entry_geo_zone']   = 'Geografik hudud';
$_['entry_status']     = 'Holati';
$_['entry_sort_order'] = 'Saralash tartibi';

// Help
$_['help_rate']        = 'Namuna: 5:10.00,7:12.00 Og\'irligi:Narxi,Og\'irligi:Narxi, va h.k. (Kg yoki boshqa belgilarni kiritmang)';

// Error
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';

