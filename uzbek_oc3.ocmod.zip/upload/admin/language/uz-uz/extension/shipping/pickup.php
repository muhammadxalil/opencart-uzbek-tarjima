<?php
// Heading
$_['heading_title']    = 'Pikap';

// Text
$_['text_extension']	 = 'Kengaytmalar';
$_['text_shipping']    = 'Доставка';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Tahrirlash';

// Entry
$_['entry_geo_zone']   = 'Geografik hudud';
$_['entry_status']     = 'Holati';
$_['entry_sort_order'] = 'Saralash tartibi';

// Error
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';

