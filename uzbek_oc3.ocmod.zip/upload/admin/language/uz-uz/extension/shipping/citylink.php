<?php
// Heading
$_['heading_title']    = 'Shahar bo\'ylab yetkazib berish';

// Text
$_['text_extension']	 = 'Kengaytmalar';
$_['text_shipping']    = 'Yetkazib berish';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Tahrirlash';

// Entry
$_['entry_rate']       = 'Yetkazib berish narxlari';
$_['entry_tax_class']  = 'Soliq klassi';
$_['entry_geo_zone']   = 'Geografik hudud';
$_['entry_status']     = 'Holati';
$_['entry_sort_order'] = 'Saralash tartibi';

// Help
$_['help_rate']        = '5.2 kasrgacha bo\'lgan qiymatni kiriting. (12345.67) Masalan: .1:1,.25:1.27 - 0,1 kg dan kam yoki teng vazn 1.00 ga tushadi (birlamchi valyuta birliklarida), 0,1 dan 0,25 kg gacha bo\'lgan vazn 1,27 ga tushadi. Kg yoki boshqa belgilarni kiritmang.';

// Error
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';

