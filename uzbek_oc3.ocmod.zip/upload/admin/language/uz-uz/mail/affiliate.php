<?php
// Text
$_['text_approve_subject']      = '%s - Sizning hamkorlik hisob qaydnomangiz faollashtirilgan.!';
$_['text_approve_welcome']      = 'Xush kelibsiz va %s da ro\'yxatdan o\'tganingiz uchun rahmat!';
$_['text_approve_login']        = 'Sizning hisobingiz yaratildi va siz elektron pochta va parolingizdan foydalanib bizning veb-saytimizga kirishingiz mumkin.';
$_['text_approve_services']     = 'Kirganingizdan keyin siz hamkorlik havolasini olishingiz mumkin';
$_['text_approve_thanks']       = 'Rahmat';
$_['text_transaction_subject']  = '%s - Hamkorlik mukofoti.';
$_['text_transaction_received'] = 'Siz %s oldingiz!';
$_['text_transaction_total']    = 'Sizning hamkorlik mukofotlarining umumiy miqdori %s.';

