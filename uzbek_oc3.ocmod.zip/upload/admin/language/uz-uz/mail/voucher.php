<?php
// Text
$_['text_subject']  = 'Sizga %s bilan sovg\'a sertifikati yuborildi';
$_['text_greeting'] = 'Tabriklaymiz, siz %s uchun Sovg\'a sertifikati oldingiz';
$_['text_from']     = 'Siz %sdan Sovg\'a sertifikati oldingiz';
$_['text_message']  = 'Aytadigan xabar bilan';
$_['text_redeem']   = 'Ushbu Sovg\'a sertifikatidan foydalanish uchun <b>%s</b> kodni saqlang, so\'ngra quyidagi havoladan foydalanib do\'konga boring va sizga yoqqan mahsulotlarga buyurtma bering. Buyurtma berishdan oldin sovg\'a sertifikati kodini savatni ko\'rish sahifasiga kiritishingiz mumkin.';
$_['text_footer']   = 'Savollaringiz bo\'lsa, ushbu xabarga javob bering.';


