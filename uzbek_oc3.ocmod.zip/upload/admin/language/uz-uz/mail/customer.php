<?php
// Text
$_['text_approve_subject']      = '%s - Sizning hisobingiz faollashtirildi!';
$_['text_approve_welcome']      = 'Xush kelibsiz va %s da ro\'yxatdan o\'tganingiz uchun rahmat!';
$_['text_approve_login']        = 'Sizning hisobingiz yaratildi va siz elektron pochta va parolingizdan foydalanib bizning veb-saytimizga tashrif buyurishingiz mumkin.';
$_['text_approve_services']     = 'Saytda ro\'yxatdan o\'tgandan so\'ng siz qo\'shimcha funktsiyalardan foydalanishingiz mumkin: buyurtmalar tarixini ko\'rish, hisob-fakturani bosib chiqarish, hisob qaydnomangiz ma\'lumotlarini o\'zgartirish va hk.';
$_['text_approve_thanks']       = 'Rahmat,';
$_['text_transaction_subject']  = '%s - Hisob qaydnomasi';
$_['text_transaction_received'] = 'Siz hisobingizga oldingiz: %s';
$_['text_transaction_total']    = 'Hisobingizdagi umumiy miqdor: %s.' . "\n\n" . 'Ushbu miqdor avtomatik ravishda keyingi xaridlar uchun sarflanadi.';
$_['text_reward_subject']       = '%s - Mukofot ballari';
$_['text_reward_received']      = 'Siz %s bonus ballarini oldingiz!';
$_['text_reward_total']         = 'Umumiy bonus ballar - s%.';

