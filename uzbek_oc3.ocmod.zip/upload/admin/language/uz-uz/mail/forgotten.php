<?php
// Text
$_['text_subject']  = '%s - Parolni o\'zgartirish so\'rovi';
$_['text_greeting'] = 'Boshqaruv paneliga kirish uchun yangi parol %s .';
$_['text_change']   = 'Parolni o\'zgartirish uchun havolani bosing';
$_['text_ip']       = 'Ushbu IPdan so\'rov yuborildi: %s';

