<?php
// Text
$_['text_subject']       = '%s - qaytish yangilangan  %s';
$_['text_return_id']     = 'Qaytarilish raqami';
$_['text_date_added']    = 'Qaytarilish sanasi';
$_['text_return_status'] = 'Qaytarilishning hozirgi holati';
$_['text_comment']       = 'Sizning qaytarishingizga sharhlar';
$_['text_footer']        = 'Savollaringiz bo\'lsa, ushbu xabarga javob bering.';

