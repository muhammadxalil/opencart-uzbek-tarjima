<?php
// Heading
$_['heading_title']         = 'Tahlil';

// Text
$_['text_success']          = 'Siz statistikani muvaffaqiyatli o\'zgartirdingiz!';
$_['text_list']             = 'Ro\'yxat';
$_['text_order_sale']       = 'Savdolar';
$_['text_order_processing'] = 'Ishlanayotgan buyurtmalar';
$_['text_order_complete']   = 'Bajarilgan buyurtmalar';
$_['text_order_other']      = 'Boshqa buyurtmalar';
$_['text_returns']          = 'Qaytarishlar';
$_['text_customer']         = 'Bohabar qilinishi kutilayotgan mijozlar';
$_['text_affiliate']        = 'Tasdiqlanishni kutayotgan hamkorlar';
$_['text_product']          = 'Mavjud emas';
$_['text_review']           = 'Tasdiqlash uchun sharhlar';

// Column
$_['column_name']           = 'Nomi';
$_['column_value']	        = 'Qiymati';
$_['column_action']         = 'Harakat';

// Error
$_['error_permission']  = 'Diqqat: Sozlamalarni o\'zgartirishga sizda ruxsat yo\'q!';