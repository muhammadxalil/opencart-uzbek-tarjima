<?php
// Heading
$_['heading_title'] = 'Hisobotlar';

// Text
$_['text_success']  = 'Siz hisobotlarni muvaffaqiyatli o\'zgartirdingiz!';
$_['text_list']     = 'Ro\'yxat';
$_['text_type']     = 'Hisobot turini tanlang';
$_['text_filter']   = 'Filtr';