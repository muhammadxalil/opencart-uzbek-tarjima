<?php
// Heading
$_['heading_title']     = 'Kim onlayn';

// Text
$_['text_extension']    = 'Modulllar';
$_['text_success']      = 'Siz onlayn bo\'yicha hisobotlarni muvaffaqiyatli o\'zgartirdingiz!';
$_['text_list']         = 'Ro\'yxat';
$_['text_filter']       = 'Filtr';
$_['text_guest']        = 'Mehmon';

// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Mijoz';
$_['column_url']        = 'So\'nggi sahifa';
$_['column_referer']    = 'Manba';
$_['column_date_added'] = 'So\'nggi bosish';
$_['column_action']     = 'Harakat';

// Entry
$_['entry_ip']          = 'IP';
$_['entry_customer']    = 'Mijoz';
$_['entry_status']      = 'Holati';
$_['entry_sort_order']  = 'Tartib';

// Error
$_['error_permission']  = 'Diqqat: Sozlamalarni o\'zgartirishga sizda ruxsat yo\'q!';