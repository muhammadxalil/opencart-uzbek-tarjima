<?php
// Heading
$_['heading_title']                = 'Do\'kon boshqaruvi';

// Text
$_['text_settings']                = 'Sozlamalar';
$_['text_success']                 = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']                    = 'Магазины';
$_['text_add']                     = 'Qo\'shish';
$_['text_edit']                    = 'Tahrirlash';
$_['text_items']                   = 'Mahsulotlar';
$_['text_tax']                     = 'Soliqlar';
$_['text_account']                 = 'Hisob';
$_['text_checkout']                = 'Buyurtmani rasmiylashtirish';
$_['text_stock']                   = 'Ombor';
$_['text_shipping']                = 'Yetkazib berish manzili';
$_['text_payment']                 = 'To\'lovchining manzili';

// Column
$_['column_name']                  = 'Do\'kon nomi';
$_['column_url']	               = 'Do\'konning URL manzili';
$_['column_action']                = 'Harakat';

// Entry
$_['entry_url']                    = 'Do\'konning URL manzili';
$_['entry_ssl']                    = 'SSL URL';
$_['entry_meta_title']             = 'Мета-тег Title';
$_['entry_meta_description']       = 'Мета-тег Description';
$_['entry_meta_keyword']           = 'Мета-тег Keywords';
$_['entry_layout']                 = 'Odatiy tartibdagi maket';
$_['entry_theme']                  = 'Shablon';
$_['entry_name']                   = 'Do\'kon nomi';
$_['entry_owner']                  = 'Do\'kon egasi';
$_['entry_address']                = 'Manzil';
$_['entry_geocode']                = 'Geocode';
$_['entry_email']                  = 'E-Mail';
$_['entry_telephone']              = 'Telefon raqami';
$_['entry_fax']                    = 'Faks';
$_['entry_image']                  = 'Rasm';
$_['entry_open']                   = 'Ish tartibi';
$_['entry_comment']                = 'Qo\'shimcha ma\'lumot';
$_['entry_location']               = 'Joylashuvi';
$_['entry_country']                = 'Mamlakat';
$_['entry_zone']                   = 'Tuman / Viloyat';
$_['entry_language']               = 'Til';
$_['entry_currency']               = 'Valyuta';
$_['entry_tax']                    = 'Soliqlarni hisobga olgan holda narxlarni ko\'rsatish';
$_['entry_tax_default']            = 'Do\'konning soliq manzili';
$_['entry_tax_customer']           = 'Mijozning soliq manzili';
$_['entry_customer_group']         = 'Mijozlar guruhi';
$_['entry_customer_group_display'] = 'Xaridor guruhlarini ko\'rsatish';
$_['entry_customer_price']         = 'Клиентские цены';
$_['entry_account']                = 'Ro\'yxatdan o\'tishda tasdiqlash';
$_['entry_cart_weight']            = 'Savat sahifasidagi vazn';
$_['entry_checkout_guest']         = 'Mehmon buyurtmasi';
$_['entry_checkout']               = 'Buyurtma berishda tasdiqlash';
$_['entry_order_status']           = 'Buyurtma holati';
$_['entry_stock_display']          = 'Ombor balansini ko\'rsating';
$_['entry_stock_checkout']         = 'Omborda yetishmovchilik bo\'lganda buyurtma';
$_['entry_logo']                   = 'Logotip';
$_['entry_icon']                   = 'Ikonka';
$_['entry_secure']                 = 'SSL-dan foydalanish';

// Help
$_['help_url']                     = 'Do\'konga to\'liq URL-ni qo\'shgan holda. Oxirida \'/\' qo\'shing. Masalan: http://wwwww.yourdomain.com/path/';
$_['help_ssl']                     = 'Do\'koningizning SSL URL manzili. Oxirida \'/\' qo\'shing. Masalan: http://www.yourdomain.com/path/ Yangi joylashuv yaratish uchun kataloglardan foydalanmang. Siz har doim boshqa domen yoki subdomen xostingidan foydalanishingiz kerak.';
$_['help_geocode']                 = 'Iltimos, joylashuvingizni GeoCode sifatida kiriting.';
$_['help_open']                    = 'Do\'koningizning ishlash tartibi.';
$_['help_comment']                 = 'Ushbu maydon mijozga qo\'shimcha ma\'lumot olish uchun. Masalan, bizning do\'kon faqat Visa kartalarini qabul qiladi.';
$_['help_location']                = '"Biz bilan bog\'laning" sahifasida joylashtirmoqchi bo\'lgan do\'konning joylashuvi haqida qo\'shimcha ma\'lumot.".';
$_['help_currency']                = 'Standart valyutani o\'zgartirish. O\'zgarishlarni ko\'rish va cookie-fayllarni tozalash uchun brauzeringiz keshini tozalashingiz kerak.';
$_['help_tax_default']             = 'Agar foydalanuvchi vakolat bermasa, soliqlarni hisoblash uchun do\'kon manzilidan foydalaning. Siz do\'kon manzilini yetkazib berish manzili yoki to\'lovchi manzili sifatida ishlatishni tanlashingiz mumkin';
$_['help_tax_customer']            = 'Soliqlarni hisoblash uchun vakolat berilganda mijozning manzilini (standart) ishlating. Siz yetkazib berish manzili yoki to\'lovchi manzili uchun standart mijoz manzilidan foydalanishni tanlashingiz mumkin';
$_['help_customer_group']          = 'Standart mijozlar guruhi.';
$_['help_customer_group_display']  = 'Ro\'yxatga olish paytida yangi mijozlar tanlashlari mumkin bo\'lgan mijozlar guruhini ko\'rsating, masalan, "Ulgurji xaridorlar"';
$_['help_customer_price']          = 'Narxlarni faqat ro\'yxatdan o\'tgan mijozlarga ko\'rsatish';
$_['help_account']                 = 'Hisobni ro\'yxatdan o\'tkazishda "qoidalarga rozilik" tasdiqlashni talab qilish.';
$_['help_checkout_guest']          = 'Hisob yaratmasdan mijozlarga buyurtma berishga ruxsat beradi. Agar mahsulotda yuklab olinadigan fayllar bo\'lsa, unda bu funktsiya ishlamaydi.';
$_['help_checkout']                = 'Buyurtmani joylashtirishda "qoidalarga rozilik" tasdiqlashni talab qilish.';
$_['help_order_status']            = 'Yangi buyurtma kelganda standart buyurtma holati.';
$_['help_stock_display']           = 'Qolgan tovarlarni mahsulot sahifasida ko\'rsatish.';
$_['help_stock_checkout']          = 'Agar buyurtma qilingan tovarlar hozirda mavjud bo\'lmasa, mijozlarga buyurtma berishiga ruxsat bering.';
$_['help_icon']                    = 'Ikonka PNG formatida, 16px * 16px o\'lchamda bo\'lishi kerak.';
$_['help_secure']                  = 'SSL-dan foydalanish uchun sizning hosting SSL sertifikatini qo\'llab-quvvatlayotganiga va SSL manzillari konfiguratsiya faylida ro\'yxatdan o\'tganligiga ishonch hosil qiling.';

// Error
$_['error_warning']                = 'Xatolik! Formani xatolarini tekshiring!';
$_['error_permission']             = 'Sozlamalarni o\'zgartirishga sizda ruxsat yo\'q!';
$_['error_url']                    = 'Do\'kon URL manzili kerak!';
$_['error_meta_title']             = 'Sarlavha 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_name']                   = 'Do\'kon nomi 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_owner']                  = 'Do\'kon egasining ismi 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_address']                = 'Do\'kon manzili 10-256 belgidan iborat bo\'lishi kerak!';
$_['error_email']                  = 'Elektron pochta manzili noto\'g\'ri kiritilgan!';
$_['error_telephone']              = 'Telefon raqami 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_customer_group_display'] = 'Agar siz ushbu xususiyatdan foydalanmoqchi bo\'lsangiz, siz odatiy mijozlar guruhini qo\'shishingiz kerak!';
$_['error_default']                = 'Asosiy do\'konni o\'chirib bo\'lmaydi!';
$_['error_store']                  = 'Xato: Ushbu do\'konni o\'chirib bo\'lmaydi, chunki %s buyurtmalari bor!';


