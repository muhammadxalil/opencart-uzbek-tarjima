<?php
// Heading
$_['heading_title']     = 'Filtrlar';

// Text
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']         = 'Filtrlar';
$_['text_add']          = 'Qo\'shish';
$_['text_edit']         = 'Tahrirlash';

// Column
$_['column_group']      = 'Filtrlar guruhi';
$_['column_sort_order'] = 'Saralash tartibi';
$_['column_action']     = 'Harakat';

// Entry
$_['entry_group']       = 'Filtrlar guruhi nomi';
$_['entry_name']        = 'Filtr nomi';
$_['entry_sort_order']  = 'Saralash tartibi';

// Error
$_['error_permission']  = 'Sizda tahrirlashga ruxsat yo\'q';
$_['error_group']       = 'Nom 1 tadan 64 tagacha belgidan iborat bo\'lishi kerak';
$_['error_name']        = 'Nom 1 tadan 64 tagacha belgidan iborat bo\'lishi kerak';

