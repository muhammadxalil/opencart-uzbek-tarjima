<?php
// Heading
$_['heading_title']          = 'Atributlar';

// Text
$_['text_success']           = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']              = 'Atributlar ro\'yhati';
$_['text_add']               = 'Qo\'shish';
$_['text_edit']              = 'Atribut sozlamalari';

// Column
$_['column_name']            = 'Atribut nomi';
$_['column_attribute_group'] = 'Atribut guruhi';
$_['column_sort_order']      = 'Saralash tartibi';
$_['column_action']          = 'Harakat';

// Entry
$_['entry_name']             = 'Atribut nomi';
$_['entry_attribute_group']  = 'Atribut guruhi';
$_['entry_sort_order']       = 'Saralash tartibi';

// Error
$_['error_permission']       = 'Sizda atributlarni o\'zgartirish huquqi yo\'q.!';
$_['error_attribute_group']  = 'Atribut guruhi talab qilinadi!';
$_['error_name']             = 'Atribut nomi 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_product']          = 'Diqqat: Bu atributni o\'chirib bo\'lmaydi, chunki u %s mahsulotga tayinlangan!';


