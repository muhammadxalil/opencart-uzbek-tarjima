<?php
// Heading
$_['heading_title']          = 'Kategoriyalar';

// Text
$_['text_success']           = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']              = 'Kategoriyalar';
$_['text_add']               = 'Qo\'shish';
$_['text_edit']              = 'Tahrirlash';
$_['text_default']           = 'Asosiy do\'kon';

// Column
$_['column_name']            = 'Kategoriyalar';
$_['column_sort_order']      = 'Saralash tartibi';
$_['column_action']          = 'Harakat';

// Entry
$_['entry_name']             = 'Kategoriya';
$_['entry_description']      = 'Ta\'rif';
$_['entry_meta_title'] 	     = 'Meta-teg Title';
$_['entry_meta_keyword']     = 'Meta-teg Keywords';
$_['entry_meta_description'] = 'Meta-teg Description';
$_['entry_keyword']          = 'SEO URL';
$_['entry_parent']           = 'Ota-onalar toifasi';
$_['entry_filter']           = 'Filtrlar';
$_['entry_store']            = 'Do\'konlar';
$_['entry_image']            = 'Toifa rasmi';
$_['entry_top']              = 'Asosiy menyu';
$_['entry_column']           = 'Ustunlar';
$_['entry_sort_order']       = 'Saralash tartibi';
$_['entry_status']           = 'Holati';
$_['entry_layout']           = 'Maket';

// Help
$_['help_filter']            = '(Avtomatik to‘ldirish)';
$_['help_keyword']           = 'Tizim bo\'ylab noyob bo\'lishi kerak.';
$_['help_top']               = 'Asosiy menyuda ko\'rsatish (faqat asosiy ota-onalar toifalari uchun).';
$_['help_column']            = 'Kategoriya ochilishidagi ustunlar soni (faqat asosiy ota-onalar toifalari uchun).';

// Error
$_['error_warning']          = 'Anketani xatolar uchun diqqat bilan tekshiring!';
$_['error_permission']       = 'Sizda toifalarni o\'zgartirish uchun ruxsat yo\'q.!';
$_['error_name']             = 'Turkum nomi 2 tadan 255 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_meta_title']       = 'Kalit so\'z 3 tadan 255 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_keyword']          = 'SEO URL band!';
$_['error_parent']           = 'Ota-onalar toifasi noto‘g‘ri tanlangan!';


