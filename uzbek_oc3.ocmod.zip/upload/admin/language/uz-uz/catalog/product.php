<?php
// Heading
$_['heading_title']          = 'Mahsulotlar';

// Text
$_['text_success']           = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']              = 'Mahsulotlar';
$_['text_add']               = 'Qo\'shish';
$_['text_edit']              = 'Tahrirlash';
$_['text_plus']              = '+';
$_['text_minus']             = '-';
$_['text_default']           = 'Asosiy do\'kon';
$_['text_option']            = 'Variant';
$_['text_option_value']      = 'Variant qiymati';
$_['text_percent']           = 'Foiz';
$_['text_amount']            = 'Qat\'iy belgilangan miqdor';

// Column
$_['column_name']            = 'Mahsulot nomi';
$_['column_model']           = 'Model';
$_['column_image']           = 'Rasm';
$_['column_price']           = 'Saytdagi narxi';
$_['column_quantity']        = 'Miqdori';
$_['column_status']          = 'Holati';
$_['column_action']          = 'Harakat';

// Entry
$_['entry_name']             = 'Mahsulot nomi';
$_['entry_description']      = 'Ta\'rif';
$_['entry_meta_title'] 	     = 'Meta-teg Title';
$_['entry_meta_keyword'] 	 = 'Meta-teg Keyword';
$_['entry_meta_description'] = 'Meta-teg Description';
$_['entry_keyword']          = 'SEO URL';
$_['entry_model']            = 'Model';
$_['entry_sku']              = 'Artikul';
$_['entry_upc']              = 'UPC';
$_['entry_ean']              = 'EAN';
$_['entry_jan']              = 'JAN';
$_['entry_isbn']             = 'ISBN';
$_['entry_mpn']              = 'MPN';
$_['entry_location']         = 'Joylashuvi';
$_['entry_shipping']         = 'Yetkazib berish talab qilinadi';
$_['entry_manufacturer']     = 'Ishlab chiqaruvchi';
$_['entry_store']            = 'Do\'konlar';
$_['entry_date_available']   = 'Keltirilgan sana';
$_['entry_quantity']         = 'Midqori';
$_['entry_minimum']          = 'Minimal miqdori';
$_['entry_stock_status']     = 'Omborda mavjud emasligi';
$_['entry_price']            = 'Narxi';
$_['entry_tax_class']        = 'Soliq';
$_['entry_points']           = 'Ballar';
$_['entry_option_points']    = 'Ballar';
$_['entry_subtract']         = 'Ombordan olib tahslamoq';
$_['entry_weight_class']     = 'Og\'irlik o\'lchov birligi';
$_['entry_weight']           = 'Og\'irligi';
$_['entry_dimension']        = 'O\'lchami (U x E x B)';
$_['entry_length_class']     = 'Uzunlik o\'lchov birligi';
$_['entry_length']           = 'Uzunligi';
$_['entry_width']            = 'Eni';
$_['entry_height']           = 'Bo\'yi';
$_['entry_image']            = 'Mahsulot rasmi';
$_['entry_additional_image'] = 'Qo\'shimcha rasm';
$_['entry_customer_group']   = 'Mijozlar guruhi';
$_['entry_date_start']       = 'Boshlangan sanasi';
$_['entry_date_end']         = 'Tugallangan sanasi';
$_['entry_priority']         = 'Ustuvorlik';
$_['entry_attribute']        = 'Atribut';
$_['entry_attribute_group']  = 'Atributlar guruhlari';
$_['entry_text']             = 'Matn';
$_['entry_option']           = 'Variant';
$_['entry_option_value']     = 'Tanlov qiymati';
$_['entry_required']         = 'Zarur';
$_['entry_status']           = 'Holati';
$_['entry_sort_order']       = 'Saralash tartibi';
$_['entry_category']         = 'Kategoriyalarda ko\'rsatish';
$_['entry_filter']           = 'Filtrlar';
$_['entry_download']         = 'Yuklamalar';
$_['entry_related']          = 'Tavsiya etiladigan mahsulotlar';
$_['entry_tag']          	 = 'Mahsulot tegi';
$_['entry_reward']           = 'Mukofot ballari';
$_['entry_layout']           = 'Maket';
$_['entry_recurring']        = 'Davriylik holati';

// Help
$_['help_keyword']           = 'Butun tizim bo\'yicha va bo\'sh joylarsiz noyob bo\'lishi kerak.';
$_['help_sku']               = 'SKU yoki ishlab chiqaruvchi kodi';
$_['help_upc']               = 'Universal mahsulot kodi';
$_['help_ean']               = 'Yevropa mahsulot kodi';
$_['help_jan']               = 'Yaponiya mahsulot kodi';
$_['help_isbn']              = 'Xalqaro standart kitob raqami';
$_['help_mpn']               = 'Ishlab chiqaruvchi raqami';
$_['help_manufacturer']      = '(Avtomatik to\'ldirish)';
$_['help_minimum']           = 'Buyurtmadagi minimal tovar miqdori (savatga qo\'shilgan mahsulot soni shu miqdordan kam bo\'lishi taqiqlanadi)';
$_['help_stock_status']      = 'Holat mahsulot omborda bo\'lmaganida ko\'rsatiladi';
$_['help_points']            = 'Tovarlarni sotib olish uchun ballar soni. Bonusli ballar bilan mahsulotni sotib olmasliklari uchun 0 ga sozlang.';
$_['help_category']          = '(Avtomatik to\'ldirish)';
$_['help_filter']            = '(Avtomatik to\'ldirish)';
$_['help_download']          = '(Avtomatik to\'ldirish)';
$_['help_related']           = '(Avtomatik to\'ldirish)';
$_['help_tag']               = 'teglar vergul bilan ajratiladi';

// Error
$_['error_warning']          = 'Formani xatolar uchun ehtiyotkorlik bilan tekshiring!';
$_['error_permission']       = 'Sizda mahsulotni o\'zgartirish huquqi yo\'q!';
$_['error_name']             = 'Mahsulot nomi 3 tadan 255 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_meta_title']       = 'Meta-teg 3 tadan 255 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_model']            = 'Mahsulot modeli 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_keyword']          = 'SEO URL band!';


