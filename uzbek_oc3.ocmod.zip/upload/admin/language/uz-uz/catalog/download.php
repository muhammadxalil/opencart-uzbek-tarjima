<?php
// Heading
$_['heading_title']     = 'Yuklab olish uchun fayllar';

// Text
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']         = 'Yuklab olish uchun fayllar';
$_['text_add']          = 'Qo\'shish';
$_['text_edit']         = 'Tahrirlash';
$_['text_upload']       = 'Fayl yuklandi';

// Column
$_['column_name']       = 'Nomi';
$_['column_date_added'] = 'Sana';
$_['column_action']     = 'Harakat';

// Entry
$_['entry_name']        = 'Yuklama sarlavhasi';
$_['entry_filename']    = 'Fayl nomi';
$_['entry_mask']        = 'Niqob';

// Help
$_['help_filename']     = 'Siz faylni yuklab olish tugmasi yoki FTP orqali quyidagi ma\'lumotlarni ko\'rsatib yuklashingiz mumkin.';
$_['help_mask']         = 'Fayl nomi va niqobi boshqacha bo\'lishi tavsiya etiladi, bu fayllarga to\'g\'ridan-to\'g\'ri kirishni oldini oladi.';

// Error
$_['error_permission']  = 'Yuklab olishlarni tahrirlashga sizda ruxsat yo\'q!';
$_['error_name']        = 'Nom 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_upload']      = 'Yuklab olish talab etiladi!';
$_['error_filename']    = 'Fayl nomi 3 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_exists']      = 'Fayl mavjud emas!';
$_['error_mask']        = 'Niqob 3 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_filetype']    = 'Fayl turi noto\'g\'ri!';
$_['error_product']     = 'Diqqat: Ushbu yuklamani o\'chirib bo\'lmaydi, chunki u %s mahsulotga tayinlangan!';

