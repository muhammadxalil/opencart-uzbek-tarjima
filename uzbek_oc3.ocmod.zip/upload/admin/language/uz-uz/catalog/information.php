<?php
// Heading
$_['heading_title']          = 'Maqolalar';

// Text
$_['text_success']           = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']              = 'Maqolalar';
$_['text_add']               = 'Qo\'shish';
$_['text_edit']              = 'Tahrirlash';
$_['text_default']           = 'Asosiy do\'kon';

// Column
$_['column_title']           = 'Maqola nomi';
$_['column_sort_order']	     = 'Saralash tartibi';
$_['column_action']          = 'Harakat';

// Entry
$_['entry_title']            = 'Maqola nomi';
$_['entry_description']      = 'Ta\'rif';
$_['entry_store']            = 'Do\'konlar';
$_['entry_meta_title'] 	     = 'Meta-teg Title';
$_['entry_meta_keyword'] 	 = 'Meta-teg Keywords';
$_['entry_meta_description'] = 'Meta-teg Description';
$_['entry_keyword']          = 'SEO URL';
$_['entry_bottom']           = 'Quyida ko\'rsatish';
$_['entry_status']           = 'Holati';
$_['entry_sort_order']       = 'Saralash tartibi';
$_['entry_layout']           = 'Sxemani tanlang';

// Help
$_['help_keyword']           = 'Butun tizim bo\'yicha va bo\'sh joylarsiz noyob bo\'lishi kerak';
$_['help_bottom']            = 'Saytning pastki qismida ko\'rsatish (futer, podval)';

// Error
$_['error_warning']          = 'Formani xatolar uchun ehtiyotkorlik bilan tekshiring!';
$_['error_permission']       = 'Sizda maqolalarni o\'zgartirish huquqi yo\'q!';
$_['error_title']            = 'Maqola nomi 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_description']      = 'Ta\'rif kamida 3 ta belgidan iborat bo\'lishi kerak!';
$_['error_meta_title']       = 'Meta-teg Title 3 tadan 255 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_keyword']          = 'SEO URL band!';
$_['error_account']          = 'Ushbu sahifani o\'chirib bo\'lmaydi, chunki u standart xavfsizlik siyosati bilan tayinlangan!';
$_['error_checkout']         = 'Ushbu sahifani o\'chirib bo\'lmaydi, chunki u standart kelishuv shartlariga ko\'ra tayinlangan!';
$_['error_affiliate']        = 'Sahifani o\'chirib bo\'lmaydi, chunki u sheriklik dasturida ishlatilyapti!';
$_['error_return']           = 'Sahifani o\'chirib bo\'lmaydi, chunki u mahsulotni qaytarish shartlarida ishlatiladi!';
$_['error_store']            = 'Sahifani o\'chirib bo\'lmaydi, chunki u %s do\'konlariga tayinlangan!';


