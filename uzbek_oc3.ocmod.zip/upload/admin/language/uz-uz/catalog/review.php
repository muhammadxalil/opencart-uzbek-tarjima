<?php
// Heading
$_['heading_title']     = 'Sharhlar';

// Text
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']         = 'Sharhlar';
$_['text_add']          = 'Qo\'shish';
$_['text_edit']         = 'Tahrirlash';

// Column
$_['column_product']    = 'Mahsulot';
$_['column_author']     = 'Muallif';
$_['column_rating']     = 'Bahosi(reyting)';
$_['column_status']     = 'Holati';
$_['column_date_added'] = 'Sana';
$_['column_action']     = 'Harakat';

// Entry
$_['entry_product']     = 'Mahsulot';
$_['entry_author']      = 'Muallif';
$_['entry_rating']      = 'Bahosi(reyting)';
$_['entry_status']      = 'Holati';
$_['entry_text']        = 'Matn';
$_['entry_date_added']  = 'Sana';

// Help
$_['help_product']      = '(Avtomatik to\'ldirish)';

// Error
$_['error_permission']  = 'Sizda sharhlarni o\'zgartirish huquqi yo\'q!';
$_['error_product']     = 'Mahsulotni tanlash talab qilinadi!';
$_['error_author']      = 'Muallif nomi 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!!';
$_['error_text']        = 'Sharh matni kamida 1 ta belgidan iborat bo\'lishi kerak!';
$_['error_rating']      = 'Baho(reyting) o\'rnatish talab etiladi!';

