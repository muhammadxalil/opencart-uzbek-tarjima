<?php
// Heading
$_['heading_title']      = 'Tanlovlar';

// Text
$_['text_success']       = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']          = 'Tanlovlar';
$_['text_add']           = 'Qo\'shish';
$_['text_edit']          = 'Tahrirlash';
$_['text_choose']        = 'Tanlash';
$_['text_select']        = 'Ro‘yxat';
$_['text_radio']         = 'O\'chirib-yoqqich';
$_['text_checkbox']      = 'Bayroqcha';
$_['text_input']         = 'Kiritish maydoni';
$_['text_text']          = 'Matn';
$_['text_textarea']      = 'Matn maydoni';
$_['text_file']          = 'Fayl';
$_['text_date']          = 'Sana';
$_['text_datetime']      = 'Sana va vaqt';
$_['text_time']          = 'Vaqt';

// Column
$_['column_name']        = 'Variant';
$_['column_sort_order']  = 'Saralash tartibi';
$_['column_action']      = 'Harakat';

// Entry
$_['entry_name']         = 'Variant nomi';
$_['entry_type']         = 'Turi';
$_['entry_option_value'] = 'Variant qiymati';
$_['entry_image']        = 'Rasm';
$_['entry_sort_order']   = 'Saralash tartibi';

// Error
$_['error_permission']   = 'Variantni o\'zgartirish uchun sizda yetarli huquq yo\'q!';
$_['error_name']         = 'Variant nomi 1 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_type']         = 'Variant qiymati ko\'rsatilmagan!';
$_['error_option_value'] = 'Variant qiymati 1 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_product']      = 'Diqqat: Ushbu variantni o\'chirib bo\'lmaydi, chunki u %s mahsulotga tayinlangan!';

