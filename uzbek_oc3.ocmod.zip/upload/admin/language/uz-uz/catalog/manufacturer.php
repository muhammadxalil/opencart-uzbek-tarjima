<?php
// Heading
$_['heading_title']     = 'Ishlab chiqaruvchilar';

// Text
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']         = 'Ishlab chiqaruvchilar';
$_['text_add']          = 'Qo\'shish';
$_['text_edit']         = 'Tahrirlash';
$_['text_default']      = 'Asosiy do\'kon';
$_['text_percent']      = 'Foiz';
$_['text_amount']       = 'Qat\'iy belgilangan miqdor';

// Column
$_['column_name']       = 'Ishlab chiqaruvchi';
$_['column_sort_order'] = 'Saralash tartibi';
$_['column_action']     = 'Harakat';

// Entry
$_['entry_name']        = 'Ishlab chiqaruvchi';
$_['entry_store']       = 'Do\'konlar';
$_['entry_keyword']     = 'SEO URL';
$_['entry_image']       = 'Rasm';
$_['entry_sort_order']  = 'Saralash tartibi';
$_['entry_type']        = 'Turi';

// Help
$_['help_keyword']      = 'Butun tizim bo\'yicha va bo\'sh joylarsiz noyob bo\'lishi kerak';

// Error
$_['error_permission']  = 'Siz ishlab chiqaruvchilarni o\'zgartirish huquqiga ega emassiz!';
$_['error_name']        = 'Ishlab chiqaruvchining nomi 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_keyword']     = 'SEO URL band!';
$_['error_product']     = 'Diqqat: Ushbu ishlab chiqaruvchini o\'chirib bo\'lmaydi, chunki u %s mahsulotga tayinlangan!!';


