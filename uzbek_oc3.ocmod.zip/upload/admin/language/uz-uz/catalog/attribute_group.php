<?php
// Heading
$_['heading_title']     = 'Atributlar guruhlari';

// Text
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']         = 'Atributlar guruhi ro\'yxati';
$_['text_add']          = 'Qo\'shish';
$_['text_edit']         = 'Tahrirlash';

// Column
$_['column_name']       = 'Atributlar guruhining nomi';
$_['column_sort_order'] = 'Saralash tartibi';
$_['column_action']     = 'Harakat';

// Entry
$_['entry_name']        = 'Atributlar guruhining nomi';
$_['entry_sort_order']  = 'Saralash tartibi';

// Error
$_['error_permission']  = 'Sizda atributlarni o\'zgartirish huquqi yo\'q.!';
$_['error_name']        = 'Atribut nomi 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_attribute']   = 'Diqqat: Ushbu guruhni o\'chirib bo\'lmaydi, chunki u %s atributlari tomonidan ishlatilyapti!';
$_['error_product']     = 'Diqqat: Bu atributni o\'chirib bo\'lmaydi, chunki u %s mahsulotga tayinlangan!';

