<?php
// Heading
$_['heading_title']			= 'Davriylik holati';

// Text
$_['text_success']          = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']             = 'Davriylik holati';
$_['text_add']              = 'Qo\'shish';
$_['text_edit']             = 'Tahrirlash';
$_['text_day']				= 'Kun';
$_['text_week']				= 'Hafta';
$_['text_semi_month']		= 'Yarim oy';
$_['text_month']			= 'Oy';
$_['text_year']				= 'Yil';
$_['text_recurring']	    = '<p><i class="fa fa-info-circle"></i> Hisob ko\'rinishining takrorlanishi chastotani tsiklga ko\'paytirish yo\'li bilan hisoblanadi..</p><p>Masalan, agar siz "hafta" va "2" tsikllaridan foydalansangiz, foydalanuvchiga har 2 haftada hisob-kitob qilinadi.</p><p>Davomiyligi - foydalanuvchi amalga oshirishi kerak bo\'lgan to\'lovlar soni. To\'lovlarni bekor qilishni xohlasangiz, 0 ni o\'rnating.</p>';
$_['text_profile']			= 'Davriylik';
$_['text_trial']			= 'Sinov profili';

// Entry
$_['entry_name']		    = 'Nomi';
$_['entry_price']			= 'Narxi';
$_['entry_duration']		= 'Davomiyligi';
$_['entry_cycle']			= 'Tsikl';
$_['entry_frequency']		= 'Chastota';
$_['entry_trial_price']		= 'Narxi';
$_['entry_trial_duration']	= 'Davomiyligi';
$_['entry_trial_status']	= 'Holati';
$_['entry_trial_cycle']	    = 'Tsikl';
$_['entry_trial_frequency'] = 'Chastota';
$_['entry_status']			= 'Holati';
$_['entry_sort_order']		= 'Saralash tartibi';

// Column
$_['column_name']			= 'Nomi';
$_['column_sort_order']	    = 'Saralash tartibi';
$_['column_action']         = 'Harakat';

// Error
$_['error_warning']         = 'Formani xatolar uchun ehtiyotkorlik bilan tekshiring!';
$_['error_permission']		= 'Sizda tahrirlash huquqi yo\'q!';
$_['error_name']			= 'Nom 3 tadan 255 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_product']			= 'Ushbu profilni o\'chirib bo\'lmaydi, chunki u %s mahsulotga tayinlangan!';

