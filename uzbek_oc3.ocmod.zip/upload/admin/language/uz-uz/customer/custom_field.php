<?php
// Heading
$_['heading_title']        = 'Sozlanadigan maydonlar';

// Text
$_['text_success']         = 'Sozlamalar muvaffaqiyatli o\'zgartirildi';
$_['text_list']            = 'Sozlanadigan hududlar';
$_['text_add']             = 'Qo\'shish';
$_['text_edit']            = 'Tahrirlash';
$_['text_choose']          = 'Tanlash';
$_['text_select']          = 'Ro\'yxat';
$_['text_radio']           = 'Ulagich';
$_['text_checkbox']        = 'Bayroqcha';
$_['text_input']           = 'Matn kiritish';
$_['text_text']            = 'Matn';
$_['text_textarea']        = 'Matn maydoni';
$_['text_file']            = 'Fayl';
$_['text_date']            = 'Sana';
$_['text_datetime']        = 'Sana &amp; Vaqt';
$_['text_time']            = 'Vaqt';
$_['text_account']         = 'Hisob';
$_['text_address']         = 'Manzil';
$_['text_regex']           = 'Doimiy ibora';

// Column
$_['column_name']          = 'Maydon nomi';
$_['column_location']      = 'Joylashuvi';
$_['column_type']          = 'Turi';
$_['column_sort_order']    = 'Saralash tartibi';
$_['column_action']        = 'Harakat';

// Entry
$_['entry_name']           = 'Maydon nomi';
$_['entry_location']       = 'Joylashuvi';
$_['entry_type']           = 'Turi';
$_['entry_value']          = 'Qiymati';
$_['entry_validation']     = 'Tekshirish';
$_['entry_custom_value']   = 'Maydon qiymati';
$_['entry_customer_group'] = 'Mijozlar guruhi';
$_['entry_required']       = 'Majburiy';
$_['entry_status']         = 'Holati';
$_['entry_sort_order']     = 'Saralash tartibi';

// Help
$_['help_regex']           = 'regexdan foydalan. Namuna: /[a-zA-Z0-9_-]/';
$_['help_sort_order']      = 'Saralash tartibini birinchisidan ustun qo\'yish uchun minusdan foydalaning.';

// Error
$_['error_permission']     = 'Sozlanadigan Maydonlar modulini o\'zgartirishga sizda ruxsat yo\'q!';
$_['error_name']           = 'Maydon nomi 3 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_type']           = 'Diqqat! Maydon qiymatini kiritish kerak!';
$_['error_custom_value']   = 'Maydon qiymati 3 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';

