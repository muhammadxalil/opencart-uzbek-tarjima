<?php
// Heading
$_['heading_title']         = 'Xaridorlar';

// Text
$_['text_success']          = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']             = 'Xaridorlar';
$_['text_add']              = 'Qo\'shish';
$_['text_edit']             = 'Tahrirlash';
$_['text_default']          = 'Odatiy';
$_['text_balance']          = 'Balans';

// Column
$_['column_name']           = 'Mijozning ismi';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Mijozlar guruhi';
$_['column_status']         = 'Holati';
$_['column_date_added']     = 'Qo\'shilgan sanasi';
$_['column_comment']        = 'Sharh';
$_['column_description']    = 'Ta\'rif';
$_['column_amount']         = 'Miqdor';
$_['column_points']         = 'Ballar';
$_['column_ip']             = 'IP';
$_['column_total']          = 'Umumiy iqdor';
$_['column_action']         = 'Harakat';

// Entry
$_['entry_customer_group']  = 'Xaridorlar guruhi';
$_['entry_firstname']       = 'Ismi, Otasining ismi';
$_['entry_lastname']        = 'Familiyasi';
$_['entry_email']           = 'E-Mail';
$_['entry_telephone']       = 'Telefon';
$_['entry_fax']             = 'Faks';
$_['entry_newsletter']      = 'Yangiliklarga obuna bo\'lish';
$_['entry_status']          = 'Holati';
$_['entry_approved']        = 'Tasdiqlangan';
$_['entry_safe']            = 'Xavfsiz';
$_['entry_password']        = 'Parol';
$_['entry_confirm']         = 'Parolni tasdiqlang';
$_['entry_company']         = 'Kompaniya';
$_['entry_address_1']       = 'Manzil 1';
$_['entry_address_2']       = 'Manzil 2';
$_['entry_city']            = 'Shahar';
$_['entry_postcode']        = 'Pochta indeksi';
$_['entry_country']         = 'Mamlakat';
$_['entry_zone']            = 'Viloyat / Tuman';
$_['entry_default']         = 'Birlamchi manzil';
$_['entry_comment']         = 'Sharhlar';
$_['entry_description']     = 'Ta\'rif';
$_['entry_amount']          = 'Miqdor';
$_['entry_points']          = 'Ballar';
$_['entry_name']            = 'Mijozning ismi';
$_['entry_ip']              = 'IP';
$_['entry_date_added']      = 'Qo\'shilgan sanasi';

// Help
$_['help_safe']             = 'Ushbu mijozni firibgarlikka qarshi tizim tutgan bo\'lsa, uni tasdiqlash uchun "true" qiymatini qo\'ying';
$_['help_points']           = 'Ballarni olib tashlash uchun minuslardan foydalaning, masalan -60';

// Error
$_['error_warning']         = 'Formani xatolarini sinchkovlik bilan tekshiring!';
$_['error_permission']      = 'Sizda Mijozlar sozlamalarini o\'zgartirish huquqi yo\'q!';
$_['error_exists']          = 'Ushbu elektron pochta allaqachon ro\'yxatdan o\'tgan!';
$_['error_firstname']       = 'Ism 1 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_lastname']        = 'Familiya 1 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_email']           = 'Elektron pochta manzili noto\'g\'ri kiritilgan!';
$_['error_telephone']       = 'Telefon raqami 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_password']        = 'Parol 4 tadan 20 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_confirm']         = 'Parol va parolni tasdiqlash bir xil emas!';
$_['error_address_1']       = 'Manzil 3 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_city']            = 'Shahar nomi 2 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_postcode']        = 'Pochta indeksi 2 tadan 10 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_country']         = 'Mamlakatni tanlang!';
$_['error_zone']            = 'Hududni tanlang!';

