<?php
// Heading
$_['heading_title']         = 'Mijozlarni tasdiqlash';

// Text
$_['text_success']          = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']             = 'Mijozlar ro\'yxati';
$_['text_default']          = 'Standart';
$_['text_customer']         = 'Mijoz';
$_['text_affiliate']        = 'Hamkor';

// Column
$_['column_name']           = 'Mijozning ismi';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Mijozlar guruhi';
$_['column_type']           = 'Turi';
$_['column_date_added']     = 'Qo\'shilgan sanasi';
$_['column_action']         = 'Harakat';

// Entry
$_['entry_name']            = 'Mijozning ismi';
$_['entry_email']           = 'E-Mail';
$_['entry_customer_group']  = 'Mijozlar guruhi';
$_['entry_type']            = 'Turi';
$_['entry_date_added']      = 'Qo\'shilgan sanasi';

// Error
$_['error_permission']      = 'Sizda Mijozlarni tasdiqlash sozlamalarini o\'zgartirish huquqi mavjud emas!';