<?php
// Heading
$_['heading_title']     = 'Xaridorlar guruhlari';

// Text
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']         = 'Xaridorlar guruhlari';
$_['text_add']          = 'Qo\'shish';
$_['text_edit']         = 'Tahrirlash';

// Column
$_['column_name']       = 'Mijozlar guruhining nomi';
$_['column_sort_order'] = 'Saralash tartibi';
$_['column_action']     = 'Harakat';

// Entry
$_['entry_name']        = 'Nomi';
$_['entry_description'] = 'Ta\'rifi';
$_['entry_approval']    = 'Yangi mijozlarni tasdiqlash';
$_['entry_sort_order']  = 'Saralash tartibi';

// Help
$_['help_approval']     = 'Do\'konga kirishdan oldin mijozlar administrator tomonidan faollashtirilishi kerak.';

// Error
$_['error_permission']  = 'Xaridorlar guruhlari sozlamalarini o\'zgartirish uchun sizda ruxsat yo\'q!';
$_['error_name']        = 'Guruh nomi 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_default']     = 'Ushbu mijozlar guruhini o\'chirib bo\'lmaydi, chunki u asosiy do\'konga tayinlangan!';
$_['error_store']       = 'Ushbu mijozlar guruhini o\'chirib bo\'lmaydi, chunki u %s do\'konga tayinlangan!';
$_['error_customer']    = 'Ushbu mijozlar guruhini o\'chirib bo\'lmaydi, chunki u %s mijozga tayinlangan!';

