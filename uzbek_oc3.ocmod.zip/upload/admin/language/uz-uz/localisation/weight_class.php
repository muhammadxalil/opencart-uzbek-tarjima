<?php
// Heading
$_['heading_title']    = 'Og\'irlik birligi';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']        = 'Og\'irlik birligi';
$_['text_add']         = 'Qo\'shish';
$_['text_edit']        = 'Tahrirlash';

// Column
$_['column_title']     = 'Og\'irlik birligi nomi';
$_['column_unit']      = 'Og\'irlik birligi';
$_['column_value']     = 'Qiymati';
$_['column_action']    = 'Harakat';

// Entry
$_['entry_title']      = 'Og\'irlik birligi nomi';
$_['entry_unit']       = 'Og\'irlik birligi';
$_['entry_value']      = 'Qiymati';

// Help
$_['help_value']       = 'Agar standart og\'irlik birligi bo\'lsa, 1.00000 ga o\'rnating.';

// Error
$_['error_permission'] = 'Siz vazn birligini ro\'yxatini o\'zgartirish huquqiga ega emassiz!';
$_['error_title']      = 'Og\'irlik birligining nomi 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_unit']       = 'Og\'irlik birligi bittadan 4 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_default']    = 'Vazn birligini o\'chirib bo\'lmaydi, chunki u sukut bo\'yicha o\'rnatilgan!';
$_['error_product']    = 'Vazn o\'lchov birligini o\'chirib bo\'lmaydi, chunki %s mahsulotga belgilangan!';

