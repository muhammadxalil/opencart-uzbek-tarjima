<?php
// Heading
$_['heading_title']    = 'Qaytishlar holatlari';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']        = 'Qaytishlar holatlari';
$_['text_add']         = 'Qo\'shish';
$_['text_edit']        = 'Tahrirlash';

// Column
$_['column_name']      = 'Qaytish holati';
$_['column_action']    = 'Harakat';

// Entry
$_['entry_name']       = 'Qaytish holati nomi';

// Error
$_['error_permission'] = 'Qaytish holatini o\'zgartirish huquqiga ega emassiz!';
$_['error_name']       = 'Qaytish holati 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_default']    = 'Qaytish holatini istisno qilib bo\'lmaydi, chunki u asosiy do\'konning qaytish holatiga biriktirilgan!';
$_['error_return']     = 'Qaytish holatini o\'chirib bo\'lmaydi, chunki %s tovarga tayinlangan!';


