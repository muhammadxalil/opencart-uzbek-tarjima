<?php
// Heading
$_['heading_title']        = 'Valyutalar';

// Text
$_['text_success']         = 'Valyutalar kursi yangilandi';
$_['text_list']            = 'Valyutalar ro\'yhati';
$_['text_add']             = 'Qo\'shish';
$_['text_edit']            = 'Tahrirlash';
$_['text_iso']             = 'Вы можете найти полный список кодов валют ISO и настройки <a href="http://www.xe.com/iso4217.php" target="_blank">на сайте</a>.';

// Column
$_['column_title']         = 'Valyuta nomi';
$_['column_code']          = 'Kod';
$_['column_value']         = 'Qiymati';
$_['column_date_modified'] = 'So\'nggi yangilanish sanasi';
$_['column_action']        = 'Harakat';

// Entry
$_['entry_title']          = 'Valyuta nomi';
$_['entry_code']           = 'Kod';
$_['entry_value']          = 'Qiymati';
$_['entry_symbol_left']    = 'Chap tomondagi belgi';
$_['entry_symbol_right']   = 'O\'ng tomondagi belgi';
$_['entry_decimal_place']  = 'Vergulgan keyingi belgilar soni';
$_['entry_status']         = 'Holati';

// Help
$_['help_code']            = 'Agar valyuta sukut bo\'yicha o\'rnatilgan bo\'lsa, u o\'zgarmaydi.';
$_['help_value']           = 'Agar bu standart pul birligi bo\'lsa, 1.00000 ga o\'rnating.';

// Error
$_['error_permission']     = 'Sizda valyutalar ro\'yxatini o\'zgartirish huquqi yo\'q';
$_['error_title']          = 'Pul birligi 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_code']           = 'Valyuta kodi 3 ta belgidan iborat bo‘lishi kerak!';
$_['error_default']        = 'Valyutani o\'chirib bo\'lmaydi, chunki u standart qilib belgilangan!';
$_['error_store']          = 'Valyuta nomini o\'chirib bo\'lmaydi, chunki% s do\'konlarga belgilangan!';
$_['error_order']          = 'Valyuta nomini o\'chirib bo\'lmaydi, chunki %s buyurtmalarga tayinlangan!';

