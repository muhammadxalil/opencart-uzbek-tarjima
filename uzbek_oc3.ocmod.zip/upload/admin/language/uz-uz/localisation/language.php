<?php
// Heading
$_['heading_title']     = 'Tillar';

// Text
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']         = 'Tillar';
$_['text_add']          = 'Qo\'shish';
$_['text_edit']         = 'Tahrirlash';

// Column
$_['column_name']       = 'Til';
$_['column_code']       = 'Kod';
$_['column_sort_order'] = 'Saralash tartibi';
$_['column_action']     = 'Harakat';

// Entry
$_['entry_name']        = 'Nomi';
$_['entry_code']        = 'Kod';
$_['entry_locale']      = 'Kodlash';
$_['entry_status']      = 'Holati';
$_['entry_sort_order']  = 'Saralash tartibi';

// Help
$_['help_locale']       = 'Namuna: en_US.UTF-8,en_US,en-gb,en_gb,english или <br> ru_RU.UTF-8,ru_RU,russian';
$_['help_status']       = 'Til tugmachalarini ko\'rsatish / yashirish (do\'kon vitrinasi).';

// Error
$_['error_permission']  = 'Sizda tillar ro\'yxatini o\'zgartirish huquqi yo\'q!';
$_['error_exists']      = 'Diqqat: Avval tilni qo\'shing!';
$_['error_name']        = 'Til nomi 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_code']        = 'Til kodi kamida 2 belgidan iborat bo\'lishi kerak!';
$_['error_locale']      = 'Tilni kodlanishini ko\'rsatishingiz kerak!';
$_['error_default']     = 'Tilni o\'chirib bo\'lmaydi, chunki u sukut bo\'yicha ishlatilyapti!';
$_['error_admin']       = 'Til ma\'murning tili bo\'lganligi sababli chiqarib tashlanishi mumkin emas';
$_['error_store']       = 'Tillar o\'chirib bo\'lmaydi, chunki %s do\'konlarga tayinlangan!';
$_['error_order']       = '%s buyurtmaga berilganligi sababli tillarni o\'chirib bo\'lmaydi!';

