<?php
// Heading
$_['heading_title']     = 'Soliq klassi';

// Text
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']         = 'Klasslar ro\'yxati';
$_['text_add']          = 'Qo\'shish';
$_['text_edit']         = 'Tahrirlash';
$_['text_shipping']     = 'Yetkazib berish manzili';
$_['text_payment']      = 'To\'lov manzili';
$_['text_store']        = 'Do\'kon manzili';

// Column
$_['column_title']      = 'Soliq sinflari';
$_['column_action']     = 'Harakat';

// Entry
$_['entry_title']       = 'Soliq sinfi';
$_['entry_description'] = 'Ta\'rif';
$_['entry_rate']        = 'Soliq stavkasi';
$_['entry_based']       = 'Ga asoslangan';
$_['entry_geo_zone']    = 'Geografik hudud';
$_['entry_priority']    = 'Ustuvorlik';

// Error
$_['error_permission']  = 'Soliq sinflarini o\'zgartirish huquqiga ega emassiz!';
$_['error_title']       = 'Soliq nomi 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_description'] = 'Ta\'rif 3 tadan 255 gacha belgidan iborat bo\'lishi kerak!';
$_['error_product']     = 'Soliq stavkasini olib tashlab bo\'lmaydi, chunki %s tovarlarga belgilangan!';

