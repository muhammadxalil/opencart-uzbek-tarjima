<?php
// Heading
$_['heading_title']      = 'Geografik hududlar';

// Text
$_['text_success']       = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']          = 'Geografik hududlar';
$_['text_add']           = 'Qo\'shish';
$_['text_edit']          = 'Tahrirlash';

// Column
$_['column_name']        = 'Geografik hudud nomi';
$_['column_description'] = 'Ta\'rifi';
$_['column_action']      = 'Harakat';

// Entry
$_['entry_name']         = 'Geografik hudud nomi';
$_['entry_description']  = 'Ta\'rifi';
$_['entry_country']      = 'Davlat';
$_['entry_zone']         = 'Tuman / Viloyat';

// Error
$_['error_permission']   = 'Sizda geografik hududlarni o\'zgartirishga ruxsat yo\'q!';
$_['error_name']         = 'Geografik hudud nomi 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_description']  = 'Ta\'rif 3 tadan 255 tagacha bo\'lishi kerak!';
$_['error_tax_rate']     = 'Geografik hududni o\'chirib bo\'lmaydi, chunki %s soliq stavkalariga belgilangan!';

