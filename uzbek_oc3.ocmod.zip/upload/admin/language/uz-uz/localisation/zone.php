<?php
// Heading
$_['heading_title']          = 'Mintaqalar';

// Text
$_['text_success']           = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']              = 'Mintaqalar';
$_['text_add']               = 'Qo\'shish';
$_['text_edit']              = 'Tahrirlash';

// Column
$_['column_name']            = 'Mintaqa nomi';
$_['column_code']            = 'Mintaqa kodi';
$_['column_country']         = 'Mamlakat';
$_['column_action']          = 'Harakat';

// Entry
$_['entry_name']             = 'Mintaqa nomi';
$_['entry_code']             = 'Mintaqa kodi';
$_['entry_country']          = 'Mamlakat';
$_['entry_status']           = 'Holati';

// Error
$_['error_permission']       = 'Sizda mintaqalar ro\'yxatini o\'zgartirish huquqi yo\'q!';
$_['error_name']             = 'Mintaqaning nomi 3 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_default']          = 'Mamlakatni o\'chirib bo\'lmaydi, chunki u sukut bo\'yicha tayinlangan!';
$_['error_store']            = 'Mintaqani o\'chirib bo\'lmaydi, chunki u %s do\'konlariga tayinlangan!';
$_['error_address']          = 'Mintaqani o\'chirib bo\'lmaydi, chunki u %s manzillar kitobi yozuvlariga tayinlangan!';
$_['error_affiliate']        = 'Mintaqani o\'chirib bo\'lmaydi, chunki %s sheriklarga tayinlangan!';
$_['error_zone_to_geo_zone'] = 'Mintaqani o\'chirib bo\'lmaydi, chunki %s geografik hududlarga tayinlangan!';

