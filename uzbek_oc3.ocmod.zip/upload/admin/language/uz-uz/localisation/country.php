<?php
// Heading
$_['heading_title']           = 'Davlatlar';

// Text
$_['text_success']            = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']               = 'Davlatlar';
$_['text_add']                = 'Qo\'shish';
$_['text_edit']               = 'Tahrirlash';

// Column
$_['column_name']             = 'Davlat nomi';
$_['column_iso_code_2']       = 'Kod ISO (2)';
$_['column_iso_code_3']       = 'Kod ISO (3)';
$_['column_action']           = 'Harakat';

// Entry
$_['entry_name']              = 'Davlat nomi';
$_['entry_iso_code_2']        = 'Kod ISO (2)';
$_['entry_iso_code_3']        = 'Kod ISO (3)';
$_['entry_address_format']    = 'Manzil formati';
$_['entry_postcode_required'] = 'Indeks majburiy';
$_['entry_status']            = 'Holati';

// Help
$_['help_address_format']     = 'Ism = {firstname}<br />Familiya = {lastname}<br />Kompaniya = {company}<br />Manzil 1 = {address_1}<br />Manzil 2 = {address_2}<br />Shahar = {city}<br />Indeks = {postcode}<br />Hudud = {zone}<br />Hudud kodi = {zone_code}<br />Davlat = {country}';

// Error
$_['error_permission']        = 'Sizda davlatlar ro\'yxatini o\'zgartirish huquqi yo\'q';
$_['error_name']              = 'Mamlakat nomi 3 tadan 128 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_default']           = 'Ushbu mamlakatni o\'chirib bo\'lmaydi, chunki u do\'kon uchun standart mamlakatdir!';
$_['error_store']             = 'Bu mamlakatni o\'chirib bo\'lmaydi, chunki %s do\'konlarga tayinlangan!';
$_['error_address']           = 'Ushbu mamlakatni o\'chirib bo\'lmaydi, chunki %s manzillar kitobi yozuvlariga tayinlangan!';
$_['error_affiliate']         = 'Bu mamlakatni o\'chirib bo\'lmaydi, chunki %s hamkorlarga tayinlangan!';
$_['error_zone']              = 'Bu mamlakatni o\'chirib bo\'lmaydi, chunki u %s hududlarga tayinlangan!';
$_['error_zone_to_geo_zone']  = 'Bu mamlakatni o\'chirib bo\'lmaydi, chunki u %s geografik hududlarga tayinlangan!';

