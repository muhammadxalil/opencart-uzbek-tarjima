<?php
// Heading
$_['heading_title']    = 'Buyurtmalar holatlari';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']        = 'Buyurtmalar holatlari';
$_['text_add']         = 'Qo\'shish';
$_['text_edit']        = 'Tahrirlash';

// Column
$_['column_name']      = 'Buyurtmalar holatlari';
$_['column_action']    = 'Harakat';

// Entry
$_['entry_name']       = 'Buyurtma holati';

// Error
$_['error_permission'] = 'Buyurtma holatini o\'zgartirish huquqiga ega emassiz!';
$_['error_name']       = 'Buyurtma holati 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_default']    = 'Buyurtma holatini istisno qilib bo\'lmaydi, chunki u asosiy do\'konning buyurtma holatiga qo\'shilgan!';
$_['error_download']   = 'Buyurtma holatini bekor qilib bo\'lmaydi, chunki u standart yuklab olish holatiga qo\'shilgan!';
$_['error_store']      = '%s do\'konlarga tayinlanganligi sababli buyurtma holatini o\'chirib bo\'lmaydi!';
$_['error_order']      = 'Buyurtma holatini o\'chirib bo\'lmaydi, chunki %s buyurtmalarga tayinlangan!';


