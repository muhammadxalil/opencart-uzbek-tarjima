<?php
// Heading
$_['heading_title']    = 'Операции возвратов';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']        = 'Операции возвратов';
$_['text_add']         = 'Qo\'shish';
$_['text_edit']        = 'Tahrirlash';

// Column
$_['column_name']      = 'Операция возврата';
$_['column_action']    = 'Harakat';

// Entry
$_['entry_name']       = 'Операция возврата';

// Error
$_['error_permission'] = 'У Вас нет прав для изменения операций возвратов!';
$_['error_name']       = 'Операция возврата должена быть от 3 до 32 символов!';
$_['error_return']     = 'Операция возврата не может быть удалена, так как назначена %s товарам!';

