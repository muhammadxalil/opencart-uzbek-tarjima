<?php
// Heading
$_['heading_title']    = 'Qaytarish sababi';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']        = 'Qaytarish sababi';
$_['text_add']         = 'Qo\'shish';
$_['text_edit']        = 'Tahrirlash';

// Column
$_['column_name']      = 'Qaytarish sababi';
$_['column_action']    = 'Harakat';

// Entry
$_['entry_name']       = 'Qaytarish sababi';

// Error
$_['error_permission'] = 'Qaytarish sabablarini o\'zgartirish huquqiga ega emassiz!';
$_['error_name']       = 'Qaytarishning sababi 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_return']     = 'Qaytarish sababini o\'chirib bo\'lmaydi, chunki %s mahsulotga tayinlangan!';

