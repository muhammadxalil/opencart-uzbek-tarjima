<?php
// Heading
$_['heading_title']    = 'Joylashgan joyi';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']        = 'Joylashgan joyi';
$_['text_add']         = 'Qo\'shish';
$_['text_edit']        = 'Tahrirlash';
$_['text_default']     = 'Standart holda';
$_['text_time']        = 'Ish tartibi';
$_['text_geocode']     = 'Geocode Xatosi ......';

// Column
$_['column_name']      = 'Do\'kon nomi';
$_['column_address']   = 'Manzil';
$_['column_action']    = 'Harakat';

// Entry
$_['entry_name']       = 'Do\'kon nomi';
$_['entry_address']    = 'Manzil';
$_['entry_geocode']    = 'Geocode';
$_['entry_telephone']  = 'Telefon';
$_['entry_fax']        = 'Faks';
$_['entry_image']      = 'Rasm';
$_['entry_open']       = 'Ish tartibi';
$_['entry_comment']    = 'Qo\'shimcha ma\'lumot';

// Help
$_['help_geocode']     = 'Iltimos, joylashuvingizni GeoCode sifatida kiriting.';
$_['help_open']        = 'Do\'koningizning ishlash tartibi.';
$_['help_comment']     = 'Ushbu maydon xaridorga qo\'shimcha ma\'lumot olish uchun. Masalan, bizning do\'kon faqat Visa kartalarini qabul qiladi.';

// Error
$_['error_permission'] = 'Ushbu sozlamalarni o\'zgartirishga sizda ruxsat yo\'q!';
$_['error_name']       = 'Do\'kon nomi 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_address']    = 'Do\'kon manzili 10-256 belgidan iborat bo\'lishi kerak!';
$_['error_telephone']  = 'Telefon 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';

