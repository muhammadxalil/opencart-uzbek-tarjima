<?php
// Heading
$_['heading_title']        = 'Soliq stavkalari';

// Text
$_['text_success']         = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']            = 'Stavkalar ro\'yxati';
$_['text_add']             = 'Qo\'shish';
$_['text_edit']            = 'Tahrirlash';
$_['text_percent']         = 'Foiz';
$_['text_amount']          = 'Belgilangan qiymat';

// Column
$_['column_name']          = 'Soliq nomi';
$_['column_rate']          = 'Stavka';
$_['column_type']          = 'Turi';
$_['column_geo_zone']      = 'Geografik hudud';
$_['column_date_added']    = 'Qo\'shilgan';
$_['column_date_modified'] = 'O\'zgartirilgan';
$_['column_action']        = 'Harakat';

// Entry
$_['entry_name']           = 'Nomi';
$_['entry_rate']           = 'Stavka';
$_['entry_type']           = 'Turi';
$_['entry_customer_group'] = 'Mijozlar guruhi';
$_['entry_geo_zone']       = 'Geografik hudud';

// Error
$_['error_permission']     = 'Sizda soliq stavkalarini o\'zgartirish huquqingiz yo\'q!';
$_['error_tax_rule']       = 'Soliq stavkasini olib tashlab bo\'lmaydi, chunki %s soliq sinflariga belgilangan!';
$_['error_name']           = 'Nom 3 tadan 32 tagacha belgili bo\'lishi kerak!';
$_['error_rate']           = 'Stavkani kiritish talab etiladi!';

