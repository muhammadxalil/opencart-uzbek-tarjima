<?php
// Heading
$_['heading_title']    = 'O\'lchov birliklari';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']        = 'O\'lchov birliklari';
$_['text_add']         = 'Qo\'shish';
$_['text_edit']        = 'Tahrirlash';

// Column
$_['column_title']     = 'O\'lchov birligining nomi';
$_['column_unit']      = 'O\'lchov birligi';
$_['column_value']     = 'Qiymati';
$_['column_action']    = 'Harakat';

// Entry
$_['entry_title']      = 'O\'lchov birligining nomi';
$_['entry_unit']       = 'O\'lchov birligi';
$_['entry_value']      = 'Qiymati';

// Help
$_['help_value']       = 'Agar u standart birlik bo\'lsa, 1.00000 ga o\'rnating.';

// Error
$_['error_permission'] = 'Sizda o\'lchov birliklarini o\'zgartirish huquqi yo\'q!';
$_['error_title']      = 'Birlik nomi 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_unit']       = 'O\'lchov birligi nomi 3 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_default']    = 'O\'lchov birligini o\'zgartirib bo\'lmaydi, chunki u sukut bo\'yicha o\'rnatilgan!';
$_['error_product']    = 'Birliklarni o\'chirib bo\'lmaydi, chunki %s mahsulotlarga tayinlangan!';

