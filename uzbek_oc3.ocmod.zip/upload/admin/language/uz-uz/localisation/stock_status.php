<?php
// Heading
$_['heading_title']    = 'Omborda holati';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']        = 'Holatlar ro\'yxati';
$_['text_add']         = 'Qo\'shish';
$_['text_edit']        = 'Tahrirlash';

// Column
$_['column_name']      = 'Ombor holati variantlari';
$_['column_action']    = 'Harakat';

// Entry
$_['entry_name']       = 'Ombor holati nomi';

// Error
$_['error_permission'] = 'Siz ombor holatlarini o\'zgartirish huquqiga ega emassiz!';
$_['error_name']       = 'Nom 3 tadan 32 tagacha belgili bo\'lishi kerak!';
$_['error_product']    = 'Ombordagi holatini o\'chirib bo\'lmadi, chunki %s tovarlarga tayinlangan!';

