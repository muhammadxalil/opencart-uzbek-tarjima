<?php
// Heading
$_['heading_title']         = 'Foydalanuvchilar';

// Text
$_['text_success']          = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']             = 'Foydalanuvchilar';
$_['text_add']              = 'Qo\'shish';
$_['text_edit']             = 'Tahrirlash';

// Column
$_['column_username']       = 'Login';
$_['column_status']         = 'Status';
$_['column_date_added']     = 'Qo\'shilgan';
$_['column_action']         = 'Harakat';

// Entry
$_['entry_username']        = 'Login';
$_['entry_user_group']      = 'Foydalanuvchilr guruhi';
$_['entry_password']        = 'Parol';
$_['entry_confirm']         = 'Parolni tasdiqlang';
$_['entry_firstname']       = 'Ism, Otasining ismi';
$_['entry_lastname']        = 'Familiya';
$_['entry_email']           = 'E-Mail';
$_['entry_image']           = 'Rasm';
$_['entry_status']          = 'Holati';

// Error
$_['error_permission']      = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
$_['error_account']         = 'Hisobingizni o\'chira olmaysiz!';
$_['error_exists_username'] = 'Diqqat: Belgilangan ism allaqachon ishlatilyapti!';
$_['error_username']        = 'Foydalanuvchi ismi 3 tadan 20 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_password']        = 'Parol 3 tadan 20 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_confirm']         = 'Parol va tasdiqlash parollari bir-biriga mos kelmaydi!';
$_['error_firstname']       = 'Ism 1 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_lastname']        = 'Familiya 1 tadan 32 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_email']           = 'Ko\'rsatilgan e-mail noto\'g\'ri!';
$_['error_exists_email']    = 'Diqqat: Ko\'rsatilgan e-mail ishlatilyapti!';

