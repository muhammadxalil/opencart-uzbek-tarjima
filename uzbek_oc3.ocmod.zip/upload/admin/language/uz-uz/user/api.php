<?php
// Heading
$_['heading_title']        = 'API';

// Text
$_['text_success']         = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']            = 'API';
$_['text_add']             = 'Qo\'shish';
$_['text_edit']            = 'Tahrirlash';
$_['text_ip']              = 'Вы можете создать список IP адресов, которым разрешено использовать API. Ваш IP - %s';

// Column
$_['column_name']          = 'Ism';
$_['column_status']        = 'Status';
$_['column_date_added']    = 'Qo\'shilgan sanasi';
$_['column_date_modified'] = 'O\'zgartirilgan sanasi';
$_['column_token']         = 'Token';
$_['column_ip']            = 'IP';
$_['column_action']        = 'Harakat';

// Entry
$_['entry_name']           = 'API ism';
$_['entry_key']            = 'API kalit';
$_['entry_status']         = 'Status';
$_['entry_ip']             = 'IP';

// Error
$_['error_permission']     = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
$_['error_name']           = 'Nom 3 tadan 20 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_key']            = 'API kaliti 64 tadan 256 tagacha belgidan iborat bo\'lishi kerak!';


