<?php
// Heading
$_['heading_title']    = 'Foydalanuvchilar guruhi';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']        = 'Foydalanuvchilar guruhlari';
$_['text_add']         = 'Qo\'shish';
$_['text_edit']        = 'Tahrirlash';

// Column
$_['column_name']      = 'Foydalanuvchilar guruhlari';
$_['column_action']    = 'Harakat';

// Entry
$_['entry_name']       = 'Foydalanuvchilar guruhlari';
$_['entry_access']     = 'Ko\'rishga ruxsat berilgan';
$_['entry_modify']     = 'O\'zgartirishlarga ruxsat berilgan';

// Error
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
$_['error_name']       = 'Foydalanuvchi guruhining nomi 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_user']       = 'Ushbu foydalanuvchi guruhini o\'chirib bo\'lmaydi, chunki unda %s foydalanuvchilar mavjud!';

