<?php
// Heading
$_['heading_title']    = 'Mavzular muharriri';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Tahrirlash';
$_['text_store']       = 'Do\'konni tanlash';
$_['text_template']    = 'Shablonni tanlash';
$_['text_default']     = 'Standart';
$_['text_warning']     = 'Diqqat! Mavzular muharriri tufayli xavfsizlik buzilishi mumkin';
$_['text_access']      = 'Ushbu sahifaga faqat kerakli ma\'mur hisob qaydnomalari kirish huquqiga ega ekanligiga ishonch hosil qiling, bu sizning dastlabki kodingizga to\'g\'ridan-to\'g\'ri kirish usulidir.';
$_['text_permission']  = 'Siz kirish huquqini <a href="%s" class="alert-link">bu yerda</a> o\'zgartirishingiz mumkin.';
$_['text_begin']       = 'Tahrirlashni boshlash uchun chapdagi mavzuni tanlang.';

// Error
$_['error_permission'] = 'Sizda sozlamalarni o\'zgartirish huquqi yo\'q!';

