<?php
// Heading
$_['heading_title']    = 'Tarjimalar';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']        = 'Tarjimalar ro\'yxati';
$_['text_edit']        = 'Tahrirlash';
$_['text_add']         = 'Qo\'shish';
$_['text_default']     = 'Standart';
$_['text_store']       = 'Do\'kon';
$_['text_language']    = 'Til';

// Column
$_['column_store']     = 'Do\'kon';
$_['column_language']  = 'Til';
$_['column_route']     = 'Yo\'l';
$_['column_key']       = 'Kalit';
$_['column_action']    = 'Harakat';

// Entry
$_['entry_store']      = 'Do\'kon';
$_['entry_language']   = 'Til';
$_['entry_route']      = 'Yo\'l';
$_['entry_key']        = 'Kalit';
$_['entry_default']    = 'Standart';
$_['entry_value']      = 'Qiymati';

// Error
$_['error_permission'] = 'Sizda tarjimalarni o\'zgartirish huquqi yo\'q!';
$_['error_key']        = 'Kalit 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';