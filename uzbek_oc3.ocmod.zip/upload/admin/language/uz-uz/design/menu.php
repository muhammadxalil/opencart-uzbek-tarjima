<?php
// Heading
$_['heading_title']     = 'Menyu';

// Text
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']         = 'Menyu ro\'yxati';
$_['text_add']          = 'Qo\'shish';
$_['text_edit']         = 'Tahrirlash';
$_['text_default']      = 'Standart';
$_['text_link']         = 'Havola';
$_['text_module']       = 'Modul';

// Column
$_['column_name']       = 'Nomi';
$_['column_store']      = 'Do\'kon';
$_['column_type']       = 'Turi';
$_['column_sort_order'] = 'Saralash tartibi';
$_['column_status']     = 'Holati';
$_['column_action']     = 'Harakat';

// Entry
$_['entry_name']        = 'Menyu';
$_['entry_store']       = 'Do\'kon';
$_['entry_type']        = 'Turi';
$_['entry_sort_order']  = 'Saralash tartibi';
$_['entry_module']      = 'Modul';
$_['entry_status']      = 'Holati';

// Error
$_['error_permission']  = 'Sozlamalarni o\'zgartirishga sizda ruxsat yo\'q!';
$_['error_name']        = 'Banner nomi 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_default']     = 'Ushbu menyuni o\'chirib bo\'lmaydi, chunki u do\'konda standart holatda ishlatilyapti!';
$_['error_store']       = 'Ushbu menyuni o\'chirib bo\'lmaydi, chunki u %s do\'kon(lar) tomonidan ishlatilyapti!';

