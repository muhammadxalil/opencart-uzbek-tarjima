<?php
// Heading
$_['heading_title']    = 'Til muharriri';

// Text
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Tahrirlash';
$_['text_default']     = 'Standart';
$_['text_store']       = 'Do\'kon';
$_['text_language']    = 'Til';
$_['text_translation'] = 'Tarjimani tanlash';
$_['text_translation'] = 'Tarjimani tanlash';

// Entry
$_['entry_key']        = 'Kalit';
$_['entry_value']      = 'Qiymati';
$_['entry_default']    = 'Standart';

// Error
$_['error_permission'] = 'Sizda sozlamalarni o\'zgartirish uchun ruxsat yo\'q!';

