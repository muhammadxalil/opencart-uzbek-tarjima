<?php
// Heading
$_['heading_title']       = 'Maketlar';

// Text
$_['text_success']        = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']           = 'Maketlar';
$_['text_add']            = 'Qo\'shish';
$_['text_edit']           = 'Tahrirlash';
$_['text_remove']         = 'O\'chirish';
$_['text_route']          = 'Ushbu maket uchun do\'kon va yo\'lni tanlang.';
$_['text_module']         = 'Modul o\'rnini tanlang';
$_['text_default']        = 'Standart';
$_['text_content_top']    = 'Sahifaning yuqori qismi';
$_['text_content_bottom'] = 'Sahifaning pastki qismi';
$_['text_column_left']    = 'Chap ustun';
$_['text_column_right']   = 'O\'ng ustun';

// Column
$_['column_name']         = 'Maket nomi';
$_['column_action']       = 'Harakat';

// Entry
$_['entry_name']          = 'Maket nomi';
$_['entry_store']         = 'Do\kon';
$_['entry_route']         = 'Yo\'l';
$_['entry_module']        = 'Modul';

// Error
$_['error_permission']    = 'Sizda Maketlarni o\'zgartirish uchun yetarlicha huquqlar mavjud emas!';
$_['error_name']          = 'Maket nomi 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_default']       = 'Ushbu maketni o\'chirib bo\'lmaydi, chunki u standart do\'konda ishlatilyapti!';
$_['error_store']         = 'Ushbu maketni o\'chirib bo\'lmaydi, chunki u %s do\'kon(lar) tomonidan ishlatilyapti!';
$_['error_product']       = 'Ushbu maketni o\'chirib bo\'lmaydi, chunki u %s mahsulot(lar) tomonidan ishlatilyapti!';
$_['error_category']      = 'Ushbu maketni o\'chirib bo\'lmaydi, chunki u %s kategoriya(lar) tomonidan ishlatilyapti!';
$_['error_information']   = 'Ushbu maketni o\'chirib bo\'lmaydi, chunki u %s sahifa(lar) tomonidan ishlatilyapti!';

