<?php
// Heading
$_['heading_title']     = 'Bannerlar';

// Text
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']         = 'Bannerlar';
$_['text_add']          = 'Qo\'shish';
$_['text_edit']         = 'Tahrirlash';
$_['text_default']      = 'Standart';

// Column
$_['column_name']       = 'Banner nomi';
$_['column_status']     = 'Holati';
$_['column_action']     = 'Harakat';

// Entry
$_['entry_name']        = 'Banner nomi';
$_['entry_title']       = 'Sarlavha';
$_['entry_link']        = 'Havola';
$_['entry_image']       = 'Rasm';
$_['entry_status']      = 'Holati';
$_['entry_sort_order']  = 'Saralash tartibi';

// Error
$_['error_permission'] = 'Sizda sozlamalarni o\'zgartirish huquqi yo\'q!';
$_['error_name']       = 'Banner nomi 3 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_title']      = 'Sarlavha 2 tadan 64 tagacha belgidan iborat bo\'lishi kerak!';

