<?php
// header
$_['heading_title']  = 'Parolni qayta tiklash';

// Text
$_['text_password']  = 'Yangi parolni kiriting!';
$_['text_success']   = 'Sizning parolingiz muvaffaqiyatli yangilandi!';

// Entry
$_['entry_password'] = 'Parol';
$_['entry_confirm']  = 'Parolni tasdiqlang';

// Error
$_['error_password'] = 'Parol 4 tadan 20 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_confirm']  = 'Parollar mos emas!';

