<?php
// Heading
$_['heading_title']      = 'OpenCart';

// Text
$_['text_profile']       = 'Sizning profil';
$_['text_store']         = 'Do\'konlar';
$_['text_help']          = 'Yordam';
$_['text_homepage']      = 'OpenCart sayti';
$_['text_support']       = 'Qo\'llab-quvvatlash forumi';
$_['text_documentation'] = 'Hujjatlar';
$_['text_logout']        = 'Chiqish';