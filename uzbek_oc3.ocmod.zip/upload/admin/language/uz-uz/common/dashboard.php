<?php
// Heading
$_['heading_title'] = 'Holat paneli';

// Error
$_['error_install'] = 'DIQQAT: O\'rnatish papkasi hali ham mavjud! install papkasini o\'chiring';

