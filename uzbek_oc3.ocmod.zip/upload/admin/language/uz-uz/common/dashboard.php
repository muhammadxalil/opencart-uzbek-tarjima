<?php
// Heading
$_['heading_title'] = 'Панель';

// Error
$_['error_install'] = 'Предупреждение: Нужно удалить папку /install после установки.';

