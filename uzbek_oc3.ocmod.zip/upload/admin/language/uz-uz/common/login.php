<?php
// header
$_['heading_title']  = 'Avtorizatsiya';

// Text
$_['text_heading']   = 'Avtorizatsiya';
$_['text_login']     = 'Login va parolni kiriting';
$_['text_forgotten'] = 'Parolni unutdingizmi?';

// Entry
$_['entry_username'] = 'Login';
$_['entry_password'] = 'Parol';

// Button
$_['button_login']   = 'Kirish';

// Error
$_['error_login']    = 'Bunday login va/yoki parol mavjud emas!';
$_['error_token']    = 'Toke-sessiya noto\'g\'ri. Qayta avtorizatsiyadan o\'ting.';

