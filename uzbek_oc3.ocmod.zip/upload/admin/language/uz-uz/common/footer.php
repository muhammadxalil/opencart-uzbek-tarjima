<?php
// Text
$_['text_footer'] 	= '<hr><a href="http://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . 'Barcha huquqlar himoyalangan.<br> <a href="http://opencart3x.ru" target="_blank">OpenCart 3 ning ruscha versiyasi - modullar va shablonlar</a>';
$_['text_version'] 	= 'Version %s';

