<?php
// header
$_['heading_title']   = 'Parolni unutdingizmi?';

// Text
$_['text_forgotten']  = 'Unutilgan parol';
$_['text_your_email'] = 'Sizning E-Mail';
$_['text_email']      = 'Hisob qaydnomangizga biriktirilgan elektron pochta manzilini kiriting. Elektron pochta orqali yuborilgan parolni tiklash havolasiga o\'ting.';
$_['text_success']    = 'Tasdiqlash havolasi elektron pochta manzilingizga yuborildi.';

// Entry
$_['entry_email']     = 'E-Mail';
$_['entry_password']  = 'Yangi parol';
$_['entry_confirm']   = 'Parolni qaytarish';

// Error
$_['error_email']     = 'Bunday elektron pochta topilmadi.';
$_['error_password']  = 'Parol 4 tadan 20 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_confirm']   = 'Parollar mos emas!';

