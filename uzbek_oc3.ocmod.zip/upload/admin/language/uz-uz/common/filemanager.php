<?php
// Heading
$_['heading_title']    = 'Rasmlar menejeri';

// Text
$_['text_uploaded']    = 'Fayl yuklandi!';
$_['text_directory']   = 'Tayyor: Katalog yaratildi!';
$_['text_delete']      = 'Fayl yoki katalog o\'chirildi!';

// Entry
$_['entry_search']     = 'Qidiruv..';
$_['entry_folder']     = 'Yangi jild';

// Error
$_['error_permission'] = 'Sizda kirish huquqi yo\'q!';
$_['error_filename']   = 'Fayl nomi 3 tadan 255 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_folder']     = 'Diqqat: Katalog nomi 3 tadan 255 tagacha belgidan iborat bo\'lishi kerak!';
$_['error_exists']     = 'Shu nomli fayl yoki katalog allaqachon mavjud!';
$_['error_directory']  = 'Katalogni tanlang!';
$_['error_filesize']   = 'Diqqat: Fayl hajmi noto\'g\'ri!';
$_['error_filetype']   = 'Diqqat: Fayl turi noto\'g\'ri!';
$_['error_upload']     = 'Diqqat: Noma\'lum sabablarga ko\'ra faylni yuklab olib bo\'lmadi!';
$_['error_delete']     = 'Katalogni o\'chirib bo\'lmadi!';


