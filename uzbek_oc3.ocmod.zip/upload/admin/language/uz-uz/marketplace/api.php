<?php
// Heading
$_['heading_title']    = 'Opencart.com ga avtorizatsiya';

// Text
$_['text_success']     = 'Muvaffaqiyat: siz o\'zgartirishlarni kiritdingiz!';
$_['text_signup']      = 'Hisob qaydnomangiz ma\'lumotlarini kiriting. Siz ro\'yxatdan o\'tishingiz mumkin <a href="https://www.opencart.com/index.php?route=account/store" target="_blank" class="alert-link">здесь</a>.';

// Entry
$_['entry_username']   = 'Login';
$_['entry_secret']     = 'Parol';

// Error
$_['error_permission'] = 'Diqqat: sizda opencart.com saytida avtorizatsiyani o\'zgartirish huquqi yo\'q!';
$_['error_username']   = 'Login majburiy!';
$_['error_secret']     = 'Parol majburiy!';
