<?php
// Heading
$_['heading_title']     = 'Modullarni o\'rnatish';

// Text
$_['text_progress']     = 'Jarayon';
$_['text_upload']       = 'Faylni yuklash';
$_['text_history']      = 'O\'rnatishlar tarixi';
$_['text_success']      = 'Modul muvaffaqiyatli o\'rnatildi!';
$_['text_install']      = 'O\'rnatish';

// Column
$_['column_filename']   = 'Fayl';
$_['column_date_added'] = 'Qo\'shilgan sana';
$_['column_action']     = 'Harakat';

// Entry
$_['entry_upload']      = 'Faylni yuklash';
$_['entry_progress']    = 'Jarayon';

// Help
$_['help_upload']       = 'ocmod.zip yoki ocmod.xml modifikator fayli kerak.';

// Error
$_['error_permission']  = 'Diqqat: Sizda o\'zgarishlarni o\'zgartirish huquqi yo\'q!';
$_['error_install']     = 'O\'rnatish hali tugallanmadi, bir necha soniya kuting!';
$_['error_upload']      = 'Fayl yuklanmadi!';
$_['error_filetype']    = 'Fayl turi noto\'g\'ri!';
$_['error_file']        = 'Fayl topilmadi!';