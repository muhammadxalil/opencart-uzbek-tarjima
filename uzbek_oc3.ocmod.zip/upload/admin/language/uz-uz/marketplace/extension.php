<?php
// Heading
$_['heading_title']  = 'Modullar / Kengaytmalar';

// Text
$_['text_success']   = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']      = 'Kengaytma';
$_['text_type']      = 'Kengaytma turini tanlang';
$_['text_filter']    = 'Filtr';
$_['text_analytics'] = 'Tahlil';
$_['text_captcha']   = 'Robotlardan himoya';
$_['text_dashboard'] = 'Панель управления';
$_['text_feed']      = 'Rag\'batlantirish';
$_['text_fraud']     = 'Firibgarlardan himoya';
$_['text_module']    = 'Modullar';
$_['text_content']   = 'Matn modullari';
$_['text_menu']      = 'Menyu';
$_['text_payment']   = 'To\'lov';
$_['text_shipping']  = 'Yetkazib berish';
$_['text_theme']     = 'Mavzular';
$_['text_total']     = 'Buyurtmada hisobga olish';

