<?php
// Text
$_['text_success']     = 'Muvaffaqiyat: Siz modullarni o\'zgartirdingiz!';
$_['text_unzip']       = 'Fayllarni arxivdan chiqarish';
$_['text_move']        = 'Fayllardan nusxa oling!';
$_['text_xml']         = 'Modifikatsiyadan foydalanish';
$_['text_remove']      = 'Vaqtinchalik fayllarni yo\'q qilish!';

// Error
$_['error_permission'] = 'Diqqat: modullarni o\'zgartirish huquqi sizda yo\'q!';
$_['error_install']    = 'O\'rnatish hali tugallanmadi, bir necha soniya kuting!';
$_['error_unzip']      = 'Zip faylni ochib bo\'lmadi!';
$_['error_file']       = 'install faylini topib bo\'lmadi!';
$_['error_directory']  = 'upload jildini topib bo\'lmadi!';
$_['error_code']       = 'XML-da noyob modul kodi kerak!';
$_['error_xml']        = '%s o\'zgartirish allaqachon o\'rnatilgan!';
$_['error_exists']     = '%s fayl allaqachon mavjud!';
$_['error_allowed']    = '%s jildni yozib bo\'lmaydi!';