<?php
// Heading
$_['heading_title']     = 'Hodisalar';

// Text
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']         = 'Hodisalar';
$_['text_event']        = 'Voqealar do\'koningizning standart funktsiyalarini o\'zgartiradi. Muammolar tug\'ulsa, bu erda tadbirlarni o\'chirib qo\'yishingiz yoki yoqishingiz mumkin.';

// Column
$_['column_code']       = 'Kod';
$_['column_trigger']    = 'Tepki';
$_['column_action']     = 'Harakat';
$_['column_status']     = 'Holati';
$_['column_date_added'] = 'Qo\'shilgan';
$_['column_action']     = 'Harakat';

// Error
$_['error_permission']  = 'Sozlamalarni o\'zgartirishga sizda ruxsat yo\'q!';

