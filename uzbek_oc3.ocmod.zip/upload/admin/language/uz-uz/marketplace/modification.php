<?php
// Heading
$_['heading_title']     = 'Modifikatorlar';

// Text
$_['text_success']      = 'Harakat muvaffaqiyatli yakunlandi!';
$_['text_refresh']      = 'Modifikatorni har safar yoqsangiz / o\'chirsangiz yoki yo\'q qilsangiz yangilash tugmachasini bosish kerak, u modifikatorlar keshini yangilaydi!';
$_['text_list']         = 'Modifikatorlar';

// Column
$_['column_name']       = 'Nomi';
$_['column_author']     = 'Muallifi';
$_['column_version']    = 'Versiyasi';
$_['column_status']     = 'Holati';
$_['column_date_added'] = 'Sana';
$_['column_action']     = 'Harakat';

// Error
$_['error_permission']  = 'Diqqat: Modifikatorlarni boshqarish uchun sizda ruxsat yo\'q!';

