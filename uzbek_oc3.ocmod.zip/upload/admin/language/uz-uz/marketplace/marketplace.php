<?php
// Heading
$_['heading_title']      = 'Modullar do\'koni';

// Text
$_['text_success']       = 'Muvaffaqiyat: Siz modullarni o\'zgartirdingiz!';
$_['text_list']          = 'Modullar ro\'yxati';
$_['text_filter']        = 'Filtr';
$_['text_search']        = 'Modul va shablonlarni qidirish';
$_['text_category']      = 'Kategoriyalar';
$_['text_all']           = 'Hammasi';
$_['text_theme']         = 'Shablonlar';
$_['text_marketplace']   = 'Modullar do\'koni';
$_['text_language']      = 'Tillar';
$_['text_payment']       = 'To\'lov';
$_['text_shipping']      = 'Yetkazib berish';
$_['text_module']        = 'Modullar';
$_['text_total']         = 'Buyurtmada hisobga olib qo\'yish';
$_['text_feed']          = 'Reklama kanallari';
$_['text_report']        = 'Hisobotlar';
$_['text_other']         = 'Boshqa';
$_['text_free']          = 'Bepul';
$_['text_paid']          = 'Pullik';
$_['text_purchased']     = 'Sotib olinganlar';
$_['text_date_modified'] = 'O\'zgartirilgan sanasi';
$_['text_date_added']    = 'Qo\'shilgan sanasi';
$_['text_name']          = 'Nomi';
$_['text_rating']        = 'Reyting bahosi';
$_['text_reviews']       = 'Sharhlar';
$_['text_compatibility'] = 'Moslik';
$_['text_downloaded']    = 'Yuklangan';
$_['text_price']         = 'Narxi';
$_['text_partner']       = 'OpenCart Partner tomonidan ishlab chiqilgan';
$_['text_support']       = '12 oylik qo\'llab-quvvatlash';
$_['text_documentation'] = 'Hujjatlar mavjud';
$_['text_sales']         = 'Savdolar';
$_['text_comment']       = 'Izohlar';
$_['text_download']      = 'Yuklash';
$_['text_install']       = 'O\'rnatish';
$_['text_comment']       = 'Izoh';
$_['text_comment_add']   = 'Izoh qoldiring';
$_['text_write']         = 'Izohingizni qoldiring..';
$_['text_purchase']      = 'Kimligingizni tasdiqlang!';
$_['text_pin']           = '4 raqamli PIN-kodni kiriting. Ushbu PIN-kod hisobingizni himoya qilish uchun yaratilgan.';
$_['text_secure']        = 'PIN-kodingizni hech kimga, shu jumladan ishlab chiquvchilarga bermang. Agar sizga modulni o\'rnatish uchun dasturchi kerak bo\'lsa, unga tegishli modulni yuborishingiz kerak.';

// Entry
$_['entry_pin']          = 'PIN';

// Tab
$_['tab_description']    = 'Ta\'rif';
$_['tab_documentation']  = 'Hujjatlar';
$_['tab_download']       = 'Yuklash';
$_['tab_comment']        = 'Sharhlar';

// Button
$_['button_opencart']    = 'opencart.com ga kirish';
$_['button_purchase']    = 'Sotib olish';
$_['button_comment']     = 'Izohlar';
$_['button_reply']       = 'Javob yozish';

// Error
$_['error_permission']   = 'Diqqat: kengaytmalarni o\'zgartirishga sizda ruxsat yo\'q!';
$_['error_opencart']     = 'Diqqat: Xarid qilishdan oldin siz o\'z hisobingiz to\'g\'risidagi ma\'lumotni opencart.com saytiga kiritishingiz kerak!';
$_['error_install']      = 'O\'rnatish hali tugallanmagan, bir necha soniya kuting!';
$_['error_purchase']     = 'Kengaytmani sotib olishning iloji yo\'q!';
$_['error_download']     = 'Kengaytmani yuklab bo\'lmadi!';
