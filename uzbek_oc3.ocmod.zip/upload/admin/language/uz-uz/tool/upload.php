<?php
// Heading
$_['heading_title']     = 'Tashqi yuklamalar';

// Text
$_['text_success']      = 'Bajarildi!';
$_['text_list']         = 'Tashqi yuklamalar';

// Column
$_['column_name']       = 'Fayl nomi';
$_['column_filename']   = 'Fayl nomi';
$_['column_date_added'] = 'Qo\'shilgan sanasi';
$_['column_action']     = 'Harakat';

// Entry
$_['entry_name']        = 'Fayl nomi';
$_['entry_filename']    = 'Fayl nomi';
$_['entry_date_added'] 	= 'Qo\'shilgan sanasi';

// Error
$_['error_permission']  = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';

