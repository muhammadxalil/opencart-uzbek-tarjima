<?php
// Heading
$_['heading_title']	   = 'Xatolar jurnali';

// Text
$_['text_success']	   = 'Xatolar jurnali tozalandi!';
$_['text_list']        = 'Xatoliklar';

// Error
$_['error_warning']	   = 'Diqqat: Sizning %s xatolar fayli %s dan';
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';

