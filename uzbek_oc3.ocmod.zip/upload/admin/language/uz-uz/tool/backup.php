<?php
// Heading
$_['heading_title']    = 'Import / Eksport';

// Text
$_['text_success']     = 'Ma\'lumotlar bazasi import qilindi';

// Entry
$_['entry_import']     = 'Import fayli .sql';
$_['entry_export']     = '.sql faylga ma\'lumotlarni eksport qilish jadvallari';

// Error
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
$_['error_export']     = 'Diqqat: Eksport qilish uchun siz kamida bitta jadvalni tanlashingiz kerak!';
$_['error_empty']      = 'Yuklangan fayl bo\'sh!';

