O'zbe tilini Opencart 3.x-ga o'rnatish:

1. Admin_ paneli orqali russian_oc3.ocmod.zip arxivini o'rnating yoki arxivni oching va fayllarni saytdagi tegishli papkalarga yuklang.
2. Ma'mur panelida Tizim> Mahalliylashtirish> Tillar> + (Yangisini qo'shish) bo'limini oching va maydonlarga yozing:
� - Til nomi: O'zbek
� - Kod: uz-uz
� - Mahalliy: uz-UZ, uz_UZ.UTF-8, uz_UZ, uz-uz, uzbek
� - Holati: yoqilgan
� - Saralash tartibi: 1
3. Administrator panelida Tizim> Sozlamalar> Tahrirlash> Mahalliy yorlig'iga o'ting:
� - Tilni tanlang: Inglizcha
� - Boshqaruv tili: Ingliz tilini tanlang